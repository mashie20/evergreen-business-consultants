<!-- ================================================================= -->
<!-- SECTION 9: FINAL VERIFICATION & STALE-STATE AUDIT -->
<!-- ================================================================= -->
<verification_audit>
1. MANDATORY POST-CHANGE AUDIT:
   - Every substantive update to the codebase MUST be followed by a verification audit before the task is marked as complete.
   - An audit consists of:
     a. A "Cold Boot" check: Restarting the environment (Docker/Server) to ensure no in-memory state is masking bugs.
     b. A "Render Check": Verifying that the DOM actually reflects the changes (via `gstack browse` or `qa-flow.js`).
     c. A "Stale-File Scan": Checking for orphaned `.tmp`, `.bak`, or duplicate files that might be accidentally imported.
2. ZERO-TRUST DELIVERY:
   - "It should work" is not a valid state. Only evidence-based confirmation (screenshots, log output, or passing test suites) is acceptable.
   - If a change is made to a critical UI path (e.g., the Player or Header), the agent MUST verify it across at least two viewport sizes (Desktop + Mobile).
</verification_audit>


<!-- ================================================================= -->
<!-- SECTION 10: OMNI-PLATFORM v2.0.0 & ZERO-ADS IRON LAW -->
<!-- ================================================================= -->
<omni_platform_and_zero_ads>
1. VERSION SYNCHRONIZATION (v2.0.0):
   - Homeflix is upgraded to Omni-Platform v2.0.0 supporting 5 surfaces from a single codebase:
     Mobile (`<640px`), Tablet (`640-1023px`), Desktop Web (`1024-1919px`), macOS (`src-tauri`), and Smart TV 10-Foot UI (`>=1920px` + Android TV Leanback).
2. ZERO-ADS SHIELD (STRICT ANTI-ADVERTISEMENT POLICY):
   - Homeflix enforces a strict Zero-Ads policy across all VOD, Live TV, Radio, and UI surfaces.
   - No ad scripts, third-party ad trackers, pre-roll/mid-roll ad injections, or sponsored placements are permitted anywhere in `public/` or `server.js`.
3. MULTI-SURFACE INPUT & SPATIAL NAVIGATION:
   - Every interactive element must remain reachable via 2D D-Pad spatial navigation (`public/omni-bridge.js`), touch gestures, and keyboard shortcuts.
</omni_platform_and_zero_ads>
