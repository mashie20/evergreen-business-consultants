#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then echo 'Install Node.js 20 or later'; exit 1; fi
node -e 'if (+process.versions.node.split(".")[0] < 20) process.exit(1)' || { echo 'Node.js 20+ required'; exit 1; }
mkdir -p data
if [ -f .env ]; then exec node --env-file=.env server.js; fi
exec node server.js
