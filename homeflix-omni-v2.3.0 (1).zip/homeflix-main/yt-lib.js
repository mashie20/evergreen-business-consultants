'use strict';
/* yt-lib.js — pure helpers for Homeflix dynamic YouTube live channels.
 * No I/O on purpose: catalog.js wires the registry/resolver, this file only
 * normalizes/validates/derives so tests can pin the behavior exactly. */

const YT_ID_RE = /^[A-Za-z0-9_-]{11}$/;

/* Any user-supplied or admin-pasted YouTube reference -> canonical watch URL.
 * Accepted:
 *   https://www.youtube.com/@AlJazeeraEnglish/live        -> channel live page
 *   https://www.youtube.com/@AlJazeeraEnglish/streams
 *   https://www.youtube.com/channel/UC...
 *   https://www.youtube.com/watch?v=<11>                  -> live-video watch
 *   https://youtu.be/<11> (+ path like /live)
 *   @AlJazeeraEnglish
 *   <11-char video id>
 * Returns {ok:true, kind:'channel'|'video', id, watchUrl} or {ok:false, reason}.
 */
function normalizeYtInput(raw) {
  const s = String(raw || '').trim();
  if (!s) return { ok: false, reason: 'empty' };

  // bare 11-char video id
  if (YT_ID_RE.test(s)) return video(s);

  // bare handle: "@name" with optional /live|/streams suffix
  if (/^@[A-Za-z0-9._-]{3,}$/.test(s)) return handle(s.slice(1).replace(/\/(live|streams)$/i, ''));

  let u = null;
  try { u = new URL(/^https?:/i.test(s) ? s : 'https://' + s); } catch (_) { return { ok: false, reason: 'not a URL' }; }
  const host = String(u.hostname).toLowerCase().replace(/^www\./, '');
  if (host !== 'youtube.com' && host !== 'youtu.be' && host !== 'youtube-nocookie.com') {
    return { ok: false, reason: 'not a YouTube host' };
  }

  if (host === 'youtu.be') {
    const id = (u.pathname.split('/').filter(Boolean)[0] || '').split('?')[0];
    if (!YT_ID_RE.test(id)) return { ok: false, reason: 'bad video id' };
    return video(id);
  }

  const parts = u.pathname.split('/').filter(Boolean);
  if (parts[0] === 'channel' && /^UC[A-Za-z0-9_-]{10,}$/.test(parts[1] || '')) {
    return { ok: true, kind: 'channel', id: parts[1], watchUrl: 'https://www.youtube.com/' + parts.join('/') + '/streams' };
  }
  if (parts[0] === 'watch') {
    const id = u.searchParams.get('v') || (u.searchParams.get('u') ? (u.searchParams.get('u').split(';')[0]) : '');
    if (!YT_ID_RE.test(id)) return { ok: false, reason: 'bad video id' };
    return video(id);
  }
  if (parts[0] === 'live') {
    const seg = parts[1] || u.searchParams.get('v') || '';
    if (YT_ID_RE.test(seg)) return video(seg);
    if (/^@/.test(seg)) return handle(seg.slice(1).replace(/\/(live|streams)$/i, ''));
    return { ok: false, reason: 'invalid live path' };
  }
  if (/^@/.test(parts[0] || '')) return handle(decodeURIComponent(parts[0]).slice(1).replace(/\/(live|streams)$/i, ''));
  if (parts[0] === 'c' || parts[0] === 'user') {
    if (!parts[1]) return { ok: false, reason: 'no handle' };
    return handle(parts[1]);
  }
  return { ok: false, reason: 'unrecognized YouTube path' };
}

function video(id) {
  return { ok: true, kind: 'video', id, watchUrl: 'https://www.youtube.com/watch?v=' + id };
}
function handle(h) {
  const id = String(h).trim();
  if (!/^[A-Za-z0-9._-]{3,60}$/.test(id)) return { ok: false, reason: 'invalid handle' };
  return { ok: true, kind: 'channel', id: id, watchUrl: 'https://www.youtube.com/@' + id + '/live' };
}

/* Canonical display slug for the registry + pseudo-URL scheme:
 * chanId = 'ytl:' + slug so it is stable across renames and URL edits. */
function slug(name) {
  return String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 48) || 'channel';
}
function chanId(watchUrl) {
  // ytl:<slug of the handle|video id> — parsed back out of the pseudo-URL
  try {
    const n = normalizeYtInput(watchUrl);
    return n.ok ? 'ytl:' + slug(n.id) : null;
  } catch (_) { return null; }
}

/* Merge a user-submitted entry into an existing registry list.
 * Dedupe key: normalized handle/video id. Keeps first (official) entry mode
 * unless overwrite=true. Returns {list, added, updated} — never mutates input. */
function mergeRegistry(list, entry, overwrite) {
  const out = (list || []).slice();
  const key = String(entry.id || '').toLowerCase();
  const i = out.findIndex((e) => String(e.id || '').toLowerCase() === key);
  if (i < 0) { out.push(entry); return { list: out, added: true, updated: false }; }
  if (overwrite) { out[i] = Object.assign({}, out[i], { watchUrl: entry.watchUrl }, entry.n ? { n: entry.n } : {}); return { list: out, added: false, updated: true }; }
  return { list: out, added: false, updated: false };
}

/* Seed registry shipped with Homeflix — official, keyless, 24/7 live news
 * channels that publish raw HLS through YouTube. Additions land on disk
 * (data/yt-live.json) and never replace an explicitly pinned entry. */
const SEED = [
  { id: 'AJEnglish',      n: 'Al Jazeera English',   co: 'qa', cats: ['news'] },
  { id: 'AlArabiya',      n: 'Al Arabiya',           co: 'sa', cats: ['news'] },
  { id: 'dwnews',         n: 'DW English',           co: 'de', cats: ['news'] },
  { id: 'dwdeutsch',      n: 'DW Deutsch',           co: 'de', cats: ['news'] },
  { id: 'TRTWorld',       n: 'TRT World',            co: 'tr', cats: ['news'] },
  { id: 'SkyNews',        n: 'Sky News',             co: 'uk', cats: ['news'] },
  { id: 'markets',        n: 'Bloomberg TV',         co: 'us', cats: ['news', 'business'] },
  { id: 'CNBC',           n: 'CNBC',                 co: 'us', cats: ['news', 'business'] },
  { id: 'NBCNews',        n: 'NBC News NOW',         co: 'us', cats: ['news'] },
  { id: 'ABCNews',        n: 'ABC News Live',        co: 'us', cats: ['news'] },
  { id: 'channelnewsasia',n: 'CNA',                  co: 'sg', cats: ['news'] },
  { id: 'WION',           n: 'WION',                 co: 'in', cats: ['news'] },
  { id: 'France24_en',    n: 'France 24 English',    co: 'fr', cats: ['news'] }
].map((x) => Object.assign({ watchUrl: 'https://www.youtube.com/@' + x.id + '/live' }, x));

/* ============================================================
 * Download-route helpers (pure) — used by server.js /api/download
 * ============================================================ */

/* Provider embed mirrors. MUST stay in lockstep with:
 *   - server.js CSP frame-src
 *   - public/app.js EMBED_BASES
 * Download resolution is pinned to these hosts only (never user text). */
const PROVIDER_BASES = [
  'https://framextv.cc',
  'https://framextv.xyz',
  'https://framextv.pro'
];

/* TMDB id (+ optional tv season/episode) -> provider embed URL, or null on
 * any invalid input. Numbers only — the server answers 400 on null. */
function providerEmbedUrl(tmdbId, season, episode) {
  const id = Number(tmdbId);
  if (!Number.isInteger(id) || id <= 0 || id > 999999999) return null;
  if (season == null) return PROVIDER_BASES[0] + '/embed/' + id;
  const s = Number(season);
  const e = Number(episode);
  if (!Number.isInteger(s) || s < 1 || s > 200) return null;
  if (!Number.isInteger(e) || e < 1 || e > 2000) return null;
  return PROVIDER_BASES[0] + '/embed/' + id + '/' + s + '/' + e;
}

/* The container ships without ffmpeg on purpose (proxied-as-is design), so a
 * merged HSV/AAC HLS stream cannot be rebuilt into one file server-side.
 * Only PROGRESSIVE formats (one URL holding audio+video, or audio-only) can
 * be streamed as a real file. */
const PROGRESSIVE_PROTO_RE = /^(https?|ftps?)/i;
const FRAGMENTED_PROTO_RE = /(m3u8|dash|hls)/i;

function isProgressiveFormat(f) {
  if (!f || typeof f !== 'object') return false;
  const proto = String(f.protocol || '');
  if (!PROGRESSIVE_PROTO_RE.test(proto) || FRAGMENTED_PROTO_RE.test(proto)) return false;
  if (FRAGMENTED_PROTO_RE.test(String(f.ext || ''))) return false;
  return true;
}

/* Best directly-downloadable format from yt-dlp `-J` metadata.
 * Preference: video+audio muxed > video-only > audio-only; then resolution,
 * then bitrate; a known filesize wins ties (predicted Content-Length).
 * Returns the yt-dlp format object or null when nothing qualifies. */
function pickProgressiveFormat(meta) {
  const formats = meta && Array.isArray(meta.formats) ? meta.formats : [];
  let best = null;
  for (const f of formats) {
    if (!isProgressiveFormat(f)) continue;
    const hasV = Boolean(f.vcodec && f.vcodec !== 'none');
    const hasA = Boolean(f.acodec && f.acodec !== 'none');
    if (!hasV && !hasA) continue;
    const score =
      (hasV && hasA ? 4e9 : hasV ? 3e9 : 1e9) +
      (Number(f.height) || 0) * 1e3 +
      (Number(f.tbr) || 0) +
      (f.filesize || f.filesize_approx ? 5e8 : 0);
    if (!best || score > best._dlScore) best = Object.assign({ _dlScore: score }, f);
  }
  return best;
}

/* Content-Disposition-safe filename: strips control/path/quote characters,
 * collapses whitespace, caps length, never empty. Windows/macOS-portable. */
function sanitizeFilename(name) {
  let s = String(name || '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, ' ')
    .trim();
  s = s.replace(/^\.+/, '').slice(0, 100).trim();
  return s || 'homeflix-download';
}

module.exports = { normalizeYtInput, slug, chanId, mergeRegistry, SEED, YT_ID_RE, providerEmbedUrl, pickProgressiveFormat, isProgressiveFormat, sanitizeFilename, PROVIDER_BASES };
