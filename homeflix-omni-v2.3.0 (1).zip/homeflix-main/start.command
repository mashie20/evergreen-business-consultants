#!/bin/bash
# Double-click on macOS after allowing the script to run.
cd "$(dirname "$0")" || exit 1
exec /bin/bash ./start.sh
