#!/usr/bin/env bash
# Homeflix — one-shot public test link via Cloudflare quick tunnel (no account needed)
set -e
if ! command -v cloudflared >/dev/null 2>&1; then
  echo "Installing cloudflared…"
  if command -v brew >/dev/null 2>&1; then brew install cloudflared
  elif command -v apt >/dev/null 2>&1; then
    curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg | sudo tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null
    echo "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main" | sudo tee /etc/apt/sources.list.d/cloudflared.list
    sudo apt-get update && sudo apt-get install -y cloudflared
  else
    echo "Install cloudflared manually: https://developers.cloudflare.com/cloudflare/one-page-apps/cloudflare-one/connections/connect-networks/downloads/"
    exit 1
  fi
fi
echo "Starting a temporary public link for http://localhost:8200 …"
echo "Share the https://*.trycloudflare.com URL that appears. Ctrl+C to stop."
cloudflared tunnel --url http://localhost:8200
