#!/usr/bin/env bash
# Homeflix — print all current public links + health check (bash/git-bash)
cd "$(dirname "$0")"

echo
echo "[Homeflix links]"
echo "Local     : http://localhost:8200"

CF=$(docker logs homeflix-flare 2>&1 | grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' | tail -1 || true)
NG=$(docker logs homeflix-ngrok 2>&1 | grep -oE 'https://[a-z0-9.-]+ngrok[a-z.-]+(dev|app)' | tail -1 || true)
if [ -z "$NG" ]; then
  NG=$(curl -s -m 3 http://localhost:4040/api/tunnels 2>/dev/null | grep -oE 'https://[a-z0-9.-]+ngrok[a-z.-]+' | head -1 || true)
fi

[ -n "$CF" ] && echo "Cloudflare: $CF" || echo "Cloudflare: not running — start with: docker compose --profile flare up -d"
[ -n "$NG" ] && echo "ngrok     : $NG" || echo "ngrok     : not running — start with: docker compose --profile ngrok up -d (needs NGROK_AUTHTOKEN) or check host :4040 dashboard"

echo
echo "Health checks:"
curl -s -o /dev/null -w "  Local     : %{http_code} (%{time_total}s)\n" http://localhost:8200/api/health || true
[ -n "$CF" ] && curl -s -o /dev/null -w "  Cloudflare: %{http_code} (%{time_total}s)\n" "$CF/api/health" || true
[ -n "$NG" ] && curl -s -o /dev/null -w "  ngrok     : %{http_code} (%{time_total}s)\n" "$NG/api/health" || true
