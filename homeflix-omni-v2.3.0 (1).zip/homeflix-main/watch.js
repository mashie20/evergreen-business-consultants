'use strict';
/* ============================================================
   Homeflix source watcher — pushes server-side changes to the
   shared link automatically, WITHOUT taking the app down.
   Runs `server.js` as a child and hot-reloads it when server
   files change on disk (bind-mounted into the container).

   Stability rules (uptime matters):
   - Only server-side files trigger a restart. Static files under
     /public are served straight from disk, so UI/CSS/HTML edits
     appear instantly with no restart at all.
   - Edits settle before restart (debounce) and roll up into ONE
     restart — saving several files in a row costs a single blip.
   - A changed JS file must pass `node --check` first; if someone
     saved a half-written file, the current server keeps serving
     untouched until the syntax is fixed.
   - Restarts never happen more often than once every MIN_GAP_MS.
   ============================================================ */

const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const FILES = ['server.js', 'catalog.js', 'yt-lib.js', 'accounts.js', 'seed.json'];
const POLL_MS = 2000;       // mtime poll interval (works on any volume type)
const QUIET_MS = 3000;      // wait this long after the last change
const MIN_GAP_MS = 10000;   // never restart more often than this

const mtimes = new Map();
for (const f of FILES) {
  try { mtimes.set(f, fs.statSync(path.join(ROOT, f)).mtimeMs); }
  catch (_) { mtimes.set(f, 0); }
}

let child = null;
let stopping = false;
let backoff = 1000;
let pending = null;        // { files: Set, timer }
let lastRestart = 0;

function start() {
  lastRestart = Date.now();
  child = spawn(process.execPath, ['server.js'], { stdio: 'inherit', cwd: ROOT });
  child.on('exit', (code) => {
    if (stopping) process.exit(code || 0);
    console.log(`[hf-watch] server exited (${code}) — restarting in ${backoff}ms`);
    setTimeout(start, backoff);
    backoff = Math.min(backoff * 2, 8000);
  });
  child.on('spawn', () => { backoff = 1000; });
}

function syntaxOk(files) {
  for (const f of files) {
    if (!f.endsWith('.js')) continue;
    const r = spawnSync(process.execPath, ['--check', f], { cwd: ROOT, timeout: 10000 });
    if (r.status !== 0) {
      console.log(`[hf-watch] ${f} has a syntax error — keeping the current server running until it's fixed`);
      return false;
    }
  }
  return true;
}

function schedule(filesSet) {
  const go = () => {
    if (stopping || !child) return;
    if (!syntaxOk(filesSet)) return; // edited mid-write; the next save re-arms us
    const wait = Math.max(0, MIN_GAP_MS - (Date.now() - lastRestart));
    setTimeout(() => {
      if (stopping || !child) return;
      lastRestart = Date.now();
      console.log(`[hf-watch] hot-reload: ${[...filesSet].join(', ')}`);
      child.kill('SIGTERM'); // exit handler restarts it
    }, wait);
  };
  if (pending) clearTimeout(pending);
  pending = setTimeout(go, QUIET_MS);
}

setInterval(() => {
  if (stopping || !child) return;
  for (const f of FILES) {
    let m = 0;
    try { m = fs.statSync(path.join(ROOT, f)).mtimeMs; } catch (_) {}
    if (m !== mtimes.get(f)) {
      const first = mtimes.get(f) !== 0;
      mtimes.set(f, m);
      if (!first) continue; // first sweep after boot
      if (pending) { /* existing timer — just note it joined the bundle */ }
      else schedule(new Set([f]));
      console.log(`[hf-watch] change detected: ${f}`);
    }
  }
}, POLL_MS);

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    stopping = true;
    if (pending) clearTimeout(pending);
    if (child) child.kill(sig);
    setTimeout(() => process.exit(0), 1500).unref();
  });
}

start();
