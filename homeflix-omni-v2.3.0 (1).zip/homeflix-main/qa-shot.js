'use strict';
/* QA harness: headless Chrome via CDP (Node built-in WebSocket, zero deps).
 * Unlocks the PIN gate once, then captures screenshots of every route at
 * desktop / tablet / phone sizes. Usage: node qa-shot.js [baseUrl]
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9223;
const BASE = process.argv[2] || 'http://127.0.0.1:8200';
const OUT = 'C:/Users/MOM/AppData/Local/Temp/opencode/qa';

const SHOTS = [
  { name: 'home-1440', url: '/?qa=guest#/', w: 1440, h: 900, settle: 6000 },
  { name: 'home-768', url: '/?qa=guest#/', w: 768, h: 1024, settle: 4500 },
  { name: 'home-390', url: '/?qa=guest#/', w: 390, h: 844, settle: 4500 },
  { name: 'live-1440', url: '/?qa=guest#/live', w: 1440, h: 900, settle: 7000 },
  { name: 'live-768', url: '/?qa=guest#/live', w: 768, h: 1024, settle: 6000 },
  { name: 'live-390', url: '/?qa=guest#/live', w: 390, h: 844, settle: 6000 },
  { name: 'radio-1440', url: '/?qa=guest#/radio', w: 1440, h: 900, settle: 7000 },
  { name: 'radio-390', url: '/?qa=guest#/radio', w: 390, h: 844, settle: 6000 },
  { name: 'search-1440', url: '/?qa=guest#/search/action', w: 1440, h: 900, settle: 5000 },
  { name: 'search-390', url: '/?qa=guest#/search/action', w: 390, h: 844, settle: 4500 },
  { name: 'watch-movie-1440', url: '/?qa=guest#/watch/movie/550', w: 1440, h: 900, settle: 7000 },
  { name: 'mylist-390', url: '/?qa=guest#/mylist', w: 390, h: 844, settle: 4500 }
];

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function getJson(u, opt) {
  let lastErr;
  for (let i = 0; i < 5; i++) { // server auto-reloads on edits — retry through blips
    try {
      const res = await fetch(u, opt);
      return { status: res.status, headers: res.headers, data: await res.text() };
    } catch (e) { lastErr = e; await new Promise((r) => setTimeout(r, 1200 * (i + 1))); }
  }
  throw lastErr;
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  // 1) unlock the gate with the shared PIN, capture the session cookie
  const unlock = await getJson(BASE + '/api/gate/unlock', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: '2026' })
  });
  const setc = unlock.headers.get('set-cookie') || '';
  const m = /hf_auth=([^;]+)/.exec(setc);
  if (!m) { console.error('unlock failed:', unlock.status, unlock.data.slice(0, 120)); process.exit(1); }
  const token = m[1];
  console.log('gate unlocked, token len', token.length);

  // 2) launch headless chrome with a debug port
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'hf-qa-'));
  const chrome = spawn(CHROME, [
    '--headless=new', '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check',
    '--disable-gpu', '--window-size=1440,900', '--hide-scrollbars', 'about:blank'
  ], { stdio: ['ignore', 'ignore', 'pipe'] });
  chrome.stderr.on('data', () => {});
  let wsUrl = null;
  for (let i = 0; i < 40; i++) {
    await wait(250);
    try {
      const v = await getJson('http://127.0.0.1:' + PORT + '/json/version');
      if (v.status === 200) { wsUrl = JSON.parse(v.data).webSocketDebuggerUrl; break; }
    } catch (_) {}
  }
  if (!wsUrl) { console.error('chrome did not expose CDP'); process.exit(1); }

  // 3) open a page target and drive it over CDP
  const created = await getJson('http://127.0.0.1:' + PORT + '/json/new?about:blank', { method: 'PUT' });
  const target = JSON.parse(created.data);
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((ok, bad) => { ws.onopen = ok; ws.onerror = bad; });

  let msgId = 0;
  const pending = new Map();
  const events = [];
  ws.onmessage = (ev) => {
    const d = JSON.parse(ev.data);
    if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); }
    else if (d.method) events.push(d.method);
  };
  const send = (method, params) => new Promise((resolve) => {
    const id = ++msgId;
    pending.set(id, resolve);
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
  const waitFor = (method, timeout) => new Promise((resolve) => {
    const t0 = Date.now();
    const iv = setInterval(() => {
      const i = events.indexOf(method);
      if (i !== -1) { events.splice(0, i + 1); clearInterval(iv); resolve(true); }
      else if (Date.now() - t0 > timeout) { clearInterval(iv); resolve(false); }
    }, 60);
  });

  await send('Network.enable');
  await send('Page.enable');
  await send('Network.setCookie', { name: 'hf_auth', value: token, url: BASE, httpOnly: true });
  await send('Runtime.enable');

  for (const s of SHOTS) {
    events.length = 0;
    await send('Emulation.setDeviceMetricsOverride', {
      width: s.w, height: s.h, deviceScaleFactor: s.w <= 768 ? 2 : 1, mobile: !!s.mobile
    });
    await send('Page.navigate', { url: BASE + s.url });
    const loaded = await waitFor('Page.loadEventFired', 20000);
    await wait(s.settle);
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    if (shot.result && shot.result.data) {
      fs.writeFileSync(path.join(OUT, s.name + '.png'), Buffer.from(shot.result.data, 'base64'));
      console.log(`shot ${s.name} (${s.w}x${s.h}) load=${loaded ? 'ok' : 'timeout'} -> ${s.name}.png`);
    } else console.error('shot failed', s.name, JSON.stringify(shot).slice(0, 160));
  }
  ws.close();
  try { chrome.kill(); } catch (_) {}
  process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
