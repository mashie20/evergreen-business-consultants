'use strict';
/*
 * Homeflix server — zero-dependency Node.js (>= 20).
 *
 *  - Serves the Netflix-style SPA from /public
 *  - Keyless metadata API backed by catalog.js (TMDB daily exports + TVMaze)
 *  - Optional PIN gate (APP_PIN) for safely sharing the link with friends
 *  - gzip + ETag static serving, security headers, rate limiting,
 *    health endpoint for Docker HEALTHCHECK, graceful shutdown
 */

const http = require('http');
const https = require('https');
const dns = require('dns').promises;
const net = require('net');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const child_process = require('child_process');
const catalog = require('./catalog');
const ytlib = require('./yt-lib');

const VERSION = '2.1.0';
const os = require('os');
const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || '0.0.0.0';
const APP_PIN = String(process.env.APP_PIN || '');
const ADMIN_TOKEN = String(process.env.ADMIN_TOKEN || '');
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const REQUIRE_SECURE_COOKIES = process.env.SECURE_COOKIES === '1';
function secureCookie(req) { return REQUIRE_SECURE_COOKIES || Boolean(TRUST_PROXY && String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase() === 'https'); }
function isAdmin(req) {
  if (!ADMIN_TOKEN) return false; // explicit opt-in; never make a household profile an admin
  const candidate = String(req.headers['x-homeflix-admin-token'] || '');
  const a = Buffer.from(candidate), b = Buffer.from(ADMIN_TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = catalog.DATA_DIR;
const LOG = (process.env.LOG_LEVEL || 'info') === 'info';

/* ------------------------------------------------------------- auth (PIN) */

const SECRET_FILE = path.join(DATA_DIR, 'secret.key');
function getSecret() {
  try { return fs.readFileSync(SECRET_FILE); } catch (_) {
    const s = crypto.randomBytes(32);
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(SECRET_FILE, s, { mode: 0o600 });
    } catch (_) {}
    return s;
  }
}
const AUTH_TOKEN = crypto.createHmac('sha256', getSecret()).update('homeflix-auth-v1').digest('hex');
const accounts = require('./accounts')(DATA_DIR, AUTH_TOKEN, secureCookie);

function isAuthed(req) {
  if (!APP_PIN) return true;
  const cookie = req.headers.cookie || '';
  let token = '';
  for (const part of cookie.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    if (part.slice(0, idx).trim() === 'hf_auth') { token = part.slice(idx + 1).trim(); break; }
  }
  if (!token || token.length !== AUTH_TOKEN.length) return false;
  try { return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(AUTH_TOKEN)); } catch (_) { return false; }
}

/* ------------------------------------------------------------- rate limit */

const buckets = new Map();
function allow(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now > b.reset) { buckets.set(key, { n: 1, reset: now + windowMs }); return true; }
  if (b.n >= max) return false;
  b.n++;
  return true;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (now > b.reset) buckets.delete(k);
}, 60000).unref();

function clientIp(req) {
  return (req.socket.remoteAddress || 'unknown').replace(/^::ffff:/, '');
}

/* ---------------------------------------------------------------- helpers */

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readJsonBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'SAMEORIGIN',
  'Referrer-Policy': 'same-origin',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains', // honored once served over HTTPS tunne link, no-op on plain http
  'Permissions-Policy': 'autoplay=(self), fullscreen=(self), encrypted-media=(self), picture-in-picture=(self), camera=(), microphone=(), geolocation=(), usb=(), payment=(), idle-detection=()',
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self'",
    "img-src 'self' https: data:",
    "media-src 'self' https: http: blob:", // hls.js MediaSource playback uses blob: URLs // radio ICY streams are often http-only (tunnel pages auto-upgrade)
    "connect-src 'self' https: http:", // live HLS segments + radio ICY streams (hls.js fetches via XHR)
    "worker-src 'self' blob:", // hls.js runs its transmuxer in a blob-URL worker
    "frame-src 'self' https://framextv.cc https://framextv.xyz https://framextv.pro", // only the known embed mirrors
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'"
  ].join('; ')
};

/* --------------------------------------------------------------- static   */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2'
};

const staticCache = new Map(); // path -> {buf, etag, mtime, type}

function serveStatic(req, res, urlPath) {
  let rel = urlPath === '/' ? '/index.html' : urlPath;
  rel = path.posix.normalize(rel).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(PUBLIC_DIR, rel);
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); res.end('Forbidden'); return; }

  const cached = staticCache.get(rel);
  let entry = cached;
  if (!entry || entry.mtime !== safeMtime(file)) {
    try {
      const stat = fs.statSync(file);
      if (!stat.isFile()) throw new Error('not a file');
      const buf = fs.readFileSync(file);
      entry = {
        buf,
        etag: '"' + stat.mtimeMs.toString(36) + '-' + stat.size.toString(36) + '"',
        mtime: stat.mtimeMs,
        type: MIME[path.extname(file).toLowerCase()] || 'application/octet-stream'
      };
      if (staticCache.size > 50) staticCache.clear();
      staticCache.set(rel, entry);
    } catch (_) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
  }

  if (req.headers['if-none-match'] === entry.etag) {
    res.writeHead(304, { ETag: entry.etag });
    res.end();
    return;
  }

  const noCache = rel === '/index.html';
  const headers = {
    'Content-Type': entry.type,
    ETag: entry.etag,
    'Cache-Control': noCache ? 'no-cache' : 'public, max-age=86400',
    Vary: 'Accept-Encoding'
  };

  const acceptsGzip = /gzip/.test(req.headers['accept-encoding'] || '');
  const compressible = /^(text|application\/json|image\/svg)/.test(entry.type) && entry.buf.length > 1024;
  if (acceptsGzip && compressible) {
    const gz = zlib.gzipSync(entry.buf);
    headers['Content-Encoding'] = 'gzip';
    headers['Content-Length'] = gz.length;
    res.writeHead(200, headers);
    res.end(gz);
  } else {
    headers['Content-Length'] = entry.buf.length;
    res.writeHead(200, headers);
    res.end(entry.buf);
  }
}

function safeMtime(file) {
  try { return fs.statSync(file).mtimeMs; } catch (_) { return -1; }
}

/* ----------------------------------------------------------------- routes */

const routes = [
  ['GET', /^\/api\/health$/, apiHealth, true],
  ['GET', /^\/api\/discovery$/, apiDiscovery, true],
  ['POST', /^\/api\/pair\/create$/, apiPairCreate, true],
  ['POST', /^\/api\/pair\/claim$/, apiPairClaim, true],
  ['GET', /^\/api\/status$/, apiStatus, true],
  ['GET', /^\/api\/gate$/, apiGate, true],
  ['POST', /^\/api\/gate\/unlock$/, apiUnlock, true],
  ['GET', /^\/api\/auth\/profiles$/, apiAuthProfiles, false],
  ['POST', /^\/api\/auth\/register$/, apiAuthRegister, false],
  ['POST', /^\/api\/auth\/login$/, apiAuthLogin, false],
  ['POST', /^\/api\/auth\/logout$/, apiAuthLogout, false],
  ['GET', /^\/api\/auth\/me$/, apiAuthMe, false],
  ['GET', /^\/api\/user\/data$/, apiUserDataGet, false],
  ['PUT', /^\/api\/user\/data$/, apiUserDataPut, false],
  ['GET', /^\/api\/catalog\/rows$/, apiRows, false],
  ['GET', /^\/api\/catalog\/search$/, apiSearch, false],
  ['GET', /^\/api\/title\/(movie|tv)\/(\d+)$/, apiTitle, false],
  ['GET', /^\/api\/enrich\/(movie|tv)\/(\d+)$/, apiEnrich, false],
  ['GET', /^\/api\/tv\/(\d+)\/seasons$/, apiTvSeasons, false],
  ['GET', /^\/api\/tv\/(\d+)\/episodes\/(\d+)$/, apiTvEpisodes, false],
  ['GET', /^\/api\/providers$/, apiProviders, false],
  ['GET', /^\/api\/av$/, apiAv, false],
  ['GET', /^\/api\/live\/index$/, apiLiveIndex, false],
  ['GET', /^\/api\/live\/channels$/, apiLiveChannels, false],
  ['GET', /^\/api\/live\/sections$/, apiLiveSections, false],
  ['GET', /^\/api\/media$/, apiMedia, false],
  ['GET', /^\/api\/download$/, apiDownload, false],
  ['POST', /^\/api\/live\/bad$/, apiLiveBad, false],
  ['GET', /^\/api\/live\/yt\/resolve$/, apiLiveYtResolve, false],
  ['POST', /^\/api\/live\/yt\/add$/, apiLiveYtAdd, false],
  ['POST', /^\/api\/admin\/sync$/, apiSync, false]
];


/* -------------------------------------------------- LAN discovery & TV pairing */
const PAIRING_CODES = new Map(); // code -> { hostUrl, createdAt, profile }

function getLanAddresses() {
  const nets = os.networkInterfaces();
  const list = [];
  for (const name of Object.keys(nets)) {
    for (const netInfo of nets[name] || []) {
      if (netInfo.family === 'IPv4' && !netInfo.internal) {
        list.push({ interface: name, address: netInfo.address, url: `http://${netInfo.address}:${PORT}` });
      }
    }
  }
  return list;
}

function apiDiscovery(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const lan = getLanAddresses();
  const primaryUrl = lan.length > 0 ? lan[0].url : `http://localhost:${PORT}`;
  sendJson(res, 200, {
    ok: true,
    service: 'homeflix-omni',
    version: VERSION,
    hostname: os.hostname(),
    port: PORT,
    primaryUrl,
    lan,
    pairingSupported: true
  });
}

async function apiPairCreate(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const lan = getLanAddresses();
  const primaryUrl = lan.length > 0 ? lan[0].url : `http://localhost:${PORT}`;
  const code = String(crypto.randomInt(100000, 999999));
  PAIRING_CODES.set(code, {
    code,
    hostUrl: primaryUrl,
    hostname: os.hostname(),
    createdAt: Date.now()
  });
  // Cleanup expired codes (> 10 minutes)
  for (const [k, v] of PAIRING_CODES.entries()) {
    if (Date.now() - v.createdAt > 10 * 60 * 1000) PAIRING_CODES.delete(k);
  }
  sendJson(res, 200, {
    ok: true,
    code,
    expiresInSeconds: 600,
    hostUrl: primaryUrl,
    pairUrl: `${primaryUrl}/?pair=${code}`
  });
}

async function apiPairClaim(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  let body;
  try { body = await readJsonBody(req, 4096); } catch (_) { sendJson(res, 400, { error: 'Bad request' }); return; }
  const code = String(body && body.code || '').trim();
  const entry = PAIRING_CODES.get(code);
  if (!entry || Date.now() - entry.createdAt > 10 * 60 * 1000) {
    sendJson(res, 404, { error: 'Invalid or expired 6-digit pairing code' });
    return;
  }
  PAIRING_CODES.delete(code);
  sendJson(res, 200, {
    ok: true,
    hostUrl: entry.hostUrl,
    hostname: entry.hostname
  });
}

function apiHealth(req, res) {
  const s = catalog.status();
  sendJson(res, 200, { ok: true, service: 'homeflix', version: VERSION, uptime: Math.round(process.uptime()), catalog: { counts: s.counts, ready: s.ready, syncing: s.syncing } });
}

function apiStatus(req, res) {
  sendJson(res, 200, catalog.status());
}

function apiGate(req, res) {
  sendJson(res, 200, { locked: Boolean(APP_PIN), authed: isAuthed(req) });
}

async function apiUnlock(req, res) {
  if (!APP_PIN) { sendJson(res, 200, { locked: false }); return; }
  if (!allow('unlock:' + clientIp(req), 10, 15 * 60000)) {
    sendJson(res, 429, { error: 'Too many attempts. Try again later.' });
    return;
  }
  let body;
  try { body = await readJsonBody(req, 4096); } catch (_) { sendJson(res, 400, { error: 'Bad request' }); return; }
  const pin = String(body && body.pin || '');
  const okPin = pin.length === APP_PIN.length && crypto.timingSafeEqual(Buffer.from(pin), Buffer.from(APP_PIN));
  if (!okPin) { sendJson(res, 403, { error: 'Incorrect PIN' }); return; }
  res.setHeader('Set-Cookie', `hf_auth=${AUTH_TOKEN}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secureCookie(req) ? '; Secure' : ''}`);
  sendJson(res, 200, { unlocked: true });
}

/* ------------------------------------------------------------- accounts */

function apiAuthProfiles(req, res) {
  sendJson(res, 200, { profiles: accounts.profiles() });
}

async function apiAuthRegister(req, res) {
  if (!allow('register:' + clientIp(req), 10, 15 * 60000)) {
    sendJson(res, 429, { error: 'Too many attempts. Try again later.' });
    return;
  }
  let body;
  try { body = await readJsonBody(req, 8192); } catch (_) { sendJson(res, 400, { error: 'Bad request' }); return; }
  const r = accounts.register(body && body.name, body && body.password);
  if (r.error) { sendJson(res, 400, { error: r.error }); return; }
  accounts.signSession(res, r.name, r.slug);
  sendJson(res, 200, { user: r.name });
}

async function apiAuthLogin(req, res) {
  if (!allow('login:' + clientIp(req), 20, 15 * 60000)) {
    sendJson(res, 429, { error: 'Too many attempts. Try again later.' });
    return;
  }
  let body;
  try { body = await readJsonBody(req, 8192); } catch (_) { sendJson(res, 400, { error: 'Bad request' }); return; }
  const r = accounts.login(body && body.name, body && body.password);
  if (r.error) { sendJson(res, 403, { error: r.error }); return; }
  accounts.signSession(res, r.name, r.slug);
  sendJson(res, 200, { user: r.name });
}

function apiAuthLogout(req, res) {
  accounts.clearSession(res);
  sendJson(res, 200, { ok: true });
}

function apiAuthMe(req, res) {
  const u = accounts.currentUser(req);
  sendJson(res, 200, { user: u ? u.name : null });
}

function apiUserDataGet(req, res) {
  const u = accounts.currentUser(req);
  if (!u) { sendJson(res, 401, { error: 'no-user' }); return; }
  sendJson(res, 200, accounts.readUserData(u.slug));
}

async function apiUserDataPut(req, res) {
  const u = accounts.currentUser(req);
  if (!u) { sendJson(res, 401, { error: 'no-user' }); return; }
  let body;
  try { body = await readJsonBody(req, 512 * 1024); } catch (_) { sendJson(res, 413, { error: 'Payload too large' }); return; }
  const saved = accounts.writeUserData(u.slug, body);
  sendJson(res, 200, { ok: true, progress: Object.keys(saved.progress).length, list: saved.list.length });
}

function apiRows(req, res) {
  sendJson(res, 200, catalog.rows());
}

function apiSearch(req, res, params) {
  const q = params.get('q') || '';
  const type = params.get('type') === 'movie' || params.get('type') === 'tv' ? params.get('type') : '';
  const limit = Number(params.get('limit')) || 60;
  sendJson(res, 200, { query: q, results: catalog.search(q, type, limit) });
}

async function apiTitle(req, res, params, m) {
  const rec = catalog.byId(m[1], Number(m[2]));
  if (!rec) { sendJson(res, 404, { error: 'Title not found in local catalog' }); return; }
  await catalog.enrichDedup(rec); // keyless enrichment, disk-cached
  sendJson(res, 200, { title: rec, similar: catalog.similar(rec, 12) });
}

async function apiEnrich(req, res, params, m) {
  const rec = catalog.byId(m[1], Number(m[2]));
  if (!rec) { sendJson(res, 404, { error: 'Title not found' }); return; }
  await catalog.enrichDedup(rec);
  sendJson(res, 200, rec);
}

async function apiTvSeasons(req, res, params, m) {
  if (!allow('tvmaze:' + clientIp(req), 120, 60000)) { sendJson(res, 429, { error: 'Slow down' }); return; }
  try { sendJson(res, 200, await catalog.tvSeasons(Number(m[1]))); }
  catch (e) { sendJson(res, 502, { error: 'Episode lookup failed', fallback: true, seasons: [] }); }
}

async function apiTvEpisodes(req, res, params, m) {
  if (!allow('tvmaze:' + clientIp(req), 120, 60000)) { sendJson(res, 429, { error: 'Slow down' }); return; }
  try { sendJson(res, 200, await catalog.tvEpisodes(Number(m[1]), Number(m[2]))); }
  catch (e) { sendJson(res, 502, { error: 'Episode lookup failed', fallback: true, episodes: [] }); }
}

function apiSync(req, res) {
  if (!isAdmin(req)) { sendJson(res, 403, { error: 'Administrator token required' }); return; }
  catalog.startSync(true);
  sendJson(res, 200, { started: true });
}

/* -------------------------------------------------- providers / live routes */

async function apiProviders(req, res) {
  const providers = await catalog.providersList();
  sendJson(res, 200, { providers });
}

async function apiAv(req, res, params) {
  const type = params.get('type') === 'tv' ? 'tv' : 'movie';
  const id = Number(params.get('id'));
  const rec = catalog.byId(type, id);
  if (!rec) { sendJson(res, 404, { error: 'not-found' }); return; }
  const r = await catalog.probeAvail(rec, {
    season: Number(params.get('season')) || 1,
    episode: Number(params.get('episode')) || 1,
    refresh: params.get('refresh') === '1'
  });
  sendJson(res, 200, { av: r.av != null ? r.av : rec.av, via: r.via || rec.avVia || '' });
}

async function apiLiveIndex(req, res) {
  try { sendJson(res, 200, await catalog.liveIndex()); }
  catch (e) { sendJson(res, 502, { error: 'Live guide unavailable, retrying…' }); }
}

async function apiLiveChannels(req, res, params) {
  try {
    sendJson(res, 200, await catalog.liveChannels({
      kind: params.get('kind'), country: params.get('country'),
      category: params.get('category'), q: params.get('q'), id: params.get('id'),
      limit: params.get('limit'), offset: params.get('offset')
    }));
  } catch (e) {
    sendJson(res, 502, { error: 'Live guide unavailable, retrying…', channels: [] });
  }
}

async function apiLiveBad(req, res) {
  let body;
  try { body = await readJsonBody(req, 4096); } catch (_) { sendJson(res, 400, { error: 'Bad request' }); return; }
  sendJson(res, 200, await catalog.reportLiveBad(body && body.url));
}

/* --- dynamic YouTube live channels: yt-dlp resolves an official 24/7 live
 * page to a raw googlevideo HLS manifest (no embed, no platform ads) which
 * plays through /api/media with header fidelity (#h key). Resolution failures
 * come back as 502 so the player rotates / re-resolves like any dead link. */
async function apiLiveYtResolve(req, res, params) {
  const id = String(params.get('id') || '').trim();
  if (!id) { sendJson(res, 400, { error: 'id required' }); return; }
  if (!allow('ytres:' + clientIp(req), 40, 60000)) { sendJson(res, 429, { error: 'Slow down a little' }); return; }
  try {
    const r = await catalog.ytResolve(id, { fresh: params.get('fresh') === '1' });
    sendJson(res, 200, { ok: true, url: r.url, title: r.title, name: r.name });
  } catch (e) {
    sendJson(res, 502, { ok: false, error: (e && e.message) || 'live resolution failed', code: (e && e.code) || '' });
  }
}

async function apiLiveYtAdd(req, res) {
  let body;
  try { body = await readJsonBody(req, 8192); } catch (_) { sendJson(res, 400, { error: 'Bad request' }); return; }
  if (!allow('ytadd:' + clientIp(req), 10, 15 * 60000)) { sendJson(res, 429, { error: 'Too many adds. Try again later.' }); return; }
  const out = catalog.ytAdd(body && body.url, body && body.n);
  sendJson(res, out.ok ? 200 : 400, out);
}

async function apiLiveSections(req, res, params) {
  try { sendJson(res, 200, await catalog.liveSections({
    kind: params.get('kind'), category: params.get('category'), q: params.get('q'),
    limit: params.get('limit')
  })); }
  catch (e) { sendJson(res, 502, { error: 'Live guide unavailable, retrying…', sections: [] }); }
}

/* --------------------------------------------------------------- media proxy
 * Core of the "channels actually work" guarantee. Browsers block:
 *   - http:// streams on our https:// tunnel pages (mixed content)
 *   - cross-origin HLS playlists without CORS headers (desktop Chrome/Edge
 *     fetch segments via XHR — no CORS, no playback; iptv-org links often
 *     have neither)
 * This endpoint streams media through our own origin, transparently solving
 * both, and rewrites HLS playlists so every referenced segment/sub-playlist
 * is proxied too. Zero deps: raw http/https piping with Range passthrough. */

// SSRF shield: tunneled visitors are untrusted, so the proxy refuses to open
// anything pointed at our own host's private networks or the cloud-imposed
// metadata endpoints. Pure-internet streaming media is unaffected. Set
// MEDIA_ALLOW_PRIVATE=1 if you intentionally serve LAN IPTV through it.
const MEDIA_ALLOW_PRIVATE = String(process.env.MEDIA_ALLOW_PRIVATE || '') === '1';
const privateRanges = new net.BlockList();
for (const [base, prefix, family] of [
  ['0.0.0.0', 8, 'ipv4'], ['10.0.0.0', 8, 'ipv4'],
  ['100.64.0.0', 10, 'ipv4'], ['127.0.0.0', 8, 'ipv4'],
  ['169.254.0.0', 16, 'ipv4'], ['172.16.0.0', 12, 'ipv4'],
  ['192.0.0.0', 24, 'ipv4'], ['192.0.2.0', 24, 'ipv4'],
  ['192.168.0.0', 16, 'ipv4'], ['198.18.0.0', 15, 'ipv4'],
  ['198.51.100.0', 24, 'ipv4'], ['203.0.113.0', 24, 'ipv4'],
  ['224.0.0.0', 4, 'ipv4'], ['240.0.0.0', 4, 'ipv4'],
  ['::', 128, 'ipv6'], ['::1', 128, 'ipv6'],
  ['fc00::', 7, 'ipv6'], ['fe80::', 10, 'ipv6'],
  ['ff00::', 8, 'ipv6'], ['2001:db8::', 32, 'ipv6']
]) privateRanges.addSubnet(base, prefix, family);
function blockedAddress(address) {
  const ip = String(address).replace(/^\[|\]$/g, '').split('%')[0];
  const family = net.isIP(ip);
  if (!family) return true;
  // IPv4-mapped IPv6 must be classified against the IPv4 ranges too.
  if (family === 6 && ip.toLowerCase().startsWith('::ffff:')) {
    const tail = ip.slice(7);
    if (net.isIP(tail) === 4) return privateRanges.check(tail, 'ipv4');
  }
  // Default deny non-global IPv6 ranges (including tunnels and mapped forms).
  if (family === 6 && !MEDIA_ALLOW_PRIVATE) return true;
  return privateRanges.check(ip, family === 4 ? 'ipv4' : 'ipv6');
}
async function resolveSafe(u) {
  if (!/^https?:$/.test(u.protocol) || u.username || u.password) throw new Error('blocked URL');
  if (/^(?:localhost|metadata\.google\.internal|metadata\.|instance\.data\.)/i.test(u.hostname)) throw new Error('blocked hostname');
  const hostname = u.hostname.replace(/^\[|\]$/g, '');
  if (MEDIA_ALLOW_PRIVATE) return { hostname, address: null, family: 0 };
  const addresses = await dns.lookup(hostname, { all: true });
  if (!addresses.length || addresses.some(a => blockedAddress(a.address))) throw new Error('blocked target address');
  return { hostname, address: addresses[0].address, family: addresses[0].family };
}
async function targetBlocked(u) {
  try { await resolveSafe(u); return false; } catch (_) { return true; }
}
async function upstreamGet(startUrl, cb, depth = 0, extraHeaders) {
  if (depth > 4) { cb(null, null, new Error('too many redirects')); return; }
  let u, resolved;
  try { u = new URL(startUrl); resolved = await resolveSafe(u); }
  catch (e) { cb(null, null, e); return; }
  const mod = u.protocol === 'https:' ? https : http;
  const options = {
    hostname: resolved.hostname,
    port: u.port || (u.protocol === 'https:' ? 443 : 80),
    path: u.pathname + u.search,
    headers: Object.assign({ 'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20 (media proxy)', Accept: '*/*' }, extraHeaders || {}),
    timeout: 15000
  };
  // Pin the actual network connection to the verified DNS result.
  // The original hostname is retained for HTTP Host and TLS SNI verification.
  if (resolved.address) options.lookup = (_host, _opts, done) => done(null, resolved.address, resolved.family);
  const request = mod.get(options, (r) => {
    if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location) {
      r.resume();
      let next;
      try { next = new URL(r.headers.location, u); }
      catch (e) { cb(null, null, e); return; }
      // Every redirect is independently resolved, checked and pinned.
      upstreamGet(next.toString(), cb, depth + 1, extraHeaders).catch(e => cb(null, null, e));
      return;
    }
    cb(r, u, null);
  });
  request.on('timeout', () => request.destroy(new Error('upstream timeout')));
  request.on('error', e => cb(null, null, e));
}

function isM3u8(u, ct) {
  return /\.m3u8(\?|#|$)/i.test(u) || /mpegurl/i.test(String(ct || ''));
}

// Absolute-proxies every URI reference in an HLS playlist (segment lines,
// sub-playlist lines, and URI="" attributes on #EXT-X-KEY / #EXT-X-MAP /
// #EXT-X-MEDIA / #EXT-X-I-FRAME-STREAM-INF / #EXT-X-PART lines).
function rewritePlaylist(text, baseUrl, suffix) {
  const abs = (uri) => '/api/media?u=' + encodeURIComponent(new URL(uri, baseUrl).toString()) + (suffix || '');
  return text.split(/\r?\n/).map((line) => {
    if (!line) return line;
    if (line.startsWith('#')) return line.replace(/URI="([^"]+)"/g, (_, uri) => `URI="${abs(uri)}"`);
    return abs(line.trim());
  }).join('\n');
}

async function apiMedia(req, res, params) {
  const raw = params.get('u') || '';
  // #h=<key> rides along on resolved YouTube manifest URLs; ytHeader() yields
  // the exact UA/cookies yt-dlp used (keyed to this URL's hash) so googlevideo
  // serves us. Sub-playlist links inherit the same key via the rewrite suffix.
  const hKey = String(params.get('h') || '');
  const ytHeaders = hKey ? catalog.ytHeader(hKey) : null;
  let target;
  try { target = new URL(raw); } catch (_) { res.writeHead(400, { 'Content-Type': 'text/plain' }); res.end('bad url'); return; }
  if (!/^https?:$/.test(target.protocol)) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('bad url');
    return;
  }
  if (await targetBlocked(target)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('private network targets are not allowed');
    return;
  }
  const out = new Set(['Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Content-Disposition']);

  upstreamGet(raw, (r, baseUrl, err) => {
    if (err || !r) {
      if (!res.headersSent) { res.writeHead(502, { 'Content-Type': 'text/plain' }); res.end('upstream failed'); }
      else try { res.destroy(); } catch (_) {}
      return;
    }
    const finalUrl = baseUrl ? baseUrl.toString() : raw;
    const ct = r.headers['content-type'] || '';

    if (r.statusCode >= 400) { // pass through the failure so the player fails over
      res.writeHead(r.statusCode, { 'Content-Type': ct || 'text/plain' });
      r.pipe(res);
      return;
    }

    if (isM3u8(finalUrl, ct)) {
      let buf = '';
      let size = 0;
      r.setEncoding('utf8');
      r.on('data', (c) => { buf += c; size += c.length; if (size > 4 * 1024 * 1024) r.destroy(new Error('playlist too large')); });
      r.on('error', () => { try { res.destroy(); } catch (_) {} });
      r.on('end', () => {
        try {
          res.writeHead(200, {
            'Content-Type': 'application/vnd.apple.mpegurl',
            'Cache-Control': 'no-store',
            'Access-Control-Allow-Origin': '*'
          });
          res.end(rewritePlaylist(buf, finalUrl, hKey ? '&h=' + encodeURIComponent(hKey) : ''));
        } catch (_) { try { res.destroy(); } catch (_) {} }
      });
      return;
    }

    // binary passthrough (video segments, radio audio, everything else)
    const headers = { 'Access-Control-Allow-Origin': '*' };
    for (const h of out) if (r.headers[h.toLowerCase()]) headers[h.toLowerCase()] = r.headers[h.toLowerCase()];
    if (!headers['content-type']) headers['content-type'] = 'application/octet-stream';
    if (params.get('dl') === '1') {
      let fd = sanitizeFilename(params.get('name') || 'homeflix-download.mp4');
      if (!/\.[a-z0-9]{1,6}$/i.test(fd)) fd += '.mp4';
      headers['content-disposition'] = 'attachment; filename="' + fd + '"';
    }
    res.writeHead(r.statusCode, headers);
    r.on('error', () => { try { res.destroy(); } catch (_) {} });
    res.on('close', () => { try { r.destroy(); } catch (_) {} });
    r.pipe(res);
  }, 0, ytHeaders);
}

/* ----------------------------------------------------------- download route
 * v1.4.1 — "⬇ Download" support for catalog titles.
 * Flow: validate -> catalog lookup -> yt-dlp resolves the provider embed
 * (execFile with an ARG ARRAY — never string-built exec, ids come from the
 * request) -> choose the best PROGRESSIVE format (container runs without
 * ffmpeg, so merged HLS cannot be rebuilt) -> hand the client a proxied URL
 * (/api/media?u=…&dl=1) so the file rides our SSRF-shielded proxy with an
 * attachment Content-Disposition. HLS-only titles answer JSON-ok=false so
 * the UI shows its existing friendly fallback toast. */
const ytDlpBin = process.env.YTDLP_BIN || 'yt-dlp';
function ytDlpJsonMeta(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    child_process.execFile(ytDlpBin, ['-J', '--no-warnings', '--no-playlist', url], {
      timeout: timeoutMs,
      killSignal: 'SIGKILL',
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true
    }, (err, stdout) => {
      if (err) { reject(err); return; }
      resolve(stdout);
    });
  });
}

async function apiDownload(req, res, params) {
  const type = params.get('type') === 'tv' ? 'tv' : (params.get('type') === 'movie' ? 'movie' : '');
  if (type !== 'movie' && type !== 'tv') { sendJson(res, 400, { error: 'type must be movie or tv' }); return; }
  const id = Number(params.get('id'));
  if (!Number.isInteger(id) || id <= 0) { sendJson(res, 400, { error: 'bad id' }); return; }
  /* downloads are heavy: modest per-IP budget, media playback stays unthrottled */
  if (!allow('dl:' + clientIp(req), 6, 5 * 60000)) { sendJson(res, 429, { error: 'Download rate limit — try again in a few minutes.' }); return; }
  const rec = catalog.byId(type, id);
  if (!rec) { sendJson(res, 404, { error: 'not-found' }); return; }

  const season = Math.max(1, Number(params.get('season')) || 1);
  const episode = Math.max(1, Number(params.get('episode')) || 1);
  const embed = ytlib.providerEmbedUrl(id, type === 'tv' ? season : null, type === 'tv' ? episode : null);
  if (!embed) { sendJson(res, 400, { error: 'bad season/episode' }); return; }

  let raw = '';
  try {
    raw = await ytDlpJsonMeta(embed, 120000);
  } catch (e) {
    const missing = e && (e.code === 'ENOENT' || (e.originalError && e.originalError.code === 'ENOENT'));
    if (LOG) console.log('[hf] download resolve failed for', embed, (e && e.message) || e);
    sendJson(res, missing ? 503 : 502, { ok: false, url: null, error: missing ? 'download resolver unavailable' : 'no downloadable source found (provider may block this title)' });
    return;
  }

  let best = null;
  try { best = ytlib.pickProgressiveFormat(JSON.parse(raw)); } catch (e) {
    if (LOG) console.log('[hf] download metadata unparsable for', embed);
  }
  if (!best || !best.url) {
    sendJson(res, 200, { ok: false, url: null, error: 'HLS-only title — direct download source not available' });
    return;
  }

  const sfx = type === 'tv' ? ' S' + season + 'E' + episode : '';
  const base = sanitizeFilename('Homeflix ' + (rec.t || 'title') + (rec.y ? ' (' + rec.y + ')' : '') + sfx);
  const ext = (best.ext && /^[a-z0-9]{1,5}$/i.test(String(best.ext)) ? String(best.ext) : 'mp4');
  const url = '/api/media?u=' + encodeURIComponent(String(best.url)) + '&dl=1&name=' + encodeURIComponent(base + '.' + ext);
  sendJson(res, 200, { ok: true, url, filename: base + '.' + ext, title: rec.t });
}

/* ----------------------------------------------------------------- server */

async function handle(req, res) {
  const started = Date.now();
  const url = new URL(req.url, 'http://x');
  const pathName = decodeURIComponent(url.pathname);

  for (const k of Object.keys(SECURITY_HEADERS)) res.setHeader(k, SECURITY_HEADERS[k]);

  try {
    if (pathName.startsWith('/api/')) {
      for (const [method, re, fn, open] of routes) {
        if (req.method !== method) continue;
        const m = pathName.match(re);
        if (!m) continue;
        if (!open && !isAuthed(req)) { sendJson(res, 401, { error: 'locked' }); return; }
        await fn(req, res, url.searchParams, m);
        if (LOG) console.log(`[hf] ${req.method} ${pathName} ${res.statusCode} ${Date.now() - started}ms`);
        return;
      }
      sendJson(res, 404, { error: 'Unknown API endpoint' });
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405); res.end(); return;
    }

    if (pathName === '/favicon.ico') { res.writeHead(204); res.end(); return; }
    serveStatic(req, res, pathName);
    if (LOG) console.log(`[hf] ${req.method} ${pathName} ${res.statusCode} ${Date.now() - started}ms`);
  } catch (e) {
    console.error('[hf] error handling', pathName, e);
    if (!res.headersSent) sendJson(res, 500, { error: 'Internal error' });
    else try { res.end(); } catch (_) {}
  }
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((e) => {
    console.error('[hf] fatal handler error', e);
    try { if (!res.headersSent) { res.writeHead(500); res.end(); } } catch (_) {}
  });
});

server.listen(PORT, HOST, () => {
  console.log(`[homeflix] v${VERSION} listening on http://${HOST}:${PORT}`);
  console.log(`[homeflix] PIN protection: ${APP_PIN ? 'ENABLED' : 'off (set APP_PIN to protect a shared link)'}`);
});

function shutdown() {
  console.log('[homeflix] shutting down…');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

catalog.init();
