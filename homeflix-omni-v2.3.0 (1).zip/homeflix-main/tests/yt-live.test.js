'use strict';
/* Deterministic tests for the yt-live registry pipeline (run: node tests/yt-live.test.js) */
const test = require('node:test');
const assert = require('assert');
const lib = require('../yt-lib');

test('accepts canonical channel handle URLs', () => {
  const r = lib.normalizeYtInput('https://www.youtube.com/@AlJazeeraEnglish/live');
  assert.equal(r.ok, true);
  assert.equal(r.kind, 'channel');
  assert.equal(r.id, 'AlJazeeraEnglish');
  assert.equal(r.watchUrl, 'https://www.youtube.com/@AlJazeeraEnglish/live');
});

test('accepts /streams variant and normalizes to /live', () => {
  const r = lib.normalizeYtInput('https://youtube.com/@dwnews/streams');
  assert.equal(r.ok, true);
  assert.equal(r.watchUrl, 'https://www.youtube.com/@dwnews/live');
});

test('accepts watch + youtu.be video links', () => {
  const watch = lib.normalizeYtInput('https://www.youtube.com/watch?v=21X5lGlDOfg');
  assert.equal(watch.ok, true); assert.equal(watch.kind, 'video');
  const short = lib.normalizeYtInput('https://youtu.be/21X5lGlDOfg');
  assert.equal(short.ok, true); assert.equal(short.watchUrl, 'https://www.youtube.com/watch?v=21X5lGlDOfg');
});

test('accepts bare handles and bare video ids', () => {
  const h = lib.normalizeYtInput('@TRTWorld');
  assert.equal(h.ok, true); assert.equal(h.kind, 'channel');
  const v = lib.normalizeYtInput('21X5lGlDOfg');
  assert.equal(v.ok, true); assert.equal(v.kind, 'video');
});

test('rejects non-YouTube hosts and garbage', () => {
  assert.equal(lib.normalizeYtInput('https://vimeo.com/live').ok, false);
  assert.equal(lib.normalizeYtInput('not a url at all').ok, false);
  assert.equal(lib.normalizeYtInput('').ok, false);
  assert.equal(lib.normalizeYtInput('https://youtube.com/watch?v=shortid8').ok, false);
});

test('chanId derives a stable pseudo-id', () => {
  assert.equal(lib.chanId('https://www.youtube.com/@SkyNews/live'), 'ytl:skynews');
  assert.equal(lib.chanId('https://youtu.be/21X5lGlDOfg'), 'ytl:21x5lgldofg');
});

test('mergeRegistry dedupes and can overwrite', () => {
  const base = [{ id: 'SkyNews', watchUrl: 'a' }];
  const added = lib.mergeRegistry(base, { id: 'CNBC', watchUrl: 'b' });
  assert.equal(added.added, true);
  assert.equal(added.list.length, 2);
  const dup = lib.mergeRegistry(base, { id: 'SkyNews', watchUrl: 'z' });
  assert.equal(dup.added, false); assert.equal(dup.updated, false); assert.equal(dup.list[0].watchUrl, 'a');
  const ow = lib.mergeRegistry(base, { id: 'SkyNews', watchUrl: 'z' }, true);
  assert.equal(ow.updated, true); assert.equal(ow.list[0].watchUrl, 'z');
});

test('seed registry shape is complete', () => {
  for (const s of lib.SEED) {
    assert.ok(s.id && s.n && s.co, 'missing field in ' + JSON.stringify(s));
    assert.ok(/^https:\/\/www\.youtube\.com\/@.+\/live$/.test(s.watchUrl), 'bad watchUrl ' + s.watchUrl);
    assert.ok(Array.isArray(s.cats) && s.cats.length, 'no category');
  }
});
