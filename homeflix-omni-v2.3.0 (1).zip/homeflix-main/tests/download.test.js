'use strict';
/* Deterministic tests for the /api/download pure helpers (run: node tests/download.test.js) */
const test = require('node:test');
const assert = require('assert');
const lib = require('../yt-lib');

test('providerEmbedUrl builds pinned movie + tv embed URLs', () => {
  assert.equal(
    lib.providerEmbedUrl(550, null),
    'https://framextv.cc/embed/550'
  );
  assert.equal(
    lib.providerEmbedUrl(67232, 2, 7),
    'https://framextv.cc/embed/67232/2/7'
  );
  // movie called with season omitted explicitly
  assert.equal(lib.providerEmbedUrl(42), 'https://framextv.cc/embed/42');
});

test('providerEmbedUrl rejects garbage ids and out-of-range season/episode', () => {
  assert.equal(lib.providerEmbedUrl(-1), null);
  assert.equal(lib.providerEmbedUrl(0), null);
  assert.equal(lib.providerEmbedUrl('abc'), null); // Number('abc') NaN
  assert.equal(lib.providerEmbedUrl(NaN), null);
  assert.equal(lib.providerEmbedUrl(99999999999), null);
  assert.equal(lib.providerEmbedUrl(550, 'x', 3), null); // season NaN
  assert.equal(lib.providerEmbedUrl(550, 0, 3), null);   // season < 1
  assert.equal(lib.providerEmbedUrl(550, 1, 5000), null); // episode > 2000
  assert.equal(lib.providerEmbedUrl('', null), null);
});

test('providerEmbedUrl never emits a host other than the pinned mirrors', () => {
  const ok = lib.providerEmbedUrl(123, 1, 1);
  assert.equal(lib.PROVIDER_BASES.includes(new URL(ok).origin), true);
});

function fmt(o) {
  return Object.assign({ protocol: 'https', ext: 'mp4', vcodec: 'avc1.640028', acodec: 'mp4a.40.2', tbr: 2000 }, o);
}

test('pickProgressiveFormat prefers muxed video+audio and higher quality', () => {
  const meta = {
    formats: [
      fmt({ height: 720, tbr: 1500, filesize: 5 }, { }),
      fmt({ height: 1080, tbr: 4000, filesize: 10 }),
      fmt({ protocol: 'm3u8_native', height: 1080, tbr: 9000 }) // HLS: never downloadable here
    ]
  };
  const best = lib.pickProgressiveFormat(meta);
  assert.ok(best);
  assert.equal(best.height, 1080);
  assert.equal(best.tbr, 4000);
});

test('pickProgressiveFormat skips HLS/DASH-only formats (no ffmpeg in container)', () => {
  const meta = { formats: [fmt({ protocol: 'm3u8' }), fmt({ protocol: 'm3u8_native', ext: 'm3u8' })] };
  assert.equal(lib.pickProgressiveFormat(meta), null);
  assert.equal(lib.pickProgressiveFormat(null), null);
  assert.equal(lib.pickProgressiveFormat({ formats: [] }), null);
});

test('pickProgressiveFormat falls back to audio-only when no video format qualifies', () => {
  const meta = {
    formats: [
      Object.assign(fmt({}), { protocol: 'm3u8_native' }), // video is HLS-only
      fmt({ vcodec: 'none', acodec: 'mp3', ext: 'mp3', tbr: 128 })
    ]
  };
  const best = lib.pickProgressiveFormat(meta);
  assert.ok(best);
  assert.equal(best.vcodec, 'none');
  assert.equal(best.acodec, 'mp3');
});

test('isProgressiveFormat rejects fragmented/dash protocols and fragmented ext', () => {
  assert.equal(lib.isProgressiveFormat(fmt({})), true);
  assert.equal(lib.isProgressiveFormat(fmt({ protocol: 'm3u8' })), false);
  assert.equal(lib.isProgressiveFormat(fmt({ protocol: 'dash' })), false);
  assert.equal(lib.isProgressiveFormat(fmt({ ext: 'm3u8' })), false);
  assert.equal(lib.isProgressiveFormat(null), false);
  assert.equal(lib.isProgressiveFormat('nope'), false);
});

test('sanitizeFilename strips path, quote, and control characters', () => {
  assert.equal(lib.sanitizeFilename('Homeflix Fight Club (1999)'), 'Homeflix Fight Club (1999)');
  assert.equal(lib.sanitizeFilename('bad/name\\here:"*?<>|'), 'bad_name_here_______');
  assert.equal(lib.sanitizeFilename('a\b\u0000c'), 'ac'); // control chars are removed entirely
  assert.equal(lib.sanitizeFilename(''), 'homeflix-download');
  assert.equal(lib.sanitizeFilename(null), 'homeflix-download');
  assert.equal(lib.sanitizeFilename('../etc/passwd'), '_etc_passwd'); // / -> _, leading dots stripped
});

test('sanitizeFilename caps length and never returns dot-prefixed names', () => {
  const long = lib.sanitizeFilename('x'.repeat(300));
  assert.ok(long.length <= 100);
  assert.equal(lib.sanitizeFilename('...hidden'), 'hidden');
});
