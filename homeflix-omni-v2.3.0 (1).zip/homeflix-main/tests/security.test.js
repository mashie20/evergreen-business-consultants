'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');

async function waitForReady(port, child) {
  for (let i = 0; i < 70; i++) {
    if (child.exitCode !== null) throw new Error('server exited unexpectedly');
    try { const r = await fetch(`http://127.0.0.1:${port}/api/health`); if (r.ok) return; } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('server did not respond');
}

test('PIN does not grant admin access and proxy refuses loopback IPv4/IPv6', { timeout: 18000 }, async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hf-security-'));
  const available = net.createServer();
  const port = await new Promise((resolve, reject) => {
    available.once('error', reject);
    available.listen(0, '127.0.0.1', () => { const p = available.address().port; available.close(() => resolve(p)); });
  });
  const child = spawn(process.execPath, ['server.js'], {
    cwd: path.resolve(__dirname, '..'), stdio: 'ignore',
    env: { ...process.env, HF_DATA_DIR: tmp, HOST: '127.0.0.1', PORT: String(port),
      APP_PIN: 'test-pin', ADMIN_TOKEN: 'test-admin-key', LOG_LEVEL: 'quiet' }
  });
  try {
    await waitForReady(port, child);
    const base = `http://127.0.0.1:${port}`;
    const unlock = await fetch(base + '/api/gate/unlock', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: 'test-pin' }) });
    assert.equal(unlock.status, 200);
    const cookie = unlock.headers.get('set-cookie').split(';')[0];
    const forbidden = await fetch(base + '/api/admin/sync', { method: 'POST', headers: { Cookie: cookie } });
    assert.equal(forbidden.status, 403);
    for (const target of ['http://127.0.0.1:80/', 'http://[::1]:80/']) {
      const res = await fetch(base + '/api/media?u=' + encodeURIComponent(target), { headers: { Cookie: cookie } });
      assert.equal(res.status, 403);
    }
    const badProto = await fetch(base + '/api/media?u=' + encodeURIComponent('file:///etc/passwd'), { headers: { Cookie: cookie } });
    assert.equal(badProto.status, 400);
  } finally {
    child.kill();
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});
