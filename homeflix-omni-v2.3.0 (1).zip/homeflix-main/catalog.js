'use strict';
/*
 * Homeflix catalog engine v2 — keyless, local-first.
 *
 * Backbone: TMDB public daily export files (files.tmdb.org — free CDN, no API key).
 *   These are ID lists: {adult, id, original_title/name, popularity}. We keep the
 *   popular slice (~100k movies + ~60k shows) fully searchable in local memory.
 *
 * Enrichment (all keyless, cached to disk in data/enrich/):
 *   - IMDb suggestion API  -> poster art, year, cast
 *   - Wikipedia REST API   -> movie synopses (+ genre keywords from the text)
 *   - TVMaze               -> TV synopses, genres, ratings, full episode lists
 *
 * Playback: every record carries its real TMDB id, which is exactly what the
 * frameXTV embed URLs expect. No external metadata API is ever required.
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn } = require('child_process');
const ytlib = require('./yt-lib');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const ROOT = __dirname;
const DATA_DIR = process.env.HF_DATA_DIR || path.join(ROOT, 'data');
const CATALOG_FILE = path.join(DATA_DIR, 'catalog.json');
const EXPORT_DIR = path.join(DATA_DIR, 'exports');
const ENRICH_DIR = path.join(DATA_DIR, 'enrich');
const TVMAZE_DIR = path.join(DATA_DIR, 'tvmaze');
const FXTV_DIR = path.join(DATA_DIR, 'fxtv');
const AV_DIR = path.join(DATA_DIR, 'av');
const IPTV_FILE = path.join(DATA_DIR, 'iptv.json');
const SEED_FILE = path.join(ROOT, 'seed.json');
const STATE_FILE = path.join(DATA_DIR, 'sync.state.json');

// frameXTV backend (same service that powers the embeds — keyless, mirrors fail over)
const FXTV_BASES = ['https://api.framextv.tech', 'https://api.framextv.cc', 'https://api.framextv.xyz', 'https://api.framextv.pro'];
let FXTV_API = null;

// Keyless live-TV source (community-maintained m3u indexes)
const IPTV_SOURCES = [
  ['Sports', 'https://iptv-org.github.io/iptv/categories/sports.m3u'],
  ['Movies', 'https://iptv-org.github.io/iptv/categories/movies.m3u'],
  ['News', 'https://iptv-org.github.io/iptv/categories/news.m3u'],
  ['Documentary', 'https://iptv-org.github.io/iptv/categories/documentary.m3u'],
  ['Kids', 'https://iptv-org.github.io/iptv/categories/kids.m3u'],
  ['Music', 'https://iptv-org.github.io/iptv/categories/music.m3u'],
  ['Entertainment', 'https://iptv-org.github.io/iptv/categories/entertainment.m3u'],
  ['US', 'https://iptv-org.github.io/iptv/countries/us.m3u'],
  ['UK', 'https://iptv-org.github.io/iptv/countries/uk.m3u']
];

const REFRESH_HOURS = Number(process.env.CATALOG_REFRESH_HOURS || 72);
const MAX_MOVIES = Number(process.env.CATALOG_MAX_MOVIES || 100000);
const MAX_TV = Number(process.env.CATALOG_MAX_TV || 60000);
const ENRICH_TOP = Number(process.env.CATALOG_ENRICH_TOP || 1200);
const MIN_POP_MOVIE = Number(process.env.CATALOG_MIN_POP_MOVIE || 2);
const MIN_POP_TV = Number(process.env.CATALOG_MIN_POP_TV || 2);

const DOWNLOAD_TIMEOUT_MS = 240000;
const API_TIMEOUT_MS = 10000;
const DAY = 86400000;
const ENRICH_TTL = 30 * DAY;
const FXTV_TTL = 7 * DAY;
const AV_TTL = 7 * DAY;
const AV_NEG_TTL = 2 * DAY;
const ENRICH_PARALLEL = 6;
const UA = { 'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20 (self-hosted; personal use)' };

const GENRE_KEYWORDS = [
  [/science[- ]fiction|sci-fi/i, 'Sci-Fi'],
  [/superhero/i, 'Action'],
  [/\bhorror\b/i, 'Horror'],
  [/\bcomedy|comédie/i, 'Comedy'],
  [/\baction\b/i, 'Action'],
  [/\badventure\b/i, 'Adventure'],
  [/\banimated|animation/i, 'Animation'],
  [/\bdocumentary/i, 'Documentary'],
  [/\bthriller/i, 'Thriller'],
  [/\bromantic|romance/i, 'Romance'],
  [/\bcrime\b/i, 'Crime'],
  [/\bfantasy\b/i, 'Fantasy'],
  [/\bmystery/i, 'Mystery'],
  [/\bwestern/i, 'Western'],
  [/\bwar\b/i, 'War'],
  [/\bdrama\b/i, 'Drama'],
  [/\bmusical/i, 'Music'],
  [/\bfamily/i, 'Family'],
  [/\bhistorical|\bhistory\b/i, 'History'],
  [/\bbiographical|biopic/i, 'Biography'],
  [/\bsports?\b/i, 'Sport'],
  [/\bsupernatural/i, 'Supernatural'],
  [/\bsitcom/i, 'Comedy']
];

/* ------------------------------------------------- shared fetch + failover */

async function fetchJson(url, timeoutMs) {
  const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs || API_TIMEOUT_MS), headers: UA });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return res.json();
}

// Sticky, self-healing mirror selection: whichever frameXTV API mirror answers
// becomes preferred; failed mirrors earn a cooldown and are re-tried later, so
// a backend move or outage never breaks metadata or availability endpoints.
const FXTV_HEALTH = new Map(); // base -> cooldownUntil
function fxtvBases() {
  const now = Date.now();
  const healthy = FXTV_BASES.filter((b) => !FXTV_HEALTH.get(b) || FXTV_HEALTH.get(b) < now);
  const list = FXTV_API && healthy.includes(FXTV_API)
    ? [FXTV_API, ...healthy.filter((b) => b !== FXTV_API)]
    : healthy.concat(FXTV_BASES.filter((b) => !healthy.includes(b)));
  return list.length ? list : FXTV_BASES;
}

async function fxtvFetch(apiPath, timeoutMs) {
  let lastErr;
  for (const base of fxtvBases()) {
    try {
      const j = await fetchJson(base + apiPath, timeoutMs);
      if (FXTV_API !== base) console.log(`[homeflix] fxtv api base -> ${base}`);
      FXTV_API = base;
      FXTV_HEALTH.delete(base);
      return j;
    } catch (e) {
      lastErr = e;
      FXTV_HEALTH.set(base, Date.now() + 60000);
    }
  }
  throw lastErr || new Error('fxtv api unreachable');
}

const isBusy = (j) => j && (j.code === 'busy' || /busy/i.test(String(j.error || '')));

/* ---------------------------------------------------- genre/origin labels */

function normGenre(g) {
  const k = String(g || '').toLowerCase().trim();
  if (!k) return '';
  if (k === 'science fiction' || k === 'science-fiction' || k === 'sci-fi' || k === 'scifi') return 'Sci-Fi';
  if (k === 'musical') return 'Music';
  if (k === 'anime') return 'Animation';
  return String(g).trim();
}

// TVMaze webChannel/network -> friendly streamer label for origin rows.
function originLabel(name) {
  const s = String(name || '').toLowerCase();
  if (!s) return '';
  if (/netflix/.test(s)) return 'Netflix';
  if (/prime|amazon/.test(s)) return 'Prime Video';
  if (/hbo|cinemax|\bmax\b/.test(s)) return 'HBO Max';
  if (/hulu/.test(s)) return 'Hulu';
  if (/paramount/.test(s)) return 'Paramount+';
  if (/disney/.test(s)) return 'Disney+';
  if (/apple/.test(s)) return 'Apple TV+';
  if (/peacock/.test(s)) return 'Peacock';
  if (/bbc|cbeebies/.test(s)) return 'BBC';
  return '';
}

/* ------------------------------------------------------- provider registry */

const PROVIDERS_TTL = 6 * 3600000;
const PROVIDER_ORDER = ['titan', 'sparky', 'super_barbarian', 'giant', 'battle_copter', 'executioner', 'root_rider', 'archer_queen', 'bowler'];
let providersMem = null;
let providersRefresh = null;

function readProvidersCache() {
  if (providersMem && Date.now() - providersMem.at < PROVIDERS_TTL) return providersMem.providers;
  if (!providersMem) {
    try { providersMem = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'fxtv-providers.json'), 'utf8')); }
    catch (_) { providersMem = null; }
  }
  return providersMem && providersMem.providers ? providersMem.providers : null;
}

// Stale-while-revalidate: always answers instantly from cache and refreshes in
// the background, so a slow or relocated backend never blocks or breaks the UI.
async function providersList() {
  const cached = readProvidersCache();
  const fresh = cached && providersMem && Date.now() - providersMem.at < PROVIDERS_TTL;
  if (!fresh && !providersRefresh) {
    providersRefresh = (async () => {
      try {
        const j = await fxtvFetch('/api/providers', 15000);
        const list = (j.providers || []).filter((p) => p.status === 'available')
          .map((p) => ({ id: p.id, name: p.name, tagline: p.tagline || '' }));
        list.sort((a, b) => {
          const ia = PROVIDER_ORDER.indexOf(a.id), ib = PROVIDER_ORDER.indexOf(b.id);
          return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
        });
        if (list.length) {
          providersMem = { at: Date.now(), providers: list };
          try { fs.writeFileSync(path.join(DATA_DIR, 'fxtv-providers.json'), JSON.stringify(providersMem)); } catch (_) {}
        }
      } catch (_) { /* keep serving stale cache */ }
    })().finally(() => { providersRefresh = null; });
  }
  if (cached && cached.length) return cached;
  await providersRefresh;
  return providersMem && providersMem.providers ? providersMem.providers : [];
}

/* ------------------------------------------------ frameXTV native metadata */

function fxtvMetaFile(type, id) { return path.join(FXTV_DIR, type, `${id}.json`); }

// Year / genres / poster / backdrop straight from the frameXTV backend —
// always in sync with what the embeds can actually play. Cached 7d; rate-limit
// ("busy") answers are never cached so nothing gets poisoned.
async function fxtvMeta(type, id) {
  const cf = fxtvMetaFile(type, id);
  try {
    const j = JSON.parse(fs.readFileSync(cf, 'utf8'));
    if (j.ok && Date.now() - j.at < FXTV_TTL) return j;
    if (!j.ok && Date.now() - j.at < (j.busy ? 30 * 60000 : 2 * DAY)) return j;
  } catch (_) {}
  let out;
  try {
    let q = `/api/meta?id=${id}&type=${type}`;
    if (type === 'tv') q += '&season=1&episode=1';
    const j = await fxtvFetch(q, 15000);
    if (j && j.success) {
      const raw = String(j.title || '');
      const m = raw.match(/^(.*?)\s*\((\d{4})\)/);
      const t = (m ? m[1] : raw.replace(/—\s*S\d+E\d+.*$/, '')).trim();
      const y = m ? Number(m[2]) : Number(String(j.year || '').slice(0, 4)) || 0;
      out = { ok: true, at: Date.now(), t, y, g: (Array.isArray(j.genres) ? j.genres : []).map(normGenre), p: j.poster || null, b: j.backdrop || null };
    } else if (isBusy(j)) {
      return { ok: false, busy: true, at: Date.now() };
    } else {
      out = { ok: false, at: Date.now() };
    }
  } catch (_) {
    return { ok: false, at: Date.now() }; // transient network issue — retry later
  }
  try { fs.writeFileSync(cf, JSON.stringify(out)); } catch (_) {}
  return out;
}

/* ------------------------------------------------ availability self-healing */

function avFile(type, id) { return path.join(AV_DIR, type, `${id}.json`); }

function readAv(type, id) {
  try {
    const j = JSON.parse(fs.readFileSync(avFile(type, id), 'utf8'));
    const ttl = j.av === 1 ? AV_TTL : j.av === 0 ? AV_NEG_TTL : 12 * 3600000;
    if (Date.now() - j.at < ttl) return j;
  } catch (_) {}
  return null;
}

// Rotates every healthy provider until one confirms the title plays.
// "busy" (rate budget) answers never mark a title dead — the probe keeps
// rotating; an all-busy sweep is cached as "unknown" for a short TTL only.
async function probeAvail(rec, opts) {
  if (!rec || !rec.id) return { av: null };
  const type = rec.type, id = rec.id;
  if (!opts || !opts.refresh) {
    const c = readAv(type, id);
    if (c) { rec.av = c.av; rec.avVia = c.via || ''; return c; }
  }
  const providers = await providersList();
  if (!providers.length) return { av: rec.av != null ? rec.av : null };
  let av = 0, via = '', sawBusy = false;
  for (const p of providers) {
    let q = `/api/stream/check?id=${id}&type=${type}&provider=${p.id}`;
    if (type === 'tv') q += `&season=${(opts && opts.season) || 1}&episode=${(opts && opts.episode) || 1}`;
    try {
      const j = await fxtvFetch(q, 20000);
      if (j && j.available) { av = 1; via = p.id; break; }
      if (isBusy(j)) sawBusy = true;
    } catch (_) { sawBusy = true; }
  }
  av = av || (sawBusy ? -1 : 0);
  const out = { at: Date.now(), av, via, type };
  rec.av = av;
  rec.avVia = via;
  try { fs.writeFileSync(avFile(type, id), JSON.stringify(out)); } catch (_) {}
  return out;
}

/* ------------------------------------------------------------------ state */

let C = { movies: [], tv: [], builtAt: 0, fromSeed: true, seedCount: 0 };
let BY_ID = new Map();
let SEARCH_IDX = [];
let ROWS_CACHE = null;
let SEEDS = [];

const sync = { running: false, phase: '', error: '', startedAt: 0, lastSync: 0, progress: '' };
const inflightEnrich = new Map();

function ensureDirs() {
  for (const d of [DATA_DIR, EXPORT_DIR, ENRICH_DIR, TVMAZE_DIR, FXTV_DIR, AV_DIR,
    path.join(ENRICH_DIR, 'movie'), path.join(ENRICH_DIR, 'tv'),
    path.join(FXTV_DIR, 'movie'), path.join(FXTV_DIR, 'tv'),
    path.join(AV_DIR, 'movie'), path.join(AV_DIR, 'tv')]) {
    fs.mkdirSync(d, { recursive: true });
  }
}

function loadSeeds() {
  try {
    SEEDS = JSON.parse(fs.readFileSync(SEED_FILE, 'utf8'));
    if (!Array.isArray(SEEDS)) SEEDS = [];
  } catch (_) { SEEDS = []; }
}

function normalize(r, type) {
  return {
    id: Number(r.id) || 0,
    type,
    t: String(r.t || r.title || r.name || '').slice(0, 160),
    y: Number(r.y || r.year || 0) || 0,
    rd: String(r.rd || '').slice(0, 10), // exact/partial release date: "YYYY-MM-DD" or "YYYY-MM"
    d: String(r.d || r.overview || '').replace(/\s+/g, ' ').trim().slice(0, 600),
    p: r.p || r.poster_path || null,
    b: r.b || r.backdrop_path || null,
    o: r.o || r.origin || null,
    av: r.av == null ? null : Number(r.av) | 0,
    g: Array.isArray(r.g) ? r.g.map(String).filter(Boolean) : [],
    v: Number(r.v || r.rating || 0) || 0,
    stars: String(r.stars || '').slice(0, 160),
    imdb: r.imdb || null,
    pop: Number(r.pop != null ? r.pop : r.popularity) || 0
  };
}

function indexCatalog() {
  BY_ID = new Map();
  SEARCH_IDX = [];
  ROWS_CACHE = null;
  const push = (r) => {
    if (!r.id || !r.t) return;
    BY_ID.set(r.type + ':' + r.id, r);
    SEARCH_IDX.push({ lt: normTitle(r.t), gt: normTitle((r.g || []).join(' ')), r });
  };
  for (const r of C.movies) push(r);
  for (const r of C.tv) push(r);
}

function loadCatalogFromDisk() {
  try {
    const j = JSON.parse(fs.readFileSync(CATALOG_FILE, 'utf8'));
    C = {
      movies: Array.isArray(j.movies) ? j.movies : [],
      tv: Array.isArray(j.tv) ? j.tv : [],
      builtAt: j.builtAt || 0,
      fromSeed: false,
      seedCount: 0
    };
    sync.lastSync = j.builtAt || 0;
  } catch (_) {
    C = seedCatalog();
  }
  indexCatalog();
}

function seedCatalog() {
  const movies = [];
  const tv = [];
  for (const s of SEEDS) {
    const rec = normalize(s, s.type);
    rec.pop = rec.pop || 1;
    if (rec.type === 'movie') movies.push(rec); else tv.push(rec);
  }
  return { movies, tv, builtAt: 0, fromSeed: true, seedCount: movies.length + tv.length };
}

/* --------------------------------------------------------------- querying */

function normTitle(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function search(q, type, limit) {
  q = String(q || '').trim().toLowerCase();
  if (!q) return [];
  limit = Math.min(Number(limit) || 60, 100);
  const nq = normTitle(q);
  const toks = nq.split(/\s+/).filter(Boolean);
  const scored = [];
  for (let i = 0; i < SEARCH_IDX.length; i++) {
    const e = SEARCH_IDX[i];
    if (type && e.r.type !== type) continue;
    let s = 0;
    if (e.lt === nq) s = 20;
    else if (e.lt.startsWith(nq)) s = 14;
    else if (e.lt.includes(nq)) s = 10;
    else {
      let ok = 0;
      for (const t of toks) if (e.lt.includes(t)) ok++;
      if (ok && ok === toks.length) s = 6;
      else if (ok) s = ok * 1.2;
    }
    // Genre matches: “horror”, “superhero movies”, “crime series”… land even
    // when the query never appears in the title.
    if (!s && e.gt && (e.gt.includes(nq) || (toks.length && toks.every((t) => e.gt.includes(t))))) s = 5;
    if (s) scored.push([s + Math.min(e.r.pop / 30, 6), e.r]);
  }
  scored.sort((a, b) => b[0] - a[0]);
  return scored.slice(0, limit).map((x) => x[1]);
}

function byId(type, id) {
  return BY_ID.get(type + ':' + id) || null;
}

function similar(rec, n) {
  const pool = rec.type === 'movie' ? C.movies : C.tv;
  const g0 = rec.g && rec.g[0];
  let out = [];
  if (g0) out = pool.filter((r) => r.id !== rec.id && r.g && r.g.includes(g0));
  if (out.length < n) {
    const have = new Set(out.map((r) => r.id));
    for (const r of pool) {
      if (out.length >= n * 2) break;
      if (r.id !== rec.id && !have.has(r.id)) out.push(r);
    }
  }
  return out.slice(0, n);
}

function interleave(a, b) {
  const out = [];
  const max = Math.max(a.length, b.length);
  for (let i = 0; i < max; i++) {
    if (i < a.length) out.push(a[i]);
    if (i < b.length) out.push(b[i]);
  }
  return out;
}

const byPop = (a, b) => b.pop - a.pop;
function dedupe(items) {
  const seen = new Set();
  const out = [];
  for (const r of items) {
    const k = r.type + ':' + r.id;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(r);
  }
  return out;
}

function rows() {
  if (ROWS_CACHE) return ROWS_CACHE;
  const { movies, tv } = C;
  const all = interleave(movies, tv);
  const ok = (r) => r.p && r.av !== 0; // has art and is not confirmed-unavailable
  const withArt = all.filter(ok);
  const withArtM = movies.filter(ok);
  const withArtT = tv.filter(ok);
  const base = withArt.length >= 40 ? withArt : all;
  const baseM = withArtM.length >= 40 ? withArtM : movies;
  const baseT = withArtT.length >= 40 ? withArtT : tv;
  const nowYear = new Date().getFullYear();
  const curMonth = new Date().toISOString().slice(0, 7); // "YYYY-MM"
  const hasG = (r, name) => r.g && r.g.includes(name);
  const newest = (a, b) => String(b.rd || '').localeCompare(String(a.rd || '')) || b.y - a.y;
  const pick = (arr) => dedupe(arr).slice(0, 24);

  const staticDefs = [
    ['trending', 'Currently Trending', base.slice(0, 30)],
    ['available', 'Verified Available Now', base.filter((r) => r.av === 1)],
    ['newmonth', 'New This Month', base.filter((r) => r.rd && String(r.rd).slice(0, 7) === curMonth).sort(newest)],
    ['movies', 'Popular Movies', baseM.slice(0, 30)],
    ['tv', 'Popular TV Shows', baseT.slice(0, 30)],
    ['new', 'New on Homeflix', base.filter((r) => r.y && r.y >= nowYear - 1).sort(newest)],
    ['top', 'Critically Acclaimed', base.filter((r) => r.v >= 8).sort((a, b) => b.v - a.v)],
    ['classics', 'Modern Classics', base.filter((r) => r.y && r.y > 0 && r.y <= 2014)],
    ['2020s', 'This Decade', base.filter((r) => r.y >= 2020)],
    ['action', 'Action & Adventure', base.filter((r) => hasG(r, 'Action') || hasG(r, 'Adventure'))],
    ['comedy', 'Comedies', base.filter((r) => hasG(r, 'Comedy'))],
    ['scifi', 'Sci-Fi & Fantasy', base.filter((r) => hasG(r, 'Sci-Fi') || hasG(r, 'Fantasy'))],
    ['animation', 'Animation & Anime', base.filter((r) => hasG(r, 'Animation'))],
    ['crime', 'Crime, Thriller & Mystery', base.filter((r) => hasG(r, 'Crime') || hasG(r, 'Thriller') || hasG(r, 'Mystery'))],
    ['horror', 'Horror', base.filter((r) => hasG(r, 'Horror'))],
    ['romance', 'Romance', base.filter((r) => hasG(r, 'Romance'))],
    ['drama', 'Dramas', base.filter((r) => hasG(r, 'Drama'))],
    ['documentary', 'Documentaries', base.filter((r) => hasG(r, 'Documentary'))]
  ];
  const rows = [];
  const usedKeys = new Set();
  for (const [key, title, items] of staticDefs) {
    usedKeys.add(key);
    const r = { key, title, items: pick(items) };
    if (r.items.length >= 4) rows.push(r);
  }

  // Robust genre rows: derived from the catalog's real genre distribution, so
  // newly enriched genres surface automatically as dedicated rows.
  const freq = new Map();
  for (const r of withArt) for (const g of r.g || []) freq.set(g, (freq.get(g) || 0) + 1);
  const covered = new Set(['Action', 'Adventure', 'Comedy', 'Sci-Fi', 'Fantasy', 'Animation', 'Crime', 'Thriller', 'Mystery', 'Horror', 'Romance', 'Drama', 'Documentary']);
  const dynGenres = [...freq.entries()]
    .filter(([g, n]) => n >= 60 && !covered.has(g))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);
  for (const [g] of dynGenres) {
    const key = 'g:' + g.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    if (usedKeys.has(key)) continue;
    usedKeys.add(key);
    const r = { key, title: g, items: pick(withArt.filter((x) => x.g && x.g.includes(g))) };
    if (r.items.length >= 4) rows.push(r);
  }

  // Origin rows (Netflix / Hulu / HBO Max / Paramount+ …) from TVMaze channel data.
  const ORIGINS = ['Netflix', 'Prime Video', 'HBO Max', 'Hulu', 'Paramount+', 'Disney+', 'Apple TV+', 'Peacock', 'BBC'];
  for (const label of ORIGINS) {
    const items = tv.filter((r) => r.o === label);
    if (items.length < 5) continue;
    const key = 'origin:' + label.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    if (usedKeys.has(key)) continue;
    usedKeys.add(key);
    rows.push({ key, title: `${label} Originals`, items: pick(items) });
  }

  // Featured hero: prefer verified-available titles when we have enough.
  let featuredPool = base.filter((r) => r.d && r.p);
  const avPool = featuredPool.filter((r) => r.av === 1);
  if (avPool.length >= 12) featuredPool = avPool;
  const dayIdx = Math.floor(Date.now() / DAY);
  let featured = featuredPool.slice().sort((a, b) => b.pop - a.pop).slice(0, 12);
  if (featured.length) featured = featured.slice(dayIdx % featured.length).concat(featured.slice(0, dayIdx % featured.length));

  ROWS_CACHE = { featured, rows, generatedAt: Date.now() };
  return ROWS_CACHE;
}

function status() {
  const enriched = (C.movies.filter((r) => r.p).length) + (C.tv.filter((r) => r.p).length);
  const available = (C.movies.filter((r) => r.av === 1).length) + (C.tv.filter((r) => r.av === 1).length);
  return {
    ready: !C.fromSeed || C.movies.length + C.tv.length > 0,
    fromSeed: C.fromSeed,
    counts: { movies: C.movies.length, tv: C.tv.length, total: C.movies.length + C.tv.length },
    enriched,
    available,
    builtAt: C.builtAt,
    syncing: sync.running,
    phase: sync.phase,
    progress: sync.progress,
    error: sync.error,
    lastSync: sync.lastSync,
    refreshHours: REFRESH_HOURS
  };
}

/* ------------------------------------------------------------ daily export */

function exportName(base, d) {
  const p = (x) => String(x).padStart(2, '0');
  return `${base}_${p(d.getMonth() + 1)}_${p(d.getDate())}_${d.getFullYear()}.json.gz`;
}

async function downloadExport(base) {
  for (let i = 0; i < 8; i++) {
    const d = new Date(Date.now() - i * DAY);
    const name = exportName(base, d);
    const dest = path.join(EXPORT_DIR, name);
    if (fs.existsSync(dest) && fs.statSync(dest).size > 100000) return { file: dest, date: name };
    try {
      const res = await fetch(`https://files.tmdb.org/p/exports/${name}`, { signal: AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS) });
      if (!res.ok) continue;
      const tmp = dest + '.part';
      await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(tmp));
      fs.renameSync(tmp, dest);
      return { file: dest, date: name };
    } catch (e) {
      try { fs.unlinkSync(dest + '.part'); } catch (_) {}
      if (i === 7) throw new Error(`export download failed: ${e.message}`);
    }
  }
  throw new Error(`no ${base} export found in the last 8 days`);
}

function readGzipLines(file, onLine) {
  return new Promise((resolve, reject) => {
    const gz = zlib.createGunzip();
    let buf = '';
    let ok = true;
    gz.on('error', reject);
    gz.on('data', (ch) => {
      buf += ch.toString('utf8');
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl);
        buf = buf.slice(nl + 1);
        if (line.trim()) onLine(line);
      }
      if (buf.length > 4194304) { ok = false; gz.destroy(new Error('line buffer overflow')); }
    });
    gz.on('end', () => { if (ok && buf.trim()) onLine(buf); resolve(); });
    fs.createReadStream(file).pipe(gz);
  });
}

async function parseExport(file, type) {
  const sink = [];
  await readGzipLines(file, (line) => {
    let j;
    try { j = JSON.parse(line); } catch (_) { return; }
    if (!j || j.adult) return;
    const pop = Number(j.popularity) || 0;
    if (type === 'movie') {
      if (j.video) return;
      if (pop < MIN_POP_MOVIE) return;
      sink.push(normalize({ id: j.id, t: j.original_title, pop }, 'movie'));
    } else {
      if (pop < MIN_POP_TV) return;
      sink.push(normalize({ id: j.id, t: j.name || j.original_name, pop }, 'tv'));
    }
  });
  return sink;
}

/* ----------------------------------------------------- keyless enrichment */

function genresFromText(text) {
  const out = [];
  for (const [re, name] of GENRE_KEYWORDS) {
    if (re.test(text) && !out.includes(name)) out.push(name);
    if (out.length >= 4) break;
  }
  return out;
}

async function imdbSuggest(title, wantedType) {
  const t = String(title || '').trim();
  if (!t) return null;
  const first = encodeURIComponent(Array.from(t)[0].toLowerCase());
  const url = `https://v3.sg.media-imdb.com/suggestion/${first}/${encodeURIComponent(t)}.json`;
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(API_TIMEOUT_MS), headers: UA });
    if (!res.ok) return null;
    const j = await res.json();
    const items = (j && j.d) || [];
    const ltq = normTitle(t);
    let best = null;
    let bestScore = 0;
    for (const it of items) {
      if (!it || !it.l || !it.i || !it.id) continue;
      const lt = normTitle(it.l);
      let s = 0;
      if (lt === ltq) s = 12;
      else if (lt.startsWith(ltq) || ltq.startsWith(lt)) s = 5;
      if (!s) continue;
      const qid = String(it.qid || '').toLowerCase();
      const q = String(it.q || '').toLowerCase();
      const isMovie = qid === 'movie' || q === 'feature' || q === 'movie';
      const isTv = qid === 'tvseries' || qid === 'tvminiseries' || q.includes('tv series');
      if (wantedType === 'movie' && isMovie) s += 6;
      else if (wantedType === 'tv' && isTv) s += 6;
      else if (wantedType === 'movie' && isTv) continue;
      else if (wantedType === 'tv' && isMovie) continue;
      if (it.y) s += 1;
      if (s > bestScore) { bestScore = s; best = it; }
    }
    return bestScore >= 10 ? best : null;
  } catch (_) { return null; }
}

// Keyless movie release dates: Wikidata keeps a dedicated TMDB-id property
// (P4947) and exact publication dates (P577), and doesn't 403 datacenter IPs.
// Query by our real TMDB id — but SCORE the candidates by title, because
// several junk entities can share one TMDB id; a wrong month is worse than
// none. Returns "YYYY-MM-DD" or null.
async function wikidataMovieDate(tmdbId, title) {
  if (!tmdbId) return null;
  const q = 'SELECT ?m ?mLabel ?rd WHERE { ?m wdt:P4947 "' + tmdbId +
    '" . OPTIONAL { ?m wdt:P577 ?rd } OPTIONAL { ?m rdfs:label ?mLabel . FILTER(LANG(?mLabel)="en") } }';
  const url = 'https://query.wikidata.org/sparql?format=json&query=' + encodeURIComponent(q);
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(API_TIMEOUT_MS + 7000),
      headers: { 'User-Agent': 'Homeflix/1.4.0 (self-hosted; personal use; keyless metadata)' }
    });
    if (!res.ok) return null;
    const j = await res.json();
    const bids = [];
    for (const b of (j.results && j.results.bindings) || []) {
      const rd = b.rd && String(b.rd.value || '').slice(0, 10);
      if (rd && /^\d{4}-\d{2}-\d{2}$/.test(rd)) {
        bids.push({ label: b.mLabel && String(b.mLabel.value || ''), rd });
      }
    }
    return pickRd(bids, title);
  } catch (_) { return null; }
}

// Trustworthy date picker: title-matching entity wins; if nothing matches,
// a single unanimous candidate is still safe; otherwise trust nothing and
// return null (the UI falls back to the plain year, which is always right).
function pickRd(bids, title) {
  const nt = normTitle(title || '');
  if (!bids.length) return null;
  const rds = bids.map((b) => b.rd).sort();
  if (rds[0] === rds[rds.length - 1]) return rds[0]; // every candidate agrees
  const good = bids
    .filter((b) => {
      const l = normTitle(b.label || '');
      return l && l === nt || (l && nt.length >= 3 && (l.startsWith(nt) || nt.startsWith(l)));
    })
    .map((b) => b.rd)
    .sort();
  return good.length ? good[0] : null; // earliest date among title matches
}

async function wikiSummary(title, year, isMovie) {
  const enc = (t) => encodeURIComponent(String(t).replace(/\s+/g, '_'));
  const tries = [];
  if (year) tries.push(`${title} (${year} film)`);
  tries.push(`${title} (film)`, title);
  for (const t of tries) {
    try {
      const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${enc(t)}`, {
        signal: AbortSignal.timeout(API_TIMEOUT_MS), headers: UA
      });
      if (!res.ok) continue;
      const j = await res.json();
      if (j.type !== 'standard' || !j.extract || j.extract.length < 80) continue;
      // A wrong synopsis is worse than none: reject pages that are clearly not the film.
      if (isMovie && /video game|game series|media franchise|\bnovel\b|\bnovella\b|\balbum\b|\bcomic book\b|\bmanga\b|\banime series\b/i.test(j.extract)) continue;
      return { extract: j.extract, thumb: (j.thumbnail && j.thumbnail.source) || null };
    } catch (_) { continue; }
  }
  return null;
}

function enrichCacheFile(rec) {
  return path.join(ENRICH_DIR, rec.type, `${rec.id}.json`);
}

function applyEnrich(rec, j) {
  rec.y = j.y || rec.y || 0;
  rec.rd = j.rd || rec.rd || '';
  rec.p = j.p || rec.p || null;
  rec.b = j.b || rec.b || null;
  rec.o = j.o || rec.o || null;
  rec.d = j.d || rec.d || '';
  rec.g = j.g && j.g.length ? j.g : rec.g || [];
  rec.v = j.v || rec.v || 0;
  rec.stars = j.stars || rec.stars || '';
  rec.imdb = j.imdb || rec.imdb || null;
}

async function enrich(rec) {
  if (!rec || !rec.id || !rec.t) return rec;
  const cf = enrichCacheFile(rec);
  if (fs.existsSync(cf)) {
    try {
      const j = JSON.parse(fs.readFileSync(cf, 'utf8'));
      // Caches written before origin tracking lack the `o` key entirely —
      // treat those as stale so streamer labels (Netflix/Hulu/…) backfill.
      // Same for the release-date key: without `rd` there is no month/year.
      const staleShape = rec.type === 'tv' && !('o' in j);
      if (!staleShape && !('rd' in j) && !j.none) { /* backfill rd below */ }
      if (!staleShape && 'rd' in j && Date.now() - j.at < ENRICH_TTL) { applyEnrich(rec, j); return rec; }
    } catch (_) {}
  }
  // 1) frameXTV native metadata — the same backend that serves playback, so
  //    years, art and genres always match what the embeds can actually play.
  try {
    const fm = await fxtvMeta(rec.type, rec.id);
    if (fm.ok) {
      if (fm.y) rec.y = fm.y;
      if (fm.p) rec.p = fm.p;
      if (fm.b) rec.b = fm.b;
      if (fm.g && fm.g.length) rec.g = fm.g;
    }
  } catch (_) {}
  if (rec.type === 'movie') {
    if (!rec.p || !rec.y) {
      const imdb = await imdbSuggest(rec.t, 'movie');
      if (imdb) {
        rec.p = rec.p || imdb.i.imageUrl || null;
        rec.y = rec.y || imdb.y || 0;
        rec.stars = String(imdb.s || '').slice(0, 160);
        rec.imdb = rec.imdb || imdb.id || null;
      }
    }
    if (!rec.d) {
      const wiki = await wikiSummary(rec.t, rec.y, true);
      if (wiki) {
        rec.d = wiki.extract.slice(0, 600);
        if (!rec.p && wiki.thumb) rec.p = wiki.thumb;
        if (!rec.g.length) rec.g = genresFromText(wiki.extract);
      }
    }
    if (!rec.rd) {
      const rd = await wikidataMovieDate(rec.id, rec.t);
      if (rd) rec.rd = rd; // "YYYY-MM-DD" -> UI shows "Jun 2025"
    }
  } else {
    const tvj = await tvEnrich(rec);
    if (tvj && tvj.show) {
      rec.y = rec.y || parseInt(String(tvj.show.premiered || '').slice(0, 4), 10) || 0;
      rec.rd = rec.rd || String(tvj.show.premiered || '').slice(0, 10); // shows get exact months too
      rec.d = tvj.show.summary || rec.d || '';
      rec.g = (tvj.show.genres && tvj.show.genres.length ? tvj.show.genres.map(normGenre) : rec.g) || [];
      rec.v = tvj.show.rating || rec.v || 0;
      rec.o = originLabel(tvj.show.origin) || rec.o || null;
      if (!rec.p && tvj.show.image) rec.p = tvj.show.image;
    }
    if (!rec.p) {
      const imdb = await imdbSuggest(rec.t, 'tv');
      if (imdb) {
        rec.p = imdb.i.imageUrl || null;
        rec.y = rec.y || imdb.y || 0;
        rec.stars = String(imdb.s || '').slice(0, 160);
        rec.imdb = rec.imdb || imdb.id || null;
      }
    }
  }
  try {
    fs.writeFileSync(cf, JSON.stringify({
      at: Date.now(), y: rec.y, rd: rec.rd || '', p: rec.p, b: rec.b,
      o: rec.o || '', // '' = checked, no streamer — prevents endless refetch
      d: rec.d, g: rec.g, v: rec.v, stars: rec.stars, imdb: rec.imdb
    }));
  } catch (_) {}
  return rec;
}

function enrichDedup(rec) {
  const k = rec.type + ':' + rec.id;
  if (inflightEnrich.has(k)) return inflightEnrich.get(k);
  const p = enrich(rec)
    .catch(() => {})
    .finally(() => inflightEnrich.delete(k));
  inflightEnrich.set(k, p);
  return p;
}

async function bulkEnrich() {
  // Pass 1 — metadata: frameXTV-native first (years/genres/art), fallbacks after.
  const pool = C.movies.slice(0, ENRICH_TOP).concat(C.tv.slice(0, ENRICH_TOP));
  for (let i = 0; i < pool.length; i += ENRICH_PARALLEL) {
    const chunk = pool.slice(i, i + ENRICH_PARALLEL);
    sync.progress = `Enriching metadata ${Math.min(i + chunk.length, pool.length)}/${pool.length}…`;
    await Promise.all(chunk.map((r) => enrich(r).catch(() => {})));
  }
  // Pass 2 — availability: verified-playable flags power rows, badges & filters.
  const avTop = Number(process.env.CATALOG_AV_TOP || 2000);
  const avPool = C.movies.slice(0, avTop).concat(C.tv.slice(0, avTop)).filter((r) => r.av == null);
  const AVP = Number(process.env.CATALOG_AV_PARALLEL || 8);
  for (let i = 0; i < avPool.length; i += AVP) {
    const chunk = avPool.slice(i, i + AVP);
    sync.progress = `Verifying availability ${Math.min(i + chunk.length, avPool.length)}/${avPool.length}…`;
    await Promise.all(chunk.map((r) => probeAvail(r).catch(() => {})));
  }
}

/* ------------------------------------------------------------ TVMaze (TV) */

function stripHtml(s) {
  return String(s || '')
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

async function tvEnrich(rec) {
  const cacheFile = path.join(TVMAZE_DIR, `${rec.id}.json`);
  try {
    if (fs.existsSync(cacheFile)) {
      const j = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      const staleShape = j.show && !('origin' in j.show); // written before origin tracking
      if (!staleShape && Date.now() - j.at < (j.none ? 2 * DAY : 30 * DAY)) return j;
    }
  } catch (_) {}
  let out;
  let transient = false;
  try {
    const url = `https://api.tvmaze.com/singlesearch/shows?q=${encodeURIComponent(rec.t)}&embed=episodes`;
    const res = await fetch(url, { signal: AbortSignal.timeout(API_TIMEOUT_MS), headers: UA });
    if (res.ok) {
      const d = await res.json();
      const yr = parseInt(String(d.premiered || '').slice(0, 4), 10) || 0;
      const refY = rec.y || 0;
      const yearOk = !yr || !refY || Math.abs(yr - refY) <= 1;
      if (yearOk) {
        out = {
          at: Date.now(),
          show: {
            id: d.id, name: d.name, premiered: d.premiered || '',
            rating: (d.rating && d.rating.average) || 0,
            origin: (d.webChannel && d.webChannel.name) || (d.network && d.network.name) || '',
            image: (d.image && (d.image.original || d.image.medium)) || null,
            genres: Array.isArray(d.genres) ? d.genres : [],
            summary: stripHtml(d.summary || '').slice(0, 600)
          },
          eps: ((d._embedded && d._embedded.episodes) || []).map((e) => ({
            s: e.season, e: e.number, n: e.name || '',
            air: e.airdate || '', img: (e.image && e.image.medium) || null,
            d: stripHtml(e.summary || '').slice(0, 400)
          })).filter((e) => e.s && e.e)
        };
      } else {
        out = { none: true };
      }
    } else {
      out = { none: true };
    }
  } catch (_) {
    out = { none: true };
    transient = true; // network flake — don't poison the cache, retry next time
  }
  out.at = Date.now();
  if (!transient) {
    try { fs.writeFileSync(cacheFile, JSON.stringify(out)); } catch (_) {}
  }
  return out;
}

async function tvSeasons(tmdbId) {
  const rec = byId('tv', tmdbId);
  if (!rec) return { seasons: [], fallback: true };
  const j = await tvEnrich(rec);
  if (!j || j.none || !j.eps) return { seasons: [], fallback: true };
  const map = new Map();
  for (const e of j.eps) {
    if (!map.has(e.s)) map.set(e.s, { n: e.s, count: 0, premiered: e.air });
    map.get(e.s).count++;
  }
  return { seasons: [...map.values()].sort((a, b) => a.n - b.n), fallback: false, show: j.show };
}

async function tvEpisodes(tmdbId, season) {
  const rec = byId('tv', tmdbId);
  if (!rec) return { episodes: [], fallback: true };
  const j = await tvEnrich(rec);
  if (!j || j.none || !j.eps) return { episodes: [], fallback: true };
  return {
    episodes: j.eps.filter((e) => e.s === Number(season)).sort((a, b) => a.e - b.e),
    fallback: false,
    show: j.show
  };
}

/* ------------------------------------------------------------------- sync */

async function buildAndSwap() {
  sync.phase = 'download';
  sync.progress = 'Fetching latest catalog exports…';
  const mv = await downloadExport('movie_ids');
  const tv = await downloadExport('tv_series_ids');

  sync.phase = 'parse';
  sync.progress = 'Indexing titles locally…';
  const [sinkM, sinkT] = await Promise.all([
    parseExport(mv.file, 'movie'),
    parseExport(tv.file, 'tv')
  ]);
  sinkM.sort(byPop); sinkM.length = Math.min(sinkM.length, MAX_MOVIES);
  sinkT.sort(byPop); sinkT.length = Math.min(sinkT.length, MAX_TV);

  const have = new Set(sinkM.map((r) => 'movie:' + r.id).concat(sinkT.map((r) => 'tv:' + r.id)));
  for (const s of SEEDS) {
    const k = s.type + ':' + s.id;
    if (!have.has(k)) {
      const rec = normalize(s, s.type);
      rec.pop = rec.pop || 0.5;
      (s.type === 'movie' ? sinkM : sinkT).push(rec);
    }
  }

  // Phase 1: persist the parsed catalog immediately (crash-resilient).
  C = { movies: sinkM, tv: sinkT, builtAt: Date.now(), fromSeed: false, seedCount: 0 };
  writeCatalog();

  sync.phase = 'enrich';
  await bulkEnrich();

  // Phase 2: stamp and persist again with enrichment baked in.
  C.builtAt = Date.now();
  writeCatalog();

  indexCatalog(); // refresh rows cache
  sync.lastSync = C.builtAt;
  sync.error = '';
  sync.phase = 'done';
  sync.progress = `${C.movies.length} movies · ${C.tv.length} shows`;
  try { fs.writeFileSync(STATE_FILE, JSON.stringify({ lastSync: sync.lastSync, at: Date.now() })); } catch (_) {}
  return C;
}

function writeCatalog() {
  const tmp = CATALOG_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(C));
  fs.renameSync(tmp, CATALOG_FILE);
}

function stale() {
  if (!fs.existsSync(CATALOG_FILE)) return true;
  if (!sync.lastSync) return true;
  return Date.now() - sync.lastSync > REFRESH_HOURS * 3600000;
}

async function startSync(force) {
  if (sync.running) return false;
  if (!force && !stale()) return false;
  sync.running = true;
  sync.error = '';
  sync.startedAt = Date.now();
  try {
    await buildAndSwap();
  } catch (e) {
    sync.error = String((e && e.message) || e);
    sync.phase = 'error';
    console.error('[homeflix] catalog sync failed:', sync.error);
  } finally {
    sync.running = false;
  }
  return true;
}

/* --------------------------------------------------------- live TV & radio */

const IPTV_TTL = 24 * 3600000;
const IPTV_API_BASE = 'https://iptv-org.github.io/api';
const RADIO_MIRRORS = ['https://de1.api.radio-browser.info', 'https://nl1.api.radio-browser.info', 'https://fi1.api.radio-browser.info', 'https://at1.api.radio-browser.info', 'https://all.api.radio-browser.info'];
const RADIO_HEALTH = new Map();
let LIVE_MEM = null;   // { at, channels[{id,n,logo,co,cats,urls,kind}], countries, categories }
let liveLoadP = null;
const LIVE_BAD = new Map(); // url -> markedAt (persisted, expires after 3 days)
const LIVE_SEEN = new Map(); // url -> last probedAt (in-memory, cooldown for the verify loop)

/* Ad & intrusion source hygiene: community indexes occasionally carry links
 * that are not streams at all — YouTube/Facebook embeds (ads served by the
 * embed platform), URL shorteners (ad-gated redirects), and known ad-network
 * hosts. None of those can execute code in Homeflix (the media elements don't
 * run content scripts and the proxy only pipes bytes), but they'd still show
 * our users ads or dead ends, so they are dropped at build time. */
const AD_URL_RE = new RegExp([
  'youtu\\.?be|youtube\\.com|yt\\.',
  'facebook\\.com|fb\\.watch|instagram\\.com|tiktok\\.com',
  'twitter\\.com|/twitter|t\\.co/',
  'bit\\.ly/|tinyurl\\.com|shorturl|\\.ly/',
  'popads|popcash|popunder|propellerads|trafficjunky|taboola|outbrain|mgid|adsrv|/adserver|doubleclick|adnxs|criteo|ad\\.ads'
].join('|'), 'i');
const adCleanUrls = (urls) => urls.filter((u) => /^https?:\/\//i.test(u || '') && !AD_URL_RE.test(u));

/* ------------------------------------------------- dynamic YouTube live TV
 * Official 24/7 live channels (news…) run raw HLS that YouTube offers without
 * any platform embed, so they can be played natively through the same proxy
 * pipeline as every other channel — zero embeds, zero platform ads.
 * youtube-live:<id> pseudo-URLs resolve on demand via yt-dlp; the resolved
 * googlevideo manifest is IP-locked to whoever fetched it, so playback always
 * goes through /api/media (same-origin, server IP) with header fidelity. */
const YT_FILE = path.join(DATA_DIR, 'yt-live.json');
const YT_RESOLVE_TTL = 6 * 60000;          // resolved manifest reuse window
const YT_BAD_TTL = 20 * 60000;             // failed resolution cooldown
const YT_BAD = new Map();                  // 'youtube-live:<id>' -> retryAt (memory only)
const YT_HEADERS = new Map();              // headerKey -> { ua, cookie } for googlevideo fetches
const YT_RES_CACHE = new Map();            // chId -> { at, r } resolved manifest entry
const YT_INFLIGHT = new Map();             // chId -> in-flight resolution promise
let YT_MEM = null;                         // { stamp, channels }
let YT_BIN_DONE = false;
let YT_BIN = null;

function ytBin() {
  if (YT_BIN_DONE) return YT_BIN;
  YT_BIN_DONE = true;
  YT_BIN = process.env.HF_YTDLP || 'yt-dlp';
  return YT_BIN;
}

function ytStamp() {
  try { return fs.statSync(YT_FILE).mtimeMs; } catch (_) { return 0; }
}

function loadYtRegistry() {
  const stamp = ytStamp();
  if (YT_MEM && YT_MEM.stamp === stamp) return YT_MEM.channels;
  let reg = null;
  try {
    const j = JSON.parse(fs.readFileSync(YT_FILE, 'utf8'));
    if (j && Array.isArray(j.channels)) reg = j.channels;
  } catch (_) {}
  if (!reg) { reg = ytlib.SEED.slice(); try { fs.writeFileSync(YT_FILE, JSON.stringify({ at: new Date().toISOString(), channels: reg }, null, 2)); } catch (_) {} }
  const channels = reg.filter((e) => e && e.watchUrl && ytlib.normalizeYtInput(e.watchUrl).ok).map((e) => ({
    id: 'ytl:' + ytlib.slug(e.id || ytlib.normalizeYtInput(e.watchUrl).id),
    n: String(e.n || e.id || 'YouTube live'),
    logo: String(e.logo || ''),
    co: String(e.co || '').toLowerCase(),
    cats: Array.isArray(e.cats) && e.cats.length ? e.cats.map((c) => String(c).toLowerCase()) : ['news'],
    // single dynamic candidate — resolved to a fresh HLS manifest on demand
    urls: ['youtube-live:' + ('ytl:' + ytlib.slug(e.id || ytlib.normalizeYtInput(e.watchUrl).id)).slice(4)],
    kind: 'tv',
    src: 'youtube',
    yt: e.watchUrl,
    bad: 0,
    official: true
  }));
  YT_MEM = { stamp, channels };
  return channels;
}

function saveYtRegistry(reg) {
  fs.writeFileSync(YT_FILE, JSON.stringify({ at: new Date().toISOString(), channels: reg }, null, 2));
  YT_MEM = null; // force rebuild from disk on next attach
}

// Injects the registry channels into whatever live payload is being served —
// runs on every liveData() call, so user-added channels appear instantly.
function withYtChannels(m) {
  if (!m || !Array.isArray(m.channels)) return m;
  const yts = loadYtRegistry();
  if (!yts.length) return m;
  const have = new Set(m.channels.map((c) => c.id));
  const extra = yts.filter((c) => !have.has(c.id));
  if (!extra.length) return m;
  return Object.assign({}, m, { channels: m.channels.concat(extra) });
}

/* Bad-mark bookkeeping: real URLs go to the persistent ledger (iptv-bad.json,
 * 3-day expiry). youtube-live pseudo candidates are memory-only with a short
 * cooldown so a transient resolution failure never hides a channel for days. */
const isYtPseudo = (u) => /^youtube-live:/.test(String(u || ''));
function badHas(u) {
  if (isYtPseudo(u)) { const t = YT_BAD.get(u); return !!t && Date.now() < t; }
  return LIVE_BAD.has(u);
}
function badSet(u) {
  if (isYtPseudo(u)) YT_BAD.set(u, Date.now() + YT_BAD_TTL);
  else { LIVE_BAD.set(u, Date.now()); }
}
function badDel(u) {
  if (isYtPseudo(u)) YT_BAD.delete(u);
  else LIVE_BAD.delete(u);
}

// Header-fidelity: googlevideo manifests/segments only serve the session that
// asked for them. The proxy fetches those URLs with the exact UA yt-dlp used,
// keyed by a short hash that rides along on proxied URLs (&h=<key>).
function ytHeaderKey(url, headers) {
  const key = 'h' + crypto.createHash('sha1').update(String(url)).digest('hex').slice(0, 12);
  YT_HEADERS.set(key, {
    ua: headers && (headers['User-Agent'] || headers['user-agent']) || '',
    cookie: headers && (headers['Cookie'] || headers['cookie']) || ''
  });
  return key;
}
function ytHeader(key) {
  const h = YT_HEADERS.get(String(key || ''));
  if (!h) return null;
  const out = {};
  if (h.ua) out['User-Agent'] = h.ua;
  if (h.cookie) out['Cookie'] = h.cookie;
  return out;
}

function pickYtFormat(info) {
  const fmts = (info && info.formats) || [];
  const hls = fmts.filter((f) => /m3u8/i.test(String(f.protocol || '')) && f.url);
  if (!hls.length) return { url: info && info.url, proto: 'raw' };
  hls.sort((a, b) => ((b.tbr || b.height || 0) - (a.tbr || a.height || 0)));
  return { url: hls[0].url, proto: 'hls' };
}

function runYtDlp(watchUrl) {
  return new Promise((resolve, reject) => {
    const args = ['-J', '--no-warnings', '--no-playlist', '--socket-timeout', '20', watchUrl];
    const p = spawn(ytBin(), args, { windowsHide: true });
    let out = '', err = '';
    const kill = setTimeout(() => { try { p.kill('k'); } catch (_) {} }, 45000);
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; });
    p.on('error', (e) => { clearTimeout(kill); reject(Object.assign(new Error('yt-dlp missing: ' + e.message), { code: 'no-yt-dlp' })); });
    p.on('close', (code) => {
      clearTimeout(kill);
      if (code !== 0 || !out) { reject(new Error('yt-dlp exit ' + code + (err ? ': ' + err.slice(-160) : ''))); return; }
      try { resolve(JSON.parse(out)); }
      catch (_) { reject(new Error('yt-dlp returned unparseable metadata')); }
    });
  });
}

// Resolve a youtube-live:<id> candidate to a play-right-now proxied HLS URL.
// opts.fresh bypasses the 6-min reuse window (client asks after a failure so a
// dead link rotates to a newly negotiated manifest instead of the cached one).
async function ytResolve(chId, opts) {
  const chans = loadYtRegistry();
  const ch = chans.find((c) => c.id === String(chId || ''));
  if (!ch) throw new Error('unknown YouTube live channel');
  const pseudo = String(chId).replace(/^ytl:/, 'youtube-live:');
  const fresh = !!(opts && opts.fresh);
  const cached = YT_RES_CACHE.get(chId);
  if (cached && !fresh) {
    if (cached.err) { const e = new Error(cached.err); e.code = cached.code || ''; throw e; } // fail fast on client auto-retries
    if (Date.now() - cached.at < YT_RESOLVE_TTL) return cached.r;
  }
  const inflight = YT_INFLIGHT.get(chId);
  if (inflight) return inflight;
  const p = (async () => {
    const fail = (msg, code) => {
      badSet(pseudo);
      YT_RES_CACHE.set(chId, { at: Date.now(), err: String(msg).slice(0, 200), code: code || '' });
      const err = new Error(msg); err.code = code || ''; throw err;
    };
    let info;
    try { info = await runYtDlp(ch.yt); }
    catch (e) {
      fail(e.code === 'no-yt-dlp'
        ? 'resolver unavailable — install yt-dlp (python -m pip install yt-dlp)'
        : String(e.message || 'resolution failed').slice(0, 200), e.code);
    }
    if (info && info.live_status && info.live_status !== 'is_live') {
      fail('channel is not live right now (' + info.live_status + ')');
    }
    const pick = pickYtFormat(info);
    if (!pick || !pick.url) fail('no playable live URL in yt-dlp metadata');
    const key = ytHeaderKey(pick.url, info.http_headers);
    badDel(pseudo);
    YT_RES_CACHE.set(chId, {
      at: Date.now(),
      r: { url: '/api/media?u=' + encodeURIComponent(pick.url) + (key ? '&h=' + key : ''), h: key, upstream: pick.url, title: String(info.title || '').slice(0, 140), name: ch.n }
    });
    return YT_RES_CACHE.get(chId).r;
  })().finally(() => YT_INFLIGHT.delete(chId));
  YT_INFLIGHT.set(chId, p);
  return p;
}

// Admin/self-service: add (or pin) a YouTube live channel from any link/handle.
// A display name (n) only lands when supplied; re-adding pins the URL but keeps
// an existing nice name — user pins always win over seed URLs.
function ytAdd(raw, display) {
  const norm = ytlib.normalizeYtInput(raw);
  if (!norm.ok) { return { ok: false, error: 'Not a YouTube channel or live video I can read — ' + norm.reason }; }
  let reg = [];
  try { reg = JSON.parse(fs.readFileSync(YT_FILE, 'utf8')).channels || []; } catch (_) { reg = ytlib.SEED.slice(); }
  const existed = reg.some((e) => String(e.id || '').toLowerCase() === String(norm.id).toLowerCase());
  const entry = { id: norm.id, co: '', cats: ['news'], watchUrl: norm.watchUrl };
  const name = String(display || '').trim().slice(0, 80);
  if (name) entry.n = name;
  else if (!existed) entry.n = norm.kind === 'video' ? 'YouTube live video ' + norm.id : '@' + norm.id;
  const merged = ytlib.mergeRegistry(reg, entry, existed);
  saveYtRegistry(merged.list);
  IDX_MEM = null; // guide pages pick the new registry up on the next call
  return { ok: true, added: merged.added, updated: merged.updated, id: 'ytl:' + ytlib.slug(norm.id) };
}

// Curated OFFICIAL public feeds — the most reliable ad-free, keyless links,
// published by the broadcasters themselves for their own players/apps. Kept
// in-Homeflix so the guide never depends solely on community indexes.
const CURATED_TV = [
  { n: 'NASA TV', co: 'us', cats: ['documentary', 'news'], urls: ['https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8'] },
  { n: 'Red Bull TV', co: 'at', cats: ['sports', 'music'], urls: ['https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8'] },
  { n: 'Al Jazeera English', co: 'qa', cats: ['news'], urls: ['https://live-hls-web-aje.getaj.net/AJE/index.m3u8', 'https://live-hls-web-aje.getaj.net/AJE/01.m3u8'] },
  { n: 'Al Jazeera Arabic', co: 'qa', cats: ['news'], urls: ['https://live-hls-web-aja.getaj.net/AJA/index.m3u8'] },
  { n: 'DW English', co: 'de', cats: ['news'], urls: ['https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8'] },
  { n: 'DW Deutsch', co: 'de', cats: ['news'], urls: ['https://dwamdstream101.akamaized.net/hls/live/2015524/dwstream101/index.m3u8'] },
  { n: 'France 24 English', co: 'fr', cats: ['news'], urls: ['https://static.france24.com/live/F24_EN_HI_HLS/live_web.m3u8'] },
  { n: 'France 24 Français', co: 'fr', cats: ['news'], urls: ['https://static.france24.com/live/F24_FR_HI_HLS/live_web.m3u8'] },
  { n: 'TRT World', co: 'tr', cats: ['news'], urls: ['https://tv-trtworld.medya.trt.com.tr/master.m3u8'] }
];

function buildCuratedTv() {
  const norm = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '');
  const channels = CURATED_TV.map((c) => ({
    id: 'own:' + norm(c.n),
    n: c.n,
    logo: '',
    co: c.co,
    cats: c.cats,
    urls: c.urls.slice(0, 3),
    bad: 0,
    kind: 'tv',
    official: true
  }));
  const catCount = new Map();
  const coCount = new Map();
  for (const c of channels) {
    for (const g of c.cats) catCount.set(g, (catCount.get(g) || 0) + 1);
    coCount.set(c.co, (coCount.get(c.co) || 0) + 1);
  }
  return {
    channels,
    countries: [...coCount.entries()].map(([code, count]) => ({ code, name: '', flag: flagOf(code), count })),
    categories: [...catCount.entries()].map(([slug, count]) => ({ slug, count }))
  };
}

// Merge channel sources into one: parts[0] wins on duplicate (country-similar
// names), so putting the curated official feeds first drops the community
// duplicates of the same channels. Country names fill from any part that has
// them (the structured iptv-org API ships a proper country name table).
function mergeSources(parts) {
  const chans = [];
  const seen = new Set();
  const catCount = new Map();
  const coCount = new Map();
  const nameMap = new Map();
  for (const part of parts) {
    if (!part) continue;
    for (const c of (part.channels || [])) {
      // co is case-insensitive: community indexes use "US", ours "us" — same country
      const k = String(c.co || '').toLowerCase() + '|' + String(c.n || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
      if (seen.has(k)) continue;
      seen.add(k);
      chans.push(c);
    }
    // categories/countries arrive either as [slug, count] tuples or as
    // {slug, count} objects (curated feed); accept both shapes.
    for (const pair of (part.categories || [])) {
      const slug = Array.isArray(pair) ? pair[0] : pair && pair.slug;
      const count = Array.isArray(pair) ? pair[1] : (pair && pair.count) || 0;
      if (!slug) continue;
      catCount.set(String(slug), (catCount.get(String(slug)) || 0) + (count || 0));
    }
    for (const co of (part.countries || [])) {
      const code = co && (co.code != null ? co.code : co[0]);
      const count = co && (co.count != null ? co.count : co[1]) || 0;
      if (!code) continue;
      coCount.set(code, (coCount.get(code) || 0) + count);
      if (co && co.name && !nameMap.get(code)) nameMap.set(code, co.name);
    }
  }
  return {
    channels: chans,
    countries: [...coCount.entries()].filter(([, count]) => count)
      .map(([code, count]) => ({ code, name: nameMap.get(code) || '', flag: flagOf(code), count }))
      .sort((a, b) => b.count - a.count),
    categories: [...catCount.entries()].map(([slug, count]) => ({ slug, count })).sort((a, b) => b.count - a.count)
  };
}

function flagOf(code) {
  const c = String(code || '').toUpperCase();
  if (!/^[A-Z]{2}$/.test(c)) return '🌐';
  return String.fromCodePoint(...[...c].map((ch) => 0x1f1e6 + ch.charCodeAt(0) - 65));
}

function liveFromDisk() {
  try {
    const j = JSON.parse(fs.readFileSync(IPTV_FILE, 'utf8'));
    if (j && Array.isArray(j.channels) && j.countries) return j;
  } catch (_) {}
  return null;
}

function loadLiveBad() {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'iptv-bad.json'), 'utf8'));
    for (const [u, t] of Object.entries(j)) if (Date.now() - t < 3 * DAY) LIVE_BAD.set(u, t);
  } catch (_) {}
}

function saveLiveBad() {
  try { fs.writeFileSync(path.join(DATA_DIR, 'iptv-bad.json'), JSON.stringify(Object.fromEntries([...LIVE_BAD].filter(([u]) => !isYtPseudo(u))))); } catch (_) {}
}

// Worldwide TV: iptv-org structured API (channels + streams + countries), keyless.
async function buildLiveApi() {
  const [chans, streams, countries] = await Promise.all([
    fetchJson(`${IPTV_API_BASE}/channels.json`, 90000),
    fetchJson(`${IPTV_API_BASE}/streams.json`, 90000),
    fetchJson(`${IPTV_API_BASE}/countries.json`, 30000)
  ]);
  const cname = new Map((countries || []).map((c) => [c.code, c.name]));
  const byChan = new Map();
  for (const s of streams || []) {
    if (!s || !s.url || s.channel == null || s.status === 'offline') continue;
    let arr = byChan.get(s.channel);
    if (!arr) byChan.set(s.channel, (arr = []));
    arr.push(s);
  }
  const channels = [];
  const catCount = new Map();
  const coCount = new Map();
  for (const c of chans || []) {
    if (!c || c.closed || c.is_nsfw) continue;
    const sts = byChan.get(c.id);
    if (!sts || !sts.length) continue;
    // Prefer clean browser-playable streams (no referrer/UA requirements), then quality.
    const dirty = (x) => (x.referrer ? 2 : 0) + (x.user_agent ? 2 : 0);
    const qual = (x) => parseInt(String(x.quality || '').replace(/\D/g, ''), 10) || 0;
    const urls = adCleanUrls(sts.slice().sort((a, b) => (dirty(a) - dirty(b)) || (qual(b) - qual(a)))
      .map((s) => s.url)).slice(0, 3);
    if (!urls.length) continue; // only ad-network/embed/dead-end links — skip
    const cats = (c.categories || []).filter(Boolean).slice(0, 4);
    channels.push({ id: c.id, n: c.name, logo: String(c.logo || '').replace(/^http:\/\//i, 'https://'), co: c.country || '', cats, urls, bad: 0, kind: 'tv' });
    for (const g of cats) catCount.set(g, (catCount.get(g) || 0) + 1);
    if (c.country) coCount.set(c.country, (coCount.get(c.country) || 0) + 1);
  }
  const co = [...coCount.entries()]
    .map(([code, count]) => ({ code, name: cname.get(code) || code, flag: flagOf(code), count }))
    .sort((a, b) => b.count - a.count);
  co.unshift({ code: '', name: 'International', flag: '🌐', count: channels.filter((c) => !c.co).length });
  const cats = [...catCount.entries()].map(([slug, count]) => ({ slug, count }))
    .sort((a, b) => b.count - a.count).slice(0, 14);
  return { channels, countries: co, categories: cats };
}

// Worldwide radio: radio-browser.info API, keyless, mirror-failover, broken
// stations pre-filtered by their community checks, ranked by listeners.
// The pull is doubled (top 6000 by listener votes) to widen the catalog.
async function buildRadio() {
  let lastErr;
  for (const base of RADIO_MIRRORS) {
    try {
      if (RADIO_HEALTH.get(base) > Date.now()) throw new Error('cooldown');
      const stations = await fetchJson(`${base}/json/stations/search?limit=6000&order=clickcount&reverse=true&hidebroken=true`, 90000);
      if (!Array.isArray(stations) || !stations.length) throw new Error('empty radio list');      const channels = [];
      const coCount = new Map();
      const coName = new Map();
      const catCount = new Map();
      for (const s of stations) {
        if (!s || !s.name || (!s.url_resolved && !s.url) || s.lastcheckok === 0) continue;
        const tags = String(s.tags || '').split(',').map((t) => t.trim().toLowerCase()).filter(Boolean).slice(0, 3);
        const co = String(s.countrycode || '').toUpperCase(); // match iptv-org TV codes
        const urls = [s.url_resolved || s.url, s.url].filter(Boolean)
          .map((u, i, a) => a.indexOf(u) === i ? u : null).filter(Boolean)
          .sort((x) => /^https:/i.test(x) ? -1 : 1);
        const clean = adCleanUrls(urls).slice(0, 2); // ad-network/redirect/embed hosts removed here
        if (!clean.length) continue;
        channels.push({
          id: 'radio:' + s.stationuuid, n: s.name.trim().slice(0, 80),
          logo: String(s.favicon || '').replace(/^http:\/\//i, 'https://'),
          co, cats: tags, urls: clean, bad: 0, kind: 'radio', codec: s.codec || '', home: s.homepage || ''
        });
        if (co) {
          coCount.set(co, (coCount.get(co) || 0) + 1);
          if (s.country) coName.set(co, s.country);
        }
        for (const t of tags) catCount.set(t, (catCount.get(t) || 0) + 1);
      }
      const countries = [...coCount.entries()]
        .map(([code, count]) => ({ code, name: coName.get(code) || code.toUpperCase(), flag: flagOf(code), count }))
        .sort((a, b) => b.count - a.count);
      const categories = [...catCount.entries()].map(([slug, count]) => ({ slug, count }))
        .sort((a, b) => b.count - a.count).slice(0, 12);
      return { channels, countries, categories };
    } catch (e) {
      lastErr = e;
      if (!/cooldown/i.test(String(e && e.message))) {
        const cause = e && e.cause && (e.cause.code || e.cause.message);
        console.error(`[homeflix] radio mirror ${base} failed: ${(e && e.message) || e}${cause ? ' (' + cause + ')' : ''}`);
      }
      RADIO_HEALTH.set(base, Date.now() + 10 * 60000);
    }
  }
  throw lastErr || new Error('radio sources unreachable');
}

// Fallback if the structured APIs are ever unreachable: community m3u indexes.
async function buildLiveM3U() {
  const channels = [];
  const seen = new Map();
  for (const [group, url] of IPTV_SOURCES) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(60000), headers: UA });
      if (!res.ok) continue;
      const text = await res.text();
      let cur = null;
      for (const line of text.split(/\r?\n/)) {
        if (line.startsWith('#EXTINF')) {
          cur = {
            name: (line.split(',').pop() || '').trim(),
            logo: (line.match(/tvg-logo="([^"]*)"/) || [])[1] || '',
            group
          };
        } else if (line && !line.startsWith('#') && cur) {
          const u = line.trim();
          if (cur.name && /^https?:/.test(u) && !AD_URL_RE.test(u)) {
            const k = cur.name.toLowerCase();
            let ch = seen.get(k);
            if (!ch) {
              ch = {
                id: 'm3u:' + k.replace(/[^a-z0-9]+/g, '-'), k, n: cur.name, logo: cur.logo,
                co: '', cats: [group.toLowerCase()], urls: [], bad: 0, kind: 'tv'
              };
              seen.set(k, ch);
              channels.push(ch);
            }
            if (ch.urls.length < 3 && !ch.urls.includes(u)) ch.urls.push(u);
          }
          cur = null;
        }
      }
    } catch (_) {}
  }
  const categories = [...new Set(channels.flatMap((c) => c.cats))]
    .map((slug) => ({ slug, count: channels.filter((c) => c.cats.includes(slug)).length }))
    .sort((a, b) => b.count - a.count);
  const countries = [{ code: '', name: 'International', flag: '🌐', count: channels.length }];
  return { channels, countries, categories };
}

function mergeLive(tv, radio) {
  const channels = []
    .concat(tv ? tv.channels : [])
    .concat(radio ? radio.channels : []);
  const coMap = new Map();
  for (const part of [tv, radio]) {
    if (!part) continue;
    for (const c of part.countries) {
      const cur = coMap.get(c.code);
      if (cur) { cur.count += c.count; if (cur.flag === '🌐' && c.flag !== '🌐') cur.flag = c.flag; }
      else coMap.set(c.code, Object.assign({}, c));
    }
  }
  const catMap = new Map();
  for (const part of [tv, radio]) {
    if (!part) continue;
    for (const c of part.categories) catMap.set(c.slug, (catMap.get(c.slug) || 0) + c.count);
  }
  return {
    at: Date.now(),
    channels,
    countries: [...coMap.values()].filter((c) => c.count > 0).sort((a, b) => b.count - a.count),
    categories: [...catMap.entries()].map(([slug, count]) => ({ slug, count })).sort((a, b) => b.count - a.count).slice(0, 16)
  };
}

let TV_LAST = null;   // raw TV part of the last build — enables cheap radio top-ups
let RADIO_LAST = null;

async function buildLive() {
  // Sequential on purpose: this box's network drops concurrent connections
  // (radio ETIMEDOUTs while the big TV export downloads), and radio is small —
  // fetch it first, then the TV data.
  let radio = null;
  try { radio = await buildRadio(); }
  catch (e) { console.error('[homeflix] radio build failed:', (e && e.message) || e); }
  console.log(`[homeflix] live: radio ${radio ? radio.channels.length + ' stations' : 'FAILED'}`);
  let tv = null;
  try { tv = await buildLiveApi(); }
  catch (e) { console.error('[homeflix] tv build failed:', (e && e.message) || e); }
  console.log(`[homeflix] live: tv ${tv ? tv.channels.length + ' channels' : 'FAILED'}`);
  if (!tv || !tv.channels.length) { try { tv = await buildLiveM3U(); } catch (_) {} }
  // Curated official feeds always ride on top (and win name-dedupes), so the
  // guide keeps flagship news/sports/documentary channels even if community
  // indexes wobble.
  const curated = buildCuratedTv();
  tv = tv && tv.channels && tv.channels.length ? mergeSources([curated, tv]) : curated;
  if (tv && tv.channels.length) TV_LAST = tv;
  if (radio && radio.channels.length) RADIO_LAST = radio;
  // Second chance for radio: the big TV download is done now, network is free.
  if (!radio || !radio.channels.length) {
    await new Promise((r) => setTimeout(r, 5000));
    RADIO_HEALTH.clear();
    try {
      radio = await buildRadio();
      if (radio && radio.channels.length) {
        RADIO_LAST = radio;
        console.log(`[homeflix] live: radio retry ok — ${radio.channels.length} stations`);
      }
    } catch (e) { console.error('[homeflix] radio retry failed:', (e && e.message) || e); }
  }
  if ((!tv || !tv.channels.length) && (!radio || !radio.channels.length)) {
    throw new Error('live sources unreachable');
  }
  const m = mergeLive(tv, radio);
  m.fmt = 3;
  m.radioOk = !!(radio && radio.channels.length); // radio-less caches never count as complete
  try { fs.writeFileSync(IPTV_FILE, JSON.stringify(m)); } catch (_) {}
  return m;
}

// Cheap targeted retry: fetch ONLY radio and re-merge with the last TV part.
// Runs periodically until radio lands, so a flaky radio-browser mirror at
// boot can never leave the radio list empty for a whole day.
let topUpTries = 0;
async function radioTopUp() {
  if (LIVE_MEM && LIVE_MEM.radioOk) return true;
  if (liveLoadP || topUpTries > 12) return false; // in-flight full build owns the network
  // TV_LAST is lost on restart — rebuild it from any cached merged snapshot
  // (every channel carries its kind, so the radio half filters out cleanly).
  if (!TV_LAST) {
    const m = LIVE_MEM;
    if (!m || !(m.channels || []).length) return false;
    TV_LAST = { channels: m.channels.filter((c) => (c.kind || 'tv') === 'tv'), countries: m.countries, categories: m.categories };
  }
  topUpTries++;
  RADIO_HEALTH.clear();
  try {
    const radio = await buildRadio();
    if (radio && radio.channels.length) {
      RADIO_LAST = radio;
      const m = mergeLive(TV_LAST, RADIO_LAST);
      m.fmt = 3;
      m.radioOk = true;
      LIVE_MEM = m;
      try { fs.writeFileSync(IPTV_FILE, JSON.stringify(m)); } catch (_) {}
      console.log(`[homeflix] live: radio top-up ok — ${radio.channels.length} stations`);
      return true;
    }
  } catch (e) {
    console.error('[homeflix] radio top-up failed:', (e && e.message) || e);
  }
  return false;
}

// Stale-while-revalidate: complete (TV+radio) cached data answers instantly;
// anything incomplete or older than the TTL triggers a background rebuild
// while the best available data keeps serving.
async function liveData() {
  return withYtChannels(await baseData());
}

function baseData() {
  const m = LIVE_MEM;
  if (m && m.fmt === 3 && m.radioOk === true && Date.now() - m.at < IPTV_TTL) return m;
  if (!liveLoadP) {
    liveLoadP = buildLive()
      .then((x) => { LIVE_MEM = x; return x; })
      .catch((e) => { console.error('[homeflix] live build failed:', (e && e.stack) || e); throw e; })
      .finally(() => { liveLoadP = null; });
  }
  if (m && (m.channels || []).length) return m; // partial/stale but usable; top-up loop fills radio gaps
  return liveLoadP;
}

// Reachability probe: validates streams once per refresh so dead links vanish
// from the list instead of erroring in the player. GET with an immediate body
// cancel works for HLS, DASH and ICY alike (HEAD is often rejected).
// DNS/resolver failures return 'unknown' — those are OUR network flaking, not
// the stream being dead, so they must never poison the bad-url list.
async function probeUrl(url) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 7000);
  try {
    const res = await fetch(url, { signal: ctl.signal, headers: UA, redirect: 'follow' });
    if (res.body) res.body.cancel().catch(() => {});
    return res.status >= 200 && res.status < 400 ? 'ok' : 'dead';
  } catch (e) {
    const cause = e && e.cause && e.cause.code;
    if (cause === 'ENOTFOUND' || cause === 'EAI_AGAIN') return 'unknown';
    return 'dead';
  } finally {
    clearTimeout(t);
  }
}

// Resolves once no live build is in flight (or one just completed), so the
// boot verify doesn't run concurrent with the build's big downloads.
async function liveSettled() {
  try { await (liveLoadP || liveData()); } catch (_) {}
  if (liveLoadP) { try { await liveLoadP; } catch (_) {} }
  return LIVE_MEM;
}

async function liveVerify() {
  const m = await liveData();
  if (!m || !m.channels) return 0;
  const targets = [];
  for (const c of m.channels) {
    if (c.src === 'youtube') continue; // resolved on demand — no URL to probe
    const liveCats = c.cats.some((x) => /sport|news/.test(x));
    if (c.kind === 'radio' && !liveCats && m.channels.indexOf(c) > 800) continue; // top radio by popularity only
    if (!liveCats && c.kind !== 'radio') continue;
    const allBad = c.urls.every((u) => badHas(u));
    const urls = allBad ? c.urls : c.urls.filter((u) => !badHas(u)).slice(0, 1);
    for (const u of urls) targets.push([c, u]);
  }
  let done = 0, dead = 0, unknown = 0;
  const CONC = 24;
  for (let i = 0; i < targets.length; i += CONC) {
    const chunk = targets.slice(i, i + CONC);
    await Promise.all(chunk.map(async ([c, u]) => {
      LIVE_SEEN.set(u, Date.now());
      const verdict = await probeUrl(u);
      if (verdict === 'ok') {
        if (badHas(u)) { badDel(u); c.bad = Math.max(0, (c.bad || 0) - 1); }
      } else if (verdict === 'unknown') {
        unknown++; // local network flake — no verdict either way
      } else { badSet(u); c.bad = (c.bad || 0) + 1; dead++; }
    }));
    done += chunk.length;
    if (done % 240 === 0) console.log(`[homeflix] live verify ${done}/${targets.length} (${dead} dead, ${unknown} network-flaky)`);
  }
  saveLiveBad();
  console.log(`[homeflix] live verify done: ${targets.length} streams, ${dead} dead, ${unknown} skipped (network flake)`);
  return dead;
}

// Round-robin background verification: every cycle checks the next slice of
// the whole channel list (skipping URLs probed recently), so over a few hours
// every link gets validated, dead ones drop out automatically, and revived
// ones come back — no user ever has to hit a dead link first.
let videoCursor = 0;
async function verifyRound(limit) {
  const m = LIVE_MEM;
  if (!m || !(m.channels || []).length) return 0;
  const targets = [];
  for (const c of m.channels) {
    if (!c.urls || !c.urls.length || !alive(c) || c.src === 'youtube') continue; // yt: resolved on playback
    const u = c.urls[0]; // primary link only — backups get tested on real playback
    if (Date.now() - (LIVE_SEEN.get(u) || 0) < 20 * 3600000) continue;
    targets.push([c, u]);
  }
  if (!targets.length) return 0;
  const slice = [];
  const n = Math.min(Number(limit) || 240, targets.length);
  for (let i = 0; i < n; i++) slice.push(targets[(videoCursor + i) % targets.length]);
  videoCursor = (videoCursor + n) % targets.length;
  let dead = 0;
  const CONC = 16;
  for (let i = 0; i < slice.length; i += CONC) {
    await Promise.all(slice.slice(i, i + CONC).map(async ([c, u]) => {
      const verdict = await probeUrl(u);
      LIVE_SEEN.set(u, Date.now());
      if (verdict === 'ok') {
        if (badHas(u)) { badDel(u); c.bad = Math.max(0, (c.bad || 0) - 1); }
      } else if (verdict === 'dead') { badSet(u); c.bad = (c.bad || 0) + 1; dead++; }
    }));
  }
  saveLiveBad();
  console.log(`[homeflix] verify round: ${slice.length} probes, ${dead} newly dead`);
  return dead;
}

const alive = (c) => c.urls.some((u) => !badHas(u));

let IDX_MEM = null; // computed index cache — liveIndex() is on the hot path
async function liveIndex() {
  const m = await liveData();
  if (!m) return { countries: [], categories: [], total: 0, kinds: { tv: 0, radio: 0 } };
  if (IDX_MEM && Date.now() - IDX_MEM.at < 90000) return IDX_MEM.payload;
  const channels = m.channels;
  const countries = m.countries.map((x) => {
    const n = channels.filter((c) => c.co === x.code && alive(c)).length;
    return { code: x.code, name: x.name, flag: x.flag, count: n };
  }).filter((x) => x.count > 0);
  const categories = m.categories.map((x) => ({
    slug: x.slug, count: channels.filter((c) => c.cats.includes(x.slug) && alive(c)).length
  })).filter((x) => x.count > 0);
  const payload = {
    at: m.at,
    countries,
    categories,
    total: channels.filter(alive).length,
    kinds: {
      tv: channels.filter((c) => (c.kind || 'tv') === 'tv' && alive(c)).length,
      radio: channels.filter((c) => c.kind === 'radio' && alive(c)).length
    }
  };
  IDX_MEM = { at: Date.now(), payload };
  return payload;
}

// Country-sectioned overview: top channels for every country in one call, so
// the Live UI can render whole-world guides nested by country without firing
// hundreds of requests. Filters (category/search) apply inside sections too.
async function liveSections(f) {
  const m = await liveData();
  if (!m) return { sections: [], total: 0 };
  f = f || {};
  const kind = String(f.kind || '').toLowerCase();
  const cat = String(f.category || '').toLowerCase();
  const terms = String(f.q || '').toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
  const perCountry = Math.min(Number(f.limit) || 24, 48);
  let list = m.channels.filter((c) => (c.kind || 'tv') === kind);
  if (cat && cat !== 'all') list = list.filter((c) => c.cats.includes(cat));
  if (terms.length) list = list.filter((c) => terms.some((t) => c.n.toLowerCase().includes(t)));
  list = list.filter(alive);
  const byCo = new Map();
  for (const c of list) {
    if (!byCo.has(c.co)) byCo.set(c.co, []);
    byCo.get(c.co).push(c);
  }
  const secList = [...byCo.entries()]
    .map(([code, chans]) => {
      const meta = m.countries.find((x) => x.code === code) || {};
      chans.sort((a, b) => a.n.localeCompare(b.n));
      return {
        co: code, name: meta.name || (code ? code.toUpperCase() : 'International'),
        flag: meta.flag || (code ? flagOf(code) : '🌐'),
        total: chans.length,
        channels: chans.slice(0, perCountry).map(({ id, n, logo, co, cats, urls, kind: k, codec, home, src, yt }) =>
          ({ id, n, logo, co, cats, urls, kind: k, codec, home, src, yt }))
      };
    })
    .sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));
  return { kind, at: m.at, total: list.length, sections: secList };
}

async function liveChannels(f) {
  const m = await liveData();
  if (!m) return { total: 0, channels: [] };
  f = f || {};
  const terms = String(f.q || '').toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
  const co = String(f.country || '').toUpperCase();
  const cat = String(f.category || '').toLowerCase();
  const kind = String(f.kind || '').toLowerCase();
  let list = m.channels;
  if (f.id) list = list.filter((c) => c.id === f.id);
  if (kind && kind !== 'all') list = list.filter((c) => (c.kind || 'tv') === kind);
  if (co && co !== 'ALL') list = list.filter((c) => c.co === co);
  if (cat && cat !== 'all') list = list.filter((c) => c.cats.includes(cat));
  if (terms.length) list = list.filter((c) => terms.some((t) => c.n.toLowerCase().includes(t)));
  list = list.filter(alive);
  const total = list.length;
  const off = Number(f.offset) || 0;
  const lim = Math.min(Number(f.limit) || 300, 600);
  // Healthy links first: never-bad channels sorted by name lead every page,
  // channels with failed-but-not-hidden links drop to the tail of the result.
  list = list
    .sort((a, b) => (a.n.localeCompare(b.n)))
    .sort((a, b) => ((a.bad || 0) - (b.bad || 0)));
  return {
    total,
    at: m.at,
    channels: list.slice(off, off + lim)
      .map(({ id, n, logo, co: cc, cats, urls, kind: k, codec, home, src, yt }) => ({ id, n, logo, co: cc, cats, urls, kind: k, codec, home, src, yt }))
  };
}

// Players report dead streams here; the link vanishes for everyone (self-healing).
async function reportLiveBad(url) {
  if (!url) return { ok: false };
  badSet(String(url));
  if (!isYtPseudo(url)) saveLiveBad();
  return { ok: true };
}

/* ------------------------------------------------------------------- init */

// Backfill streamer labels (Netflix/Hulu/HBO Max…) for popular shows whose
// caches predate origin tracking. Goes straight to the TVMaze layer (origin
// comes only from there — no frameXTV probes needed), runs once per boot,
// and persists results so later boots skip straight past it.
let originBackfilled = false;
async function originBackfill() {
  if (originBackfilled) return;
  originBackfilled = true;
  const pool = C.tv.slice(0, Math.max(ENRICH_TOP * 2, 2400)).filter((r) => !r.o);
  if (!pool.length) return;
  console.log(`[homeflix] origin backfill: ${pool.length} shows…`);
  const P = 6;
  for (let i = 0; i < pool.length; i += P) {
    await Promise.all(pool.slice(i, i + P).map(async (r) => {
      try {
        const out = await tvEnrich(r);
        if (out && out.show) {
          r.o = originLabel(out.show.origin) || r.o || null;
          r.y = r.y || parseInt(String(out.show.premiered || '').slice(0, 4), 10) || 0;
          r.p = r.p || out.show.image || null;
          r.v = r.v || out.show.rating || 0;
          if (!r.g || !r.g.length) r.g = (out.show.genres || []).map(normGenre).filter(Boolean);
        }
      } catch (_) {}
    }));
    if ((i + P) % 300 === 0) console.log(`[homeflix] origin backfill ${Math.min(i + P, pool.length)}/${pool.length}`);
  }
  indexCatalog(); // rebuild rows cache with origin labels
  writeCatalog(); // persist — later boots skip the backfill
  console.log(`[homeflix] origin backfill done: ${C.tv.filter((r) => r.o).length} shows labeled`);
}

function init() {
  ensureDirs();
  loadSeeds();
  loadCatalogFromDisk();
  loadLiveBad();
  const diskLive = liveFromDisk();
  if (diskLive) LIVE_MEM = diskLive;
  console.log(`[homeflix] catalog loaded: ${C.movies.length} movies, ${C.tv.length} shows${C.fromSeed ? ' (seed — syncing in background)' : ''}`);
  if (stale()) setTimeout(() => startSync(false), 1500);
  // Warm-up chain: build live data fully (sequential radio → TV), THEN
  // verify streams, THEN backfill origins — running any of these concurrent
  // with the build's big downloads starves this box's DNS (ENOTFOUND storm).
  setTimeout(() => {
    liveSettled()
      .then(() => liveVerify().catch(() => {}))
      // front-page preprobes: the guide's first screens verify minutes after
      // boot, not hours later, so opening the Live tab lands on working links
      .then(() => verifyRound(1200).catch(() => {}))
      .then(() => originBackfill().catch(() => {}))
      .catch(() => {});
  }, 4000);
  // Keep remote backends warm: providers hourly, live daily (SWR), a
  // dedicated cheap radio top-up until radio data lands, plus a permanent
  // round-robin stream verifier so dead links never accumulate.
  setInterval(() => { providersList().catch(() => {}); }, 60 * 60000);
  setInterval(() => { liveData().catch(() => {}); }, 30 * 60000);
  setInterval(() => { radioTopUp().catch(() => {}); }, 90 * 1000);
  setInterval(() => { verifyRound(900).catch(() => {}); }, 6 * 60000);

  // Give the initial warm-up chain a head start, then launch background
  // work: the Wikidata release-date backfill for the top movies.
  setTimeout(() => { rdBackfill().catch(() => {}); }, 60000);
}

// Batched Wikidata lookup: one SPARQL query per chunk of ids, returning
// every P577 candidate (with each entity's English label) so titles can be
// scored instead of blindly trusting the first binding.
function rdBatchQuery(ids) {
  if (!ids.length) return Promise.resolve(new Map());
  const list = ids.map((x) => '"' + String(x) + '"').join(' ');
  const q = 'SELECT ?tmdbId ?mLabel ?rd WHERE { ?movie wdt:P4947 ?tmdbId . VALUES ?tmdbId { ' + list +
    ' } OPTIONAL { ?movie wdt:P577 ?rd } OPTIONAL { ?movie rdfs:label ?mLabel . FILTER(LANG(?mLabel)="en") } }';
  const url = 'https://query.wikidata.org/sparql?format=json&query=' + encodeURIComponent(q);
  return fetch(url, {
    signal: AbortSignal.timeout(API_TIMEOUT_MS + 7000),
    headers: { 'User-Agent': 'Homeflix/1.4.0 (self-hosted; personal use; keyless metadata)' }
  }).then((res) => {
    if (!res.ok) return new Map();
    return res.json().then((j) => {
      const map = new Map();
      for (const b of (j.results && j.results.bindings) || []) {
        const id = b.tmdbId && String(b.tmdbId.value || '') || '';
        const rd = b.rd && String(b.rd.value || '').slice(0, 10);
        const label = b.mLabel && String(b.mLabel.value || '') || '';
        if (id && rd && /^\d{4}-\d{2}-\d{2}$/.test(rd)) {
          if (!map.has(id)) map.set(id, []);
          map.get(id).push({ label, rd });
        }
      }
      return map;
    });
  }).catch(() => new Map());
}

// One-off: fetch exact release dates (month/year) for the most popular
// movies in the background so the UI shows "Jun 2025"-style dates even for
// titles nobody has opened yet. Batched SPARQL (40 ids/query) keeps it to a
// couple dozen round-trips — a minute-ish, not hours.
let rdBackfilled = false;
async function rdBackfill() {
  if (rdBackfilled) return;
  rdBackfilled = true;
  // No `!r.rd` filter on purpose: the whole top list gets re-scored, so any
  // date claimed earlier by an ambiguous entity is corrected in this pass.
  const pool = C.movies.slice(0, ENRICH_TOP);
  if (!pool.length) return;
  console.log(`[homeflix] release-date backfill: ${pool.length} movies…`);
  const CH = 40;
  let done = 0, dated = 0;
  for (let i = 0; i < pool.length; i += CH) {
    const chunk = pool.slice(i, i + CH);
    const map = await rdBatchQuery(chunk.map((r) => r.id));
    for (const r of chunk) {
      const best = pickRd(map.get(String(r.id)) || [], r.t);
      if (best) {
        if (best !== r.rd) dated++; // new or corrected date
        r.rd = best;
        const cf = enrichCacheFile(r);
        try {
          const j = fs.existsSync(cf) ? JSON.parse(fs.readFileSync(cf, 'utf8')) : {};
          j.at = j.at || Date.now();
          j.rd = best;
          fs.writeFileSync(cf, JSON.stringify(j));
        } catch (_) {}
      }
      done++;
    }
    if ((i + CH) % 240 === 0) sync.progress = `Release dates ${done}/${pool.length}…`;
  }
  indexCatalog();
  writeCatalog();
  sync.progress = '';
  console.log(`[homeflix] release-date backfill done: ${dated} movies (re)dated`);
}

module.exports = {
  DATA_DIR, init, rows, search, byId, similar, status,
  enrich, enrichDedup, tvSeasons, tvEpisodes, startSync,
  providersList, fxtvMeta, probeAvail,
  liveChannels, liveIndex, liveSections, reportLiveBad,
  ytResolve, ytAdd, ytHeader
};
