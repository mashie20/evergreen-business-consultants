@echo off
REM ============================================================
REM  Homeflix — print all current public links + health check
REM  Run after deploying (URLs rotate when quick tunnels restart)
REM ============================================================
setlocal
cd /d "%~dp0"

echo.
echo [Homeflix links]
echo Local     : http://localhost:8200

echo Cloudflare:
docker logs homeflix-flare 2>&1 | findstr /C:"trycloudflare.com" | findstr /C:"https://" | more +0

echo ngrok (docker service, if enabled with --profile ngrok):
docker logs homeflix-ngrok 2>&1 | findstr /C:"url=https" | findstr /C:"ngrok"

echo ngrok (host agent dashboard on :4040, if you started it outside compose):
curl -s -m 3 http://localhost:4040/api/tunnels

echo.
echo Health checks:
curl -s -o nul -w "  Local     : %%{http_code} (%%{time_total}s)" http://localhost:8200/api/health
echo.
endlocal
