#!/usr/bin/env bash
set -euo pipefail
echo "[Homeflix Android + TV Builder] Syncing Capacitor web assets from public/..."
if [ ! -d "node_modules/@capacitor/core" ]; then
  npm install --no-save @capacitor/core @capacitor/cli @capacitor/android
fi
npx cap sync android
cd android
./gradlew assembleDebug
echo "[Homeflix Android + TV Builder] Unified Phone/Tablet/TV APK ready at:"
echo "  android/app/build/outputs/apk/debug/app-debug.apk"
