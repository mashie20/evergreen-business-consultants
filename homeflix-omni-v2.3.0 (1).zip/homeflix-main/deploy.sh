#!/usr/bin/env bash
# Safe cross-platform deployment: no implicit commits, pushes or global Docker pruning.
set -euo pipefail
cd "$(dirname "$0")"
command -v docker >/dev/null || { echo 'Docker Desktop or Docker Engine is required'; exit 1; }
docker compose config --quiet
docker compose build
docker compose up -d --remove-orphans
docker compose ps
printf 'Homeflix: http://localhost:%s\n' "${HOSTPORT:-8200}"
