#!/usr/bin/env bash
set -euo pipefail
echo "[Homeflix macOS Builder] Verifying Rust & Tauri CLI..."
if ! command -v cargo >/dev/null 2>&1; then
  echo "Error: Rust/Cargo not installed. Install via https://rustup.rs"
  exit 1
fi
npx --yes @tauri-apps/cli@latest build --bundles dmg,app
echo "[Homeflix macOS Builder] Complete! Output in src-tauri/target/release/bundle/dmg/"
