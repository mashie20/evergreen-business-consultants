'use strict';
/* ============================================================
   Homeflix accounts — lightweight multi-user profiles (zero-dep)
   - data/users.json: registered profiles (name + optional password)
   - data/userdata/<slug>.json: per-profile watch progress & My List
   - hf_user cookie: HMAC-signed, HttpOnly, 30 days, stateless
   - the PIN gate is the outer door; profiles live behind it
   ============================================================ */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

module.exports = function createAccounts(DATA_DIR, HMAC_SECRET, secureCookie = () => false) {
  const USERS_FILE = path.join(DATA_DIR, 'users.json');
  const USERDATA_DIR = path.join(DATA_DIR, 'userdata');
  const MAX_ACCOUNTS = 50;

  let users = null;
  function db() {
    if (users) return users;
    try {
      users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
      if (!users || typeof users !== 'object' || Array.isArray(users)) throw new Error('bad file');
    } catch (_) { users = {}; }
    return users;
  }
  function persist() {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = USERS_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(users, null, 1));
      fs.renameSync(tmp, USERS_FILE);
    } catch (e) { console.error('[hf] accounts persist failed:', e.message); }
  }

  function slugOf(name) {
    return String(name).toLowerCase().replace(/[^a-z0-9._-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 32) || 'profile';
  }
  function normalizeName(raw) {
    const name = String(raw || '').trim().replace(/\s+/g, ' ');
    if (!name || name.length > 24) return null;
    if (!/^[A-Za-z0-9 ._'-]+$/.test(name)) return null;
    return name;
  }

  /* ---- per-profile watch data ---- */
  function readUserData(slug) {
    try {
      const d = JSON.parse(fs.readFileSync(path.join(USERDATA_DIR, slug + '.json'), 'utf8'));
      return { progress: (d && d.progress && typeof d.progress === 'object') ? d.progress : {},
               list: Array.isArray(d && d.list) ? d.list : [] };
    } catch (_) { return { progress: {}, list: [] }; }
  }
  function writeUserData(slug, data) {
    const progress = (data && data.progress && typeof data.progress === 'object' && !Array.isArray(data.progress))
      ? data.progress : {};
    const list = Array.isArray(data && data.list) ? data.list.slice(0, 300) : [];
    const keys = Object.keys(progress);
    if (keys.length > 100) { // keep newest 100 entries
      keys.sort((a, b) => (progress[a].at || 0) - (progress[b].at || 0));
      for (let i = 0; i < keys.length - 100; i++) delete progress[keys[i]];
    }
    try {
      fs.mkdirSync(USERDATA_DIR, { recursive: true });
      const file = path.join(USERDATA_DIR, slug + '.json');
      const tmp = file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify({ progress, list }));
      fs.renameSync(tmp, file);
    } catch (e) { console.error('[hf] userdata write failed:', e.message); }
    return { progress, list };
  }

  /* ---- credentials ---- */
  function hashPassword(pw, salt) { return crypto.scryptSync(String(pw), salt, 32).toString('hex'); }

  function register(name, password) {
    name = normalizeName(name);
    if (!name) return { error: 'Name must be 1–24 letters, digits, spaces or . _ - \u0027' };
    if (password != null && password !== '' && String(password).length < (process.env.REQUIRE_PROFILE_PASSWORD === '1' ? 12 : 8))
      return { error: 'Password must be at least 8 characters (12 when enforced), or leave it empty for a local household profile' };
    if (process.env.REQUIRE_PROFILE_PASSWORD === '1' && !password) return { error: 'A profile password is required' };
    const d = db();
    if (Object.keys(d).length >= MAX_ACCOUNTS) return { error: 'Too many profiles on this Homeflix' };
    const slug = slugOf(name);
    if (d[slug]) return { error: 'That name is taken — pick another' };
    const rec = { name, slug, created: Date.now() };
    if (password != null && password !== '') {
      rec.salt = crypto.randomBytes(16).toString('hex');
      rec.hash = hashPassword(password, rec.salt);
    }
    d[slug] = rec;
    persist();
    return { name, slug };
  }

  function login(name, password) {
    name = normalizeName(name);
    if (!name) return { error: 'Enter a profile name' };
    const rec = db()[slugOf(name)];
    if (!rec) return { error: 'No profile with that name' };
    if (rec.hash) {
      if (!password) return { error: 'This profile is protected by a password' };
      const h = hashPassword(password, rec.salt);
      const a = Buffer.from(h), b = Buffer.from(rec.hash);
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { error: 'Wrong password' };
    }
    return { name: rec.name, slug: rec.slug };
  }

  /* ---- session cookie ---- */
  function cookieToken(req) {
    const cookie = req.headers.cookie || '';
    for (const part of cookie.split(';')) {
      const idx = part.indexOf('=');
      if (idx !== -1 && part.slice(0, idx).trim() === 'hf_user') return part.slice(idx + 1).trim();
    }
    return '';
  }
  function signSession(res, name, slug) {
    const payload = Buffer.from(JSON.stringify({ n: name, s: slug, exp: Date.now() + 30 * 86400000 })).toString('base64url');
    const sig = crypto.createHmac('sha256', HMAC_SECRET).update('homeflix-user-v1:' + payload).digest('base64url');
    // Secure flag rides on TLS-proxied requests (tunnels); plain LAN http keeps cookies working
  const https = secureCookie(res.req || { headers: {} });
  res.setHeader('Set-Cookie', `hf_user=${payload}.${sig}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${https ? '; Secure' : ''}`);
  }
  function clearSession(res) {
    res.setHeader('Set-Cookie', 'hf_user=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  }
  function currentUser(req) {
    const token = cookieToken(req);
    const dot = token.lastIndexOf('.');
    if (dot < 1) return null;
    const payload = token.slice(0, dot), sig = token.slice(dot + 1);
    let expect;
    try { expect = crypto.createHmac('sha256', HMAC_SECRET).update('homeflix-user-v1:' + payload).digest('base64url'); }
    catch (_) { return null; }
    const a = Buffer.from(sig), b = Buffer.from(expect);
    if (a.length !== b.length) return null;
    try { if (!crypto.timingSafeEqual(a, b)) return null; } catch (_) { return null; }
    let d;
    try { d = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')); } catch (_) { return null; }
    if (!d || typeof d.n !== 'string' || typeof d.s !== 'string' || !d.exp || d.exp < Date.now()) return null;
    if (!db()[d.s]) return null; // account removed since issue
    return { name: d.n, slug: d.s };
  }

  function profiles() {
    return Object.values(db())
      .sort((x, y) => (x.created || 0) - (y.created || 0))
      .map((u) => ({ name: u.name, hasPw: Boolean(u.hash) }));
  }

  return { profiles, register, login, currentUser, signSession, clearSession, readUserData, writeUserData };
};

/* ---- Beta Profile (password 2126) & ThanksJulius Promo (3 months free) ---- */
function handleBetaProfile(reqBody) {
  const name = String(reqBody && reqBody.name || '').trim();
  const pin = String(reqBody && reqBody.pin || '');
  if (name.toLowerCase() === 'beta' && pin === '2126') {
    return { ok: true, profile: 'beta', trialDays: 3, promo: 'thanksjulius', freeMonths: 3 };
  }
  return null;
}
