@echo off
REM ============================================================
REM  Homeflix one-command update cycle
REM   1) git add/commit/push          (defaults: origin/main)
REM   2) docker image rebuild + restart
REM   3) docker prune (dangling images, old build cache)
REM  Edit files -> run this -> new code is live & versioned.
REM ============================================================
setlocal
cd /d "%~dp0"

echo [1/4] git: staging, committing, pushing...
git add -A
git diff --cached --quiet 2>nul
if errorlevel 1 (
  git commit -m "Auto-deploy %date% %time%" --quiet
) else (
  echo       nothing new to commit
)
git push -u origin main 2>nul || (echo       WARNING: git push failed — run ^"gh auth login^" or fix the remote)

echo [2/4] docker: rebuilding image...
docker compose build --pull=false 2>&1 | findstr /C:"writing image" /C:"reproducible" /C:"exporting" /C:"error" /C:"ERROR"

echo [3/4] docker: restarting Homeflix container...
docker compose up -d --force-recreate

echo [4/4] docker: pruning garbage...
docker image prune -f
docker builder prune -f
docker container prune -f

echo.
docker ps --filter name=homeflix --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
echo Done. Local:  http://localhost:8200   Health: curl http://localhost:8200/api/health
endlocal
