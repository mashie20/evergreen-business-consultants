'use strict';
/* Ends-to-end playback QA: headless Chrome opens real channel pages and we
 * watch the <video>/<audio> element until it plays or the player gives up.
 * Usage: node qa-live.js [baseUrl] [pin]
 * Verifies: TV stream plays (videoWidth>0 / currentTime advances) and radio
 * stream plays (currentTime advances, no error, no offline note).
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9224;
const BASE = process.argv[2] || 'http://127.0.0.1:8200';
const PIN = process.argv[3] || '2026';
const OUT = 'C:/Users/MOM/AppData/Local/Temp/opencode/qa';

function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function getJson(u, opt) {
  let lastErr;
  for (let i = 0; i < 8; i++) {
    try {
      const res = await fetch(u, opt);
      return { status: res.status, headers: res.headers, data: await res.text() };
    } catch (e) { lastErr = e; await new Promise((r) => setTimeout(r, 1200 * (i + 1))); }
  }
  throw lastErr;
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  const unlock = await getJson(BASE + '/api/gate/unlock', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: PIN })
  });
  const m = /hf_auth=([^;]+)/.exec(unlock.headers.get('set-cookie') || '');
  if (!m) { console.error('unlock failed:', unlock.status); process.exit(1); }
  const token = m[1];

  // pinned channels: search the server for exactly-known good upstreams
  const tvq = JSON.parse((await getJson(BASE + '/api/live/channels?kind=tv&q=ACC&limit=5', { headers: { cookie: 'hf_auth=' + token } })).data).channels;
  const rlist = JSON.parse((await getJson(BASE + '/api/live/channels?kind=radio&limit=60', { headers: { cookie: 'hf_auth=' + token } })).data).channels;
  const tv = tvq[0] || rlist[0];
  const radio = rlist.find((c) => /Radio Armisa/i.test(c.n)) || rlist.find((c) => (c.urls || []).some((u) => /^https:.*\.mp3$/.test(u))) || rlist[0];
  console.log('TV channel   :', tv.n, '->', (tv.urls || [])[0]);
  console.log('Radio channel:', radio.n, '->', (radio.urls || [])[0]);

  await runPlay('tv', tv.id, token); // HLS TV
  await runPlay('radio', radio.id, token); // radio mp3
  process.exit(0);
}

async function runPlay(kind, channelId, token) {
  const label = 'qa-live-' + kind;
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'hf-qa-'));
  const chrome = spawn(CHROME, [
    '--headless=new', '--remote-debugging-port=' + PORT,
    '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check',
    '--autoplay-policy=no-user-gesture-required', '--mute-audio',
    '--disable-gpu', '--window-size=1440,900', '--hide-scrollbars', 'about:blank'
  ], { stdio: ['ignore', 'ignore', 'pipe'] });
  chrome.stderr.on('data', () => {});
  try {
    let wsUrl = null;
    for (let i = 0; i < 40; i++) {
      await wait(250);
      try {
        const v = await getJson('http://127.0.0.1:' + PORT + '/json/version');
        if (v.status === 200) { wsUrl = JSON.parse(v.data).webSocketDebuggerUrl; break; }
      } catch (_) {}
    }
    if (!wsUrl) throw new Error('chrome did not expose CDP');
    const created = await getJson('http://127.0.0.1:' + PORT + '/json/new?about:blank', { method: 'PUT' });
    const target = JSON.parse(created.data);
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((ok, bad) => { ws.onopen = ok; ws.onerror = bad; });

    let msgId = 0;
    const pending = new Map();
    const trail = [];
    ws.onmessage = (ev) => {
      const d = JSON.parse(ev.data);
      if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); return; }
      if (!d.method) return;
      if (d.method === 'Runtime.consoleAPICalled') {
        trail.push('console[' + d.params.type + '] ' + (d.params.args || []).map((a) => a.value != null ? String(a.value).slice(0, 220) : (a.description ? String(a.description).slice(0, 220) : '')).join(' '));
      } else if (d.method === 'Network.requestWillBeSent') {
        const u = d.params.request.url;
        if (/api\/media|m3u8|\.mp3|\.aac|\.ts(\?|$)|framextv/.test(u)) trail.push('req ' + d.params.request.method + ' ' + u.slice(0, 170));
      } else if (d.method === 'Network.responseReceived') {
        const u = d.params.response.url;
        if (/api\/media|m3u8|\.mp3|\.aac|\.ts(\?|$)/.test(u)) trail.push('res ' + d.params.response.status + ' ' + d.params.response.mimeType + ' ' + u.slice(0, 170));
      } else if (d.method === 'Log.entryAdded') {
        trail.push('log[' + d.params.entry.source + '/' + d.params.entry.level + '] ' + d.params.entry.text.slice(0, 220));
      }
    };
    const send = (method, params) => new Promise((resolve) => {
      const id = ++msgId;
      pending.set(id, resolve);
      ws.send(JSON.stringify({ id, method, params: params || {} }));
    });

    await send('Page.enable');
    await send('Network.enable');
    await send('Runtime.enable');
    await send('Network.setCookie', { name: 'hf_auth', value: token, url: BASE, httpOnly: true });
    await send('Emulation.setDeviceMetricsOverride', { width: 1440, height: 900, deviceScaleFactor: 1, mobile: false });
    // wrap Hls BEFORE app.js calls it: every instance surfaces its errors
    await send('Page.addScriptToEvaluateOnNewDocument', { source: `[].concat(
      "window.addEventListener('error',e=>console.log('[page-error]',e.message,e.filename+':'+e.lineno));",
      "window.addEventListener('unhandledrejection',e=>console.log('[page-rejection]',(e.reason&&(e.reason.message||String(e.reason))||'').slice(0,200)));",
      "(function(){const patch=()=>{if(window.__hlsPatched||!window.Hls)return setTimeout(patch,120);window.__hlsEvents=[];window.__hlsPatched=true;const Old=window.Hls;const W=function(c){const inst=new Old(Object.assign({},c||{}));const push=(d)=>{try{window.__hlsEvents.push('HLS fatal='+d.fatal+' type='+d.type+' '+d.details+(d.response?(' http='+d.response.code):''))}catch(_){}};try{inst.on(Old.Events.ERROR,(_,d)=>push(d))}catch(_){}return inst;};Object.assign(W,Old);window.Hls=W;};patch();})();"
    ).join('')`
    });

    const url = BASE + '/?qa=guest#/watch/live/' + encodeURIComponent(channelId);
    await send('Page.navigate', { url });
    await wait(4000);

    const expr = `(v=>{ v=v||{}; const el=document.querySelector('#live-media'); if(!el) return {no:false,state:'no-element'}; const e=el.error&&el.error.code; const note=document.querySelector('.stream-note'); return {state:'ok',tag:el.tagName,ready:el.readyState,src:el.currentSrc?'set':'empty',vw:el.videoWidth||0,t:(+el.currentTime||0).toFixed(1),err:e||(el.error&&el.error.code)||0,paused:el.paused,loading:!!document.getElementById('player-loading'),note:note?note.textContent.slice(0,80):null,hlsev:(window.__hlsEvents||[]).slice(-5)};})()`;
    const deadline = Date.now() + 62000;
    let r = null;
    const t0 = Date.now();
    while (Date.now() < deadline) {
      await wait(2500);
      const res = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
      r = res.result && res.result.result && res.result.result.value;
      if (!r || r.state !== 'ok') continue;
      const playing = (r.tag === 'VIDEO' ? (r.vw > 0 && r.t > 0) : (r.ready >= 2 && r.t > 0)) && !r.err && !r.note;
      const stuck = r.err || r.note;
      if (playing) { r.verdict = 'PLAYING'; break; }
      if (stuck && !r.loading && r.ready === 0 && Date.now() - t0 > 20000) { r.verdict = 'OFFLINE-NOTE'; break; }
    }
    if (!r || !r.verdict) r = Object.assign({}, r, { verdict: 'TIMEOUT-WAITING' });
    console.log(`${kind.toUpperCase()} RESULT:`, JSON.stringify(r));
    console.log(`${kind.toUpperCase()} TRAIL:`);
    for (const t of trail.slice(0, 80)) console.log('   ', t);

    const shot = await send('Page.captureScreenshot', { format: 'png' });
    if (shot.result && shot.result.data) fs.writeFileSync(path.join(OUT, label + '.png'), Buffer.from(shot.result.data, 'base64'));
    ws.close();
  } finally {
    try { chrome.kill(); } catch (_) {}
    await wait(500);
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
