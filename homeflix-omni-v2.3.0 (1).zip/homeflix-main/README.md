# 🎬 Homeflix

**Homeflix** is a self-hosted, local-first, Netflix-style streaming portal. Browse a rich movie & TV catalog, hit play, and Homeflix streams through **frameXTV** HTML5 embeds — with in-app player controls (play/pause, seek, volume, extraction servers, subtitles) driven by the frameXTV postMessage SDK. Beyond movies & shows it also streams **live TV and radio from around the world**, nested by country and category.

**Zero API keys. Zero npm dependencies. One Docker container.**

---

## How it works (no TMDB API, by design)

| Layer | Source | Keys needed |
|---|---|---|
| Catalog backbone (search & IDs) | **TMDB public daily export files** (`files.tmdb.org`) — 1.2M+ titles, indexed locally on first run, refreshed every 72 h | ❌ none |
| Poster art, years, cast | **IMDb suggestion API** (IMDb's own autocomplete CDN), cached to disk | ❌ none |
| Movie synopses + genres | **Wikipedia REST API** (film pages), cached to disk | ❌ none |
| Seasons, episodes, TV summaries, streamer origins | **TVMaze** (free public API), cached to disk | ❌ none |
| Playback | **frameXTV embeds** (`framextv.cc/embed/{tmdbId}[/s/e]`) | ❌ none |
| Live TV | **iptv-org** structured API (channels + streams + countries), m3u fallback | ❌ none |
| Radio | **radio-browser.info** community API (mirror failover) | ❌ none |
| My List / Continue Watching | Browser localStorage, synced per-account when signed in | ❌ none |

After the first sync (~2–4 min), a ~20 MB local catalog file holds ~95k movies + ~60k shows. Browsing/searching is instant, fully in-memory, and keeps working offline. Popular titles get posters, synopses and **verified availability flags** pre-fetched at sync; anything else is enriched on-demand the first time you see it (then cached for 30 days). 60 curated starter titles work **immediately**, even before the first sync finishes.

## Quick start (Docker — recommended)

```bash
cd Homeflix
docker compose up -d --build
```

Open **http://localhost:8200** (configurable via `HOSTPORT` in `.env` — 8200 is used by default because 8080 is commonly taken by other apps). On first boot the container:

1. Loads the seed catalog (instantly usable).
2. Downloads the latest TMDB daily exports in the background and builds the full local index (~1–2 min).
3. Fetches worldwide live TV + radio and starts verifying stream health in the background.
4. Keeps everything in the `homeflix_data` volume, so restarts are instant and offline-capable.

Run without Docker:

```bash
node server.js          # needs Node.js >= 20 (uses only built-ins)
```

## Accounts (per-user watch data)

Everyone can create their own profile inside Homeflix — **"Who's watching?"** on first visit, and an avatar menu in the top bar:

- **Create profile** with a name; a password is optional (≥ 4 chars if set).
- Each account gets isolated **Continue Watching + My List** (`data/userdata/*.json`), pushed to the server automatically (debounced) when signed in — so progress follows you across devices and browsers.
- Guest mode stays fully local (localStorage only); a guest's history is adopted into the account when they sign up on the same browser.
- Sessions are signed HttpOnly cookies valid 30 days. Registration and login are rate-limited.
- User data lives in the Docker volume, so it survives container rebuilds.

## Live TV & Radio (worldwide)

The **Live TV** page streams real community channels and radio — no keys, no geo-locked apps:

- **~10,000 TV channels** from iptv-org plus **~3,000 radio stations** (top by listeners), merged into one guide.
- **Nested by country** with flag emojis (United States, India, Germany, …) plus an International bucket, and by **category** (sports, news, movies, music, kids, …).
- **Sports shortcuts**: ⚽ EPL, 🏈 NFL, 🏀 NBA and 📡 News chips filter the guide straight to the relevant networks (NBC Sports, Sky Sports, ESPN, CBS Sports HQ, NFL Network, TNT Sports, NBA TV …).
- **Low-latency player**: hls.js (vendored, no CDN) hugs the live edge; radio plays through the same player as audio. "Back to live" re-syncs if you fell behind; "Back to guide" returns instantly.
- **Self-healing signals**: streams are probed on a schedule and dead links are reported by every player to the server, which hides them for everyone (3-day memory). Each channel keeps backup stream URLs and the player rotates through them automatically on fatal errors.
- **Reality check**: these are free community feeds — some are geo-restricted, temporarily offline, or rotate. The player auto-switches to backups; if a channel is truly offline, pick another one.

### ⚡ YouTube live channels (dynamic, ad-free)

Beyond community m3u links, Live TV ships official 24/7 **YouTube news channels** (Al Jazeera, DW, TRT World, Sky News, Bloomberg, CNBC, NBC News NOW, ABC News Live, CNA, WION, Al Arabiya, France 24 — marked with an **⚡ YT** chip):

- **No YouTube embeds, no YouTube ads** — the server resolves the official channel's live page with **yt-dlp** into a raw HLS manifest and streams it through Homeflix's own proxy with exact header fidelity. The 6-layer ad shield stays in charge of the player.
- **Dynamic by design** — there is no URL to rot: `youtube-live:<id>` candidates are resolved fresh on playback (short reuse window), and if a manifest dies mid-stream the player silently re-resolves a new source.
- **Add your own** — "＋ Add YouTube channel" on the Live TV page accepts any `@handle`, `channel/UC…`, `watch?v=`, or `youtu.be` link plus an optional display name. Entries live in `data/yt-live.json` and survive restarts.
- **Dependency**: `pip install yt-dlp` (ffmpeg recommended). Without it, YT chips fail with a clear message and everything else keeps working.

## Availability & origin badges

- **✓ Available** — a green check on cards means the title was verified playable through frameXTV right now (probed per-provider, cached with smart TTLs, re-probed on-demand from the detail modal).
- **Origin rows & chips** — shows carry their streamer origin (Netflix Originals, Prime Video, HBO Max, Hulu, Paramount+, Disney+, Apple TV+, Peacock, BBC) from TVMaze channel data, shown as a badge on cards and dedicated rows on the home page.

## Never-breaks playback pipeline

1. **Provider registry** — Homeflix pulls frameXTV's live provider list (titan, sparky, super_barbarian, giant, …) with a 6 h disk cache + hourly revalidation; the list survives provider renames automatically.
2. **API failover** — the server rotates frameXTV API domains (.tech/.cc/.xyz/.pro) with per-domain cooldowns; the client retries transient 5xx/network blips automatically.
3. **Embed mirror failover** — if the embed domain itself stops serving, the player rotates .cc → .xyz → .pro.
4. **Playback watchdog** — if an embed never reports actual playback within 16 s, the player silently switches extraction server, then embed mirror, and only then shows a "switch server" button.
5. **Live stream failover** — fatal HLS errors rotate backup stream URLs and report dead ones to the server.

## Auto-push: edits go live in seconds

`docker-compose.yml` runs a tiny supervisor (`watch.js`) instead of the server directly:

- It polls source files every 2 s; on any edit (`server.js`, `catalog.js`, `accounts.js`, `seed.json`, `public/*`) it restarts the Node process in-place — **no image rebuild**.
- Source files are bind-mounted read-only; the `homeflix_data` volume owns all state, so restarts are instant and nothing is lost.
- Result: edit a file on the host → the shared tunnel link shows the change within seconds. The client even rides out the ~2 s restart blip with automatic retries.

## One-command updates (git + docker, automatic)

`deploy.cmd` (Windows) / `./deploy.sh` (macOS/Linux) runs the whole update cycle:

1. Git: stage everything, commit (`Auto-deploy <date>`), push to `origin/main`.
2. Docker: rebuild `homeflix:latest`, force-recreate the container, then **prune** — dangling images, exited containers removed, build cache trimmed.
3. Prints container health + the local URL (`http://localhost:8200`).

Because source files are bind-mounted read-only, UI changes reach the running
app seconds after saving even *before* you run the script; the script is for
days when dependencies/Dockerfile change or when you want the git push + prune
sweep done in one step.

## Security & privacy (store-grade)

- 🔐 **PIN gate** — every API and page requires the shared PIN; cookies are `HttpOnly; SameSite=Lax`, and marked `Secure` automatically whenever the request arrives over HTTPS (ngrok/Cloudflare tunnels do this for you).
- 🧮 **Account passwords** are scrypt-hashed with per-user salts and compared in constant time — no plaintext stored anywhere.
- 🛡️ **Zero ads by design** — the player iframe is sandboxed (no popups, top-navigation, modals or downloads can escape it), CSP `frame-src` is pinned to the known embed mirrors only, and a runtime guard blocks stray `window.open`/popup anchors with a 🛡 counter in the player bar.
- 🧱 Strict security headers: CSP, HSTS, `Referrer-Policy`, and a locked-down `Permissions-Policy` (camera, mic, geo, USB, payment all denied).
- 🚦 Rate limiting, `/api/health`, graceful shutdown, restart-safe disk caches — and **zero npm dependencies**, so there is no supply-chain surface.

## Install as an app (PWA) & app-store path

Homeflix ships a web manifest + app icon: open the link in Chrome/Safari → **Add to Home Screen** → it launches full-screen like a native app. This same PWA is the stepping stone to storefronts later (Capacitor/TWA wrapper, Microsoft Store or Play Store) without changing the stack.

## Share a link with friends

### Option A — quick test link (1 minute, free, no account)
```bash
share.cmd        # Windows
./share.sh       # macOS / Linux
```
This starts a temporary `https://…trycloudflare.com` URL that proxies to your local instance. Set a **PIN** first (below) so only your friends can use it. Quick links change whenever your PC restarts; use Option B for a permanent address.

### Option B — stable permanent link (Cloudflare named tunnel)
1. Install cloudflared, then:
   ```bash
   cloudflared tunnel login
   cloudflared tunnel create homeflix
   cloudflared tunnel route dns homeflix homeflix.yourdomain.com
   ```
2. Put the tunnel token in `.env` (copy `.env.example` → `.env`, set `TUNNEL_TOKEN=…`), and in the Cloudflare Zero Trust dashboard set the tunnel's service URL to `http://homeflix:8080` (container-to-container on the compose network).
3. ```bash
   docker compose --profile tunnel up -d
   ```
   Your friends now use **https://homeflix.yourdomain.com** permanently.

### PIN protection (recommended for shared links)
```bash
APP_PIN=2026 docker compose up -d
```
Visitors must enter the PIN once; a signed HttpOnly cookie keeps them logged in for 30 days (the signing secret persists in the data volume, so sessions survive restarts). Attempts are rate-limited against brute force.

## Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `8080` | HTTP port |
| `APP_PIN` | *(empty)* | If set, locks the app behind a PIN |
| `CATALOG_REFRESH_HOURS` | `72` | How often to refresh the local catalog from TMDB exports |
| `CATALOG_MAX_MOVIES` | `100000` | Cap on locally indexed movies |
| `CATALOG_MAX_TV` | `60000` | Cap on locally indexed shows |
| `CATALOG_ENRICH_TOP` | `1200` | How many top titles get posters/synopses pre-fetched at sync |
| `CATALOG_AV_TOP` | `2000` | How many top titles get verified-playable probes at sync |
| `HF_DATA_DIR` | `./data` | Where catalog, caches, accounts, and the auth secret live |
| `LOG_LEVEL` | `info` | Set to `error` for quiet logs |

## Features

- 🎞 **Netflix-style UI** — hero billboard, hover cards, horizontal rows, detail modal, search, My List
- 👥 **Multi-user accounts** — "Who's watching?" picker, per-user Continue Watching & My List, optional passwords
- ▶ **frameXTV playback** — movies (`/embed/{id}`) and TV (`/embed/{id}/{s}/{e}`) with rotating embed mirrors
- 🎛 **Full player controls via postMessage SDK** — play/pause, ±10 s seek, volume/mute, extraction-server switch, subtitle track, speed, next episode
- 📡 **Real-time telemetry** — listens to `frameXTV:timeupdate` and saves progress
- 🔁 **Continue Watching** — progress bars and one-click resume (sends the `t` timestamp parameter)
- 📺 **Live TV & radio worldwide** — country-nested guide, categories, EPL/NFL/NBA sports chips, low-latency HLS player, radio support, backup-stream failover, community dead-link reporting
- ✅ **Availability checks** — verified-playable badges, per-title probe API, smart caching
- 🏷 **Origin labels** — Netflix / Hulu / HBO Max / Paramount+ / … rows and card badges
- 🔁 **Self-healing backends** — provider registry revalidation, API-domain cooldowns, embed mirror rotation, playback watchdog, client retry
- 🔒 **PIN gate** — safe sharing, signed sessions, brute-force rate limiting
- 🪶 **Light** — no npm deps, gzip + ETag static serving, strict CSP, in-memory search over 155k+ titles in milliseconds
- 🩺 **Production hygiene** — `/api/health` endpoint, Docker `HEALTHCHECK`, graceful shutdown, restart-safe caches

## Player URL parameters used

| Param | Where |
|---|---|
| `autoplay`, `muted`, `controls`, `speed` | Always set from player settings |
| `t` | Resume timestamp (Continue Watching) |
| `server` | Chosen extraction provider (non-auto) |
| `poster`, `title` | Custom poster & title overlay in the player header |

## Troubleshooting

- **"Still extracting…"** — that provider may be down. The watchdog switches servers automatically; you can also use the **Server** dropdown manually.
- **"Authorization failed" / PIN loop** — you're most likely on a stale link. Get the current link from the host (quick links change when the tunnel restarts), then re-enter the PIN.
- **Live channel offline / "Connecting to live signal…" hangs** — community streams rotate and geo-block. The player already tried every backup URL for that channel; pick another channel. Dead links auto-hide for everyone within a day.
- **Radio tab empty right after boot** — the radio source was briefly unreachable; the app keeps retrying in the background (radio builds before the big TV download by design).
- **Catalog empty / sync failed** — the host may have blocked `files.tmdb.org`. Check `GET /api/status`, then `POST /api/admin/sync` to retry. The seed catalog keeps the app usable meanwhile.
- **Wrong synopsis on an obscure title** — Wikipedia matched a franchise/game page; the app rejects those. Re-enrich via `POST /api/admin/sync`, or wait for the 30-day cache TTL.
- **Episode data missing** — TVMaze had no match for that show; the embed's own season/episode picker still works.
- **Reset PIN sessions** — delete `data/secret.key` and restart.

## Legal note

Homeflix is a self-hosted front-end shell. Playback is provided by the third-party frameXTV service and its extraction providers; live channels and radio come from community iptv-org / radio-browser listings. Availability and content are outside Homeflix's control. Host it only where and how you're allowed to, and only for audiences entitled to watch.

## License

Proprietary — all rights reserved. See `LICENSE`.


## macOS and Linux — v1.4.2 setup

Requires **Node.js 20+** for direct execution, or Docker Desktop (Mac) / Docker
Engine + Compose plugin (Linux). ARM64 and x86-64 are supported by the standard
Node.js and multi-architecture Docker images, subject to optional yt-dlp availability.

```sh
cp .env.example .env
# Set APP_PIN and a strong random ADMIN_TOKEN in .env before public exposure.
./start.sh                     # native macOS/Linux server (port 8080)
# or
./deploy.sh                    # Docker service (port 8200 by default)
```

On macOS, `start.command` also launches the native application from Finder.
The native start script loads `.env` automatically if present; environment
variables already exported by the shell take precedence.
Local browsing remains possible without a PIN, but **never expose a passwordless
instance publicly**. Set `APP_PIN`, `ADMIN_TOKEN`, and preferably
`REQUIRE_PROFILE_PASSWORD=1` on internet-facing installations. Use HTTPS and set
`SECURE_COOKIES=1` when external browser requests are exclusively HTTPS.
Only set `TRUST_PROXY=1` if untrusted clients cannot reach the Node port directly.

To request an administrator synchronization, use a secret HTTP header:

```sh
curl -X POST -H "X-Homeflix-Admin-Token: $ADMIN_TOKEN" \
  http://localhost:8080/api/admin/sync
```

### Security and compatibility notes

- Media proxy connections are validated and pinned to DNS-resolved public
  addresses, including redirects. IPv6 proxy targets are intentionally blocked
  unless `MEDIA_ALLOW_PRIVATE=1` (only for trusted local setups).
- Existing short-password profiles can still log in. New passwords must have at
  least 8 characters or 12 with `REQUIRE_PROFILE_PASSWORD=1`.
- `deploy.sh` no longer stages, commits, pushes, or prunes unrelated Docker data.
- Both development and production versions still use the existing frontend.
- Run `npm test` for the bundled unit tests; playback requires separate live
  provider and browser verification.
