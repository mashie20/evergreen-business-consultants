window.addEventListener('error', (e) => console.error('[QA-PAGEERROR]', e.message, e.filename + ':' + e.lineno + ':' + e.colno, (e.error && e.error.stack) || ''));
window.addEventListener('unhandledrejection', (e) => console.error('[QA-REJECTION]', (e.reason && (e.reason.stack || e.reason.message)) || e.reason));
console.log('[QA-HOOK] installed');
