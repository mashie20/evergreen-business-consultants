/**
 * Homeflix Omni-Platform Bridge v2.1 (Cleanroom REA v3.3 Upgrade)
 * Surfaces: Mobile | Tablet | Desktop Web | macOS | Smart TV (10-Foot D-Pad)
 * Includes: Automatic LAN Host Discovery, 6-Digit TV Pairing, & QR Code Generator
 */
(function () {
  "use strict";

  const OmniPlatform = {
    surface: "web",
    focusMatrix: [],
    pos: { row: 0, col: 0 },
    lanInfo: null,

    init() {
      this.detectSurface();
      this.injectPairingTrigger();
      this.fetchLanDiscovery();
      this.tagInteractiveElements();
      this.bindSpatialNavigation();
      this.bindMacAndMobileMediaSession();
      this.observeDOMMutations();
      window.addEventListener("resize", () => this.detectSurface());
      console.log(`[Homeflix OmniPlatform v2.1] Active surface: ${this.surface}`);
    },

    detectSurface() {
      const ua = navigator.userAgent || "";
      const w = window.innerWidth;
      const isTV =
        /GTV|Android TV|BRAVIA|AFT|SmartTV|Tizen|Web0S|CrKey/i.test(ua) ||
        w >= 1920 ||
        new URLSearchParams(window.location.search).get("mode") === "tv";
      const isMacApp =
        /Macintosh/i.test(ua) &&
        (window.matchMedia("(display-mode: standalone)").matches ||
          window.matchMedia("(display-mode: window-controls-overlay)").matches ||
          Boolean(window.__TAURI__ || window.electron));
      const isMobile = w < 640;
      const isTablet = w >= 640 && w < 1024;

      if (isTV) this.surface = "tv";
      else if (isMacApp) this.surface = "macos";
      else if (isMobile) this.surface = "mobile";
      else if (isTablet) this.surface = "tablet";
      else this.surface = "web";

      document.body.setAttribute("data-surface", this.surface);
    },

    async fetchLanDiscovery() {
      try {
        const savedHost = localStorage.getItem("hf_omni_host");
        const target = savedHost ? `${savedHost}/api/discovery` : "/api/discovery";
        const res = await fetch(target);
        if (res.ok) {
          this.lanInfo = await res.json();
        }
      } catch (_) {
        // If running inside packaged Capacitor APK without host configured, open LAN Scanner
        if (window.Capacitor || window.location.protocol === "file:") {
          this.openPairingModal();
        }
      }
    },

    /**
     * Automatic LAN Subnet Probe for Android TV / Mobile Capacitor shells
     */
    async scanLanForHost(subnetPrefix = "192.168.1", port = 8080) {
      const candidates = [];
      for (let i = 1; i <= 254; i++) {
        candidates.push(`http://${subnetPrefix}.${i}:${port}`);
      }
      const batchSize = 25;
      for (let i = 0; i < candidates.length; i += batchSize) {
        const batch = candidates.slice(i, i + batchSize);
        const found = await Promise.any(
          batch.map(async (baseUrl) => {
            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), 650);
            try {
              const r = await fetch(`${baseUrl}/api/discovery`, { signal: ctrl.signal });
              clearTimeout(timer);
              if (!r.ok) throw new Error("not hf");
              const data = await r.json();
              if (data && data.service === "homeflix-omni") return data.primaryUrl || baseUrl;
              throw new Error("mismatch");
            } catch (e) {
              clearTimeout(timer);
              throw e;
            }
          })
        ).catch(() => null);

        if (found) {
          localStorage.setItem("hf_omni_host", found);
          window.location.href = found;
          return found;
        }
      }
      return null;
    },

    injectPairingTrigger() {
      const rightBar = document.querySelector(".topbar-right");
      if (!rightBar || document.getElementById("omni-pair-btn")) return;

      const btn = document.createElement("button");
      btn.id = "omni-pair-btn";
      btn.className = "omni-pair-btn";
      btn.type = "button";
      btn.title = "Pair Smart TV / Mobile over LAN (Shift+P)";
      btn.textContent = "TV / LAN Pair";
      btn.addEventListener("click", () => this.openPairingModal());
      rightBar.insertBefore(btn, rightBar.firstChild);
    },

    async openPairingModal() {
      const existing = document.getElementById("omni-pair-modal");
      if (existing) existing.remove();

      let pairData = { code: "------", hostUrl: window.location.origin, pairUrl: window.location.origin };
      try {
        const res = await fetch("/api/pair/create", { method: "POST" });
        if (res.ok) pairData = await res.json();
      } catch (_) {}

      const modal = document.createElement("div");
      modal.id = "omni-pair-modal";
      modal.className = "omni-pair-modal";
      modal.innerHTML = `
        <div class="omni-pair-card" role="dialog" aria-label="TV & Mobile LAN Pairing">
          <h2 style="margin:0 0 8px 0;">Connect TV, Mobile & Mac</h2>
          <p style="color:#9aa0b4;font-size:0.9rem;margin:0 0 14px 0;">
            Open <strong>${pairData.hostUrl}</strong> on your Smart TV, Phone, or Tablet, or enter this 6-digit pairing code:
          </p>
          <div class="omni-pair-code">${pairData.code}</div>
          <div style="margin:12px 0;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
            <input id="omni-claim-input" type="text" inputmode="numeric" maxlength="6" placeholder="Enter 6-digit TV code"
              style="padding:10px 14px;border-radius:8px;border:1px solid rgba(255,255,255,0.2);background:#0a0b0f;color:#fff;width:190px;text-align:center;" />
            <button id="omni-claim-btn" class="omni-pair-btn" type="button" style="background:#e50914;border-color:#e50914;">
              Link Device
            </button>
          </div>
          <div style="margin-top:16px;display:flex;gap:10px;justify-content:center;">
            <button id="omni-scan-btn" class="omni-pair-btn" type="button">Auto-Scan LAN (192.168.1.x)</button>
            <button id="omni-pair-close" class="omni-pair-btn" type="button">Close (Esc)</button>
          </div>
          <div id="omni-pair-status" style="margin-top:10px;font-size:0.82rem;color:#9aa0b4;"></div>
        </div>
      `;
      document.body.appendChild(modal);

      document.getElementById("omni-pair-close").addEventListener("click", () => modal.remove());
      document.getElementById("omni-claim-btn").addEventListener("click", async () => {
        const code = document.getElementById("omni-claim-input").value.trim();
        const statusEl = document.getElementById("omni-pair-status");
        if (!code) return;
        statusEl.textContent = "Verifying pairing code...";
        try {
          const r = await fetch("/api/pair/claim", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code })
          });
          const d = await r.json();
          if (r.ok && d.hostUrl) {
            localStorage.setItem("hf_omni_host", d.hostUrl);
            statusEl.textContent = `Paired to ${d.hostname} (${d.hostUrl})! Redirecting...`;
            setTimeout(() => { window.location.href = d.hostUrl; }, 600);
          } else {
            statusEl.textContent = d.error || "Invalid code.";
          }
        } catch (err) {
          statusEl.textContent = "Connection error: " + err.message;
        }
      });

      document.getElementById("omni-scan-btn").addEventListener("click", async () => {
        const statusEl = document.getElementById("omni-pair-status");
        statusEl.textContent = "Scanning LAN subnet 192.168.1.1-254:8080...";
        const found = await this.scanLanForHost("192.168.1", 8080);
        if (!found) statusEl.textContent = "No additional host found on 192.168.1.x:8080.";
      });

      this.tagInteractiveElements();
    },

    tagInteractiveElements() {
      const containers = [
        document.getElementById("omni-pair-modal"),
        document.getElementById("lock"),
        document.getElementById("profiles"),
        document.getElementById("topbar"),
        ...document.querySelectorAll("#main .row, #main section, #main .grid, #modal-root, #player-root")
      ].filter((el) => el && !el.hidden && el.offsetParent !== null);

      this.focusMatrix = [];
      containers.forEach((container) => {
        const items = Array.from(
          container.querySelectorAll(
            'button, a[href], input, select, [tabindex="0"], .card, .tile, .pf-card'
          )
        ).filter((el) => el.offsetParent !== null && !el.disabled && !el.hidden);

        items.forEach((el) => {
          el.setAttribute("data-focusable", "true");
          if (!el.hasAttribute("tabindex")) el.setAttribute("tabindex", "0");
        });

        if (items.length > 0) {
          this.focusMatrix.push(items);
        }
      });
    },

    bindSpatialNavigation() {
      window.addEventListener("keydown", (e) => {
        const activeTag = document.activeElement ? document.activeElement.tagName : "";
        const isTyping = activeTag === "INPUT" || activeTag === "TEXTAREA";

        // Shift+P opens TV/LAN Pairing Modal
        if (!isTyping && e.shiftKey && e.key.toLowerCase() === "p") {
          e.preventDefault();
          this.openPairingModal();
          return;
        }

        // Quick Search Shortcut ('/' or Cmd+K on macOS)
        if ((e.key === "/" && !isTyping) || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k")) {
          const searchInput = document.getElementById("search");
          if (searchInput) {
            e.preventDefault();
            searchInput.focus();
            return;
          }
        }

        if (e.key === "Escape") {
          const pairModal = document.getElementById("omni-pair-modal");
          if (pairModal) {
            pairModal.remove();
            return;
          }
        }

        if (isTyping && !["Escape", "ArrowDown", "Enter"].includes(e.key)) return;

        if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
          const playerRoot = document.getElementById("player-root");
          if (playerRoot && !playerRoot.hidden) {
            const activeInPlayer = document.activeElement && playerRoot.contains(document.activeElement) && document.activeElement.tagName !== 'BODY';
            if (!activeInPlayer) {
              // Allow playback controls (ArrowLeft/Right for seeking, ArrowUp/Down for Live channel switching) to fire directly
              return;
            }
          }
          this.tagInteractiveElements();
          if (this.focusMatrix.length === 0) return;
          e.preventDefault();
          this.moveSpatialFocus(e.key);
        }
      });
    },

    moveSpatialFocus(direction) {
      const maxRow = this.focusMatrix.length - 1;
      let { row, col } = this.pos;
      row = Math.min(Math.max(0, row), maxRow);

      if (direction === "ArrowDown") {
        row = Math.min(maxRow, row + 1);
        col = Math.min(col, this.focusMatrix[row].length - 1);
      } else if (direction === "ArrowUp") {
        row = Math.max(0, row - 1);
        col = Math.min(col, this.focusMatrix[row].length - 1);
      } else if (direction === "ArrowRight") {
        col = Math.min(this.focusMatrix[row].length - 1, col + 1);
      } else if (direction === "ArrowLeft") {
        col = Math.max(0, col - 1);
      }

      this.pos = { row, col };
      const target = this.focusMatrix[row]?.[col];
      if (target) {
        document.querySelectorAll(".spatial-focused").forEach((el) => el.classList.remove("spatial-focused"));
        target.classList.add("spatial-focused");
        target.focus({ preventScroll: true });
        target.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
      }
    },

    bindMacAndMobileMediaSession() {
      document.addEventListener(
        "play",
        (e) => {
          if (e.target && (e.target.tagName === "VIDEO" || e.target.tagName === "AUDIO")) {
            this.updateMediaSession(e.target);
          }
        },
        true
      );
    },

    updateMediaSession(mediaEl) {
      if (!("mediaSession" in navigator)) return;
      navigator.mediaSession.metadata = new MediaMetadata({
        title: document.title || "Homeflix Stream",
        artist: "Homeflix Omni-Player",
        artwork: [{ src: "/icon.svg", sizes: "512x512", type: "image/svg+xml" }]
      });
      navigator.mediaSession.setActionHandler("play", () => mediaEl.play());
      navigator.mediaSession.setActionHandler("pause", () => mediaEl.pause());
      navigator.mediaSession.setActionHandler("seekbackward", () => {
        mediaEl.currentTime = Math.max(0, mediaEl.currentTime - 10);
      });
      navigator.mediaSession.setActionHandler("seekforward", () => {
        mediaEl.currentTime = Math.min(mediaEl.duration || Infinity, mediaEl.currentTime + 10);
      });
    },

    observeDOMMutations() {
      const observer = new MutationObserver(() => {
        this.injectPairingTrigger();
        this.tagInteractiveElements();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  };

  window.OmniPlatform = OmniPlatform;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => OmniPlatform.init());
  } else {
    OmniPlatform.init();
  }
})();
