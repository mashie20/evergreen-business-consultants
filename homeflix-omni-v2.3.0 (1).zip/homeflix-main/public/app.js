'use strict';
/* ============================================================
   Homeflix app — Netflix-style local-first streaming portal
   Player: frameXTV embeds + postMessage SDK controls
   ============================================================ */

(() => {
  // Embed domains rotate automatically: if one stops serving, the player
  // watchdog silently fails over to the next mirror (self-healing playback).
  const EMBED_BASES = ['https://framextv.cc', 'https://framextv.xyz', 'https://framextv.pro'];
  let embedBaseIdx = 0;
  let EMBED_ORDER = EMBED_BASES.slice();
  let fastestBase = null;
  // Boot preflight: race every mirror, promote whoever answers first. The
  // player then always opens on the fastest reachable backend, and the
  // watchdog below keeps rotating if a mirror dies mid-session.
  function probeBase(base) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 3500);
    return fetch(base + '/favicon.ico', { mode: 'no-cors', signal: ctl.signal, cache: 'no-store' })
      .then(() => { clearTimeout(t); return base; })
      .catch(() => { clearTimeout(t); throw new Error(base); });
  }
  async function pickEmbedBase() {
    try {
      fastestBase = await Promise.any(EMBED_BASES.map(probeBase));
      EMBED_ORDER = [fastestBase].concat(EMBED_BASES.filter((b) => b !== fastestBase));
    } catch (_) { /* all raced out — keep current order, watchdog handles it */ }
    return fastestBase;
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // Poster helper: works with full IMDb/Wiki URLs and legacy TMDB paths alike.
  function imgSize(u, w) {
    if (!u) return '';
    if (!/^https?:/.test(u)) return `https://image.tmdb.org/t/p/${w >= 600 ? 'w780' : 'w342'}${u}`;
    if (u.includes('media-amazon')) {
      let base = u.replace(/\.jpg$/, '');
      if (base.includes('._V1_')) base = base.replace(/(\._V1_).*$/, '._V1_');
      else base += '._V1_';
      return base + `UX${w}.jpg`;
    }
    return u;
  }

  const FALLBACK_PROVIDERS = [ // used only if the provider registry can't be reached
    { id: 'titan', name: 'Titan — direct MP4 1080p' },
    { id: 'sparky', name: 'Sparky — direct HLS up to 4K' },
    { id: 'super_barbarian', name: 'Super Barbarian — auto HLS' },
    { id: 'giant', name: 'Giant — multi-audio' },
    { id: 'bowler', name: 'Bowler — multi-language' }
  ];
  let PROVIDER_LIST = null; // refreshed from the server's self-healing registry
  async function getProviders() {
    if (PROVIDER_LIST && PROVIDER_LIST.length) return PROVIDER_LIST;
    try {
      const d = await api('/api/providers');
      if (d.providers && d.providers.length) { PROVIDER_LIST = d.providers; return PROVIDER_LIST; }
    } catch (_) {}
    PROVIDER_LIST = FALLBACK_PROVIDERS;
    return PROVIDER_LIST;
  }

  /* ------------------------------------------------- SVG icon library */
  const SVG_ICONS = {
    epl: '<svg class="hf-icon icon-epl" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m12 7 3.5 2.5-1.5 4.5h-4L8.5 9.5z"/><path d="M12 7V2m3.5 7.5L20 8m-6 6 3.5 4M10 14l-3.5 4M8.5 9.5 4 8"/></svg>',
    nfl: '<svg class="hf-icon icon-nfl" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="10" ry="6" transform="rotate(-45 12 12)"/><path d="m8.5 8.5 7 7m-5-2 3-3m-1 5 3-3m-5-1 3-3"/></svg>',
    nba: '<svg class="hf-icon icon-nba" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2.5 10a11.5 11.5 0 0 1 19 0M2.5 14a11.5 11.5 0 0 0 19 0M12 2v20M2 12h20"/></svg>',
    news: '<svg class="hf-icon icon-news" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4.93 4.93a10 10 0 0 1 14.14 0m-11.31 2.83a6 6 0 0 1 8.48 0M12 11a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm0 3v8m-4 0h8"/></svg>',
    tv: '<svg class="hf-icon icon-tv" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="13" rx="2"/><polyline points="17 2 12 7 7 2"/></svg>',
    radio: '<svg class="hf-icon icon-radio" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="8" width="20" height="14" rx="2"/><path d="m5 8 11-6"/><circle cx="8" cy="15" r="2.5"/><line x1="14" y1="13" x2="18" y2="13"/><line x1="14" y1="17" x2="18" y2="17"/></svg>',
    globe: '<svg class="hf-icon icon-globe" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    star: '<svg class="hf-icon icon-star" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',
    info: '<svg class="hf-icon icon-info" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    play: '<svg class="hf-icon icon-play" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"/></svg>',
    pause: '<svg class="hf-icon icon-pause" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>',
    rewind10: '<svg class="hf-icon icon-rewind10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4a8 8 0 1 0 8 8"/><polyline points="12 1 12 7 6 4"/><text x="12" y="15" font-size="7" font-weight="bold" fill="currentColor" stroke="none" text-anchor="middle">10</text></svg>',
    forward10: '<svg class="hf-icon icon-forward10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4a8 8 0 1 1-8 8"/><polyline points="12 1 12 7 18 4"/><text x="12" y="15" font-size="7" font-weight="bold" fill="currentColor" stroke="none" text-anchor="middle">10</text></svg>',
    next: '<svg class="hf-icon icon-next" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 4 15 12 5 20 5 4"/><rect x="16" y="4" width="3" height="16" rx="1"/></svg>',
    prev: '<svg class="hf-icon icon-prev" viewBox="0 0 24 24" fill="currentColor"><polygon points="19 20 9 12 19 4 19 20"/><rect x="5" y="4" width="3" height="16" rx="1"/></svg>',
    volume: '<svg class="hf-icon icon-volume" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="currentColor"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>',
    mute: '<svg class="hf-icon icon-mute" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill="currentColor"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>',
    fullscreen: '<svg class="hf-icon icon-fs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><polyline points="21 15 21 21 15 21"/><polyline points="3 9 3 3 9 3"/></svg>',
    exitFs: '<svg class="hf-icon icon-exitfs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><polyline points="14 20 14 14 20 14"/><polyline points="10 4 10 10 4 10"/></svg>',
    rotate: '<svg class="hf-icon icon-rotate" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 12a10 10 0 0 1 17.5-6.5L21.5 8M22 12a10 10 0 0 1-17.5 6.5L2.5 16"/></svg>',
    back: '<svg class="hf-icon icon-back" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
    reload: '<svg class="hf-icon icon-reload" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.5 8A10 10 0 1 0 22 12"/></svg>',
    live: '<svg class="hf-icon icon-live" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2a10 10 0 0 0-7.07 17.07l1.41-1.41A8 8 0 1 1 12 20v2a10 10 0 0 0 0-20z" opacity=".5"/></svg>',
    download: '<svg class="hf-icon icon-download" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    lock: '<svg class="hf-icon icon-lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    shield: '<svg class="hf-icon icon-shield" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    check: '<svg class="hf-icon icon-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>',
    close: '<svg class="hf-icon icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    plus: '<svg class="hf-icon icon-plus" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>'
  };

  function icon(name, extraClass = '') {
    const s = SVG_ICONS[name];
    if (!s) return '';
    if (!extraClass) return s;
    return s.replace('class="hf-icon ', `class="hf-icon ${extraClass} `);
  }

  function setupDoubleTapSeek(stageEl) {
    if (!stageEl || stageEl._hasDoubleTap) return;
    stageEl._hasDoubleTap = true;
    let lastTap = 0;
    let lastX = 0;
    stageEl.addEventListener('touchend', (e) => {
      const now = Date.now();
      const touch = e.changedTouches && e.changedTouches[0];
      if (!touch) return;
      const x = touch.clientX;
      const rect = stageEl.getBoundingClientRect();
      if (now - lastTap < 320 && Math.abs(x - lastX) < 90) {
        e.preventDefault();
        const isLeft = (x - rect.left) < rect.width / 2;
        if (isLeft) {
          const b10 = $('#pb-back10');
          if (b10) b10.click();
          showSeekRipple(stageEl, 'left', '-10s');
        } else {
          const f10 = $('#pb-fwd10');
          if (f10) f10.click();
          showSeekRipple(stageEl, 'right', '+10s');
        }
        lastTap = 0;
      } else {
        lastTap = now;
        lastX = x;
      }
    });
  }

  function showSeekRipple(container, side, text) {
    const rip = document.createElement('div');
    rip.className = `seek-ripple seek-ripple-${side}`;
    rip.innerHTML = `<span>${text}</span>`;
    container.appendChild(rip);
    setTimeout(() => rip.remove(), 550);
  }

  /* ---------------------------------------------------------- state */
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (_) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} }
  };
  const state = {
    route: null,
    prevHash: '#/', // last non-player route — where Back should return to
    rows: null,
    rowsAt: store.get('hf_rows_at', 0),
    myList: store.get('hf_mylist', []),
    progress: store.get('hf_progress', {}),
    settings: Object.assign({ provider: 'auto', volume: 1, muted: false, speed: '1', sub: 0, autoplay: 1, mutedStart: 0 }, store.get('hf_settings', {})),
    locked: false,
    user: null
  };

  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
  const main = $('#main');
  const playerRoot = $('#player-root');
  const modalRoot = $('#modal-root');

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  // "2025-06-13" -> "Jun 2025", "2025" -> "2025", missing -> falsy.
  const periodOf = (r) => {
    const rd = String((r && r.rd) || '');
    const y = Number(rd.slice(0, 4)) || (r && r.y) || 0;
    if (!y) return '';
    const m = Number(rd.slice(5, 7));
    return (m >= 1 && m <= 12 ? MONTHS[m - 1] + ' ' : '') + y;
  };
  const titleOf = (r) => r && r.t || '';
  const yearOf = (r) => r && r.y || '';
  const metaLine = (r) => {
    const bits = [];
    const when = periodOf(r);
    if (when) bits.push(when);
    if (r.v) bits.push(`<span class="match">${Number(r.v).toFixed(1)} ${icon('star')}</span>`);
    const g = (r.g || []).filter((x) => typeof x === 'string').slice(0, 3).map(esc);
    return bits.concat(g).join(' <span class="dim">&bull;</span> ');
  };

  let toastTimer = 0;
  function toast(msg, ms) {
    const t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, ms || 2600);
  }

  function showStatus(html, spinning) {
    const bar = $('#statusbar');
    if (!html) { bar.hidden = true; return; }
    bar.innerHTML = (spinning ? '<div class="spinner"></div>' : '') + html;
    bar.hidden = false;
  }

  /* ---------------------------------------------------------- API */
  // Auto-retries network failures and 5xx blips (e.g. while the server
  // restarts to push an update) so brief maintenance never shows errors.
  async function api(path, opts) {
    let lastErr;
    for (let i = 0; i < 3; i++) {
      try {
        const res = await fetch(path, opts);
        if (!res.ok) {
          let msg = 'HTTP ' + res.status, code = '';
          try { const j = await res.json(); msg = j.error || msg; code = j.error || ''; } catch (_) {}
          if (res.status === 401 && code === 'locked') { showLock(); throw new Error('locked'); }
          if (res.status === 502 || res.status === 503 || res.status === 504) { lastErr = new Error(msg); await sleep(500 * (i + 1)); continue; }
          throw new Error(msg);
        }
        return res.json();
      } catch (e) {
        if (e.message === 'locked') throw e;
        lastErr = e;
        if (i < 2) await sleep(500 * (i + 1)); // network hiccup — server restarting
      }
    }
    throw lastErr;
  }

  /* ---------------------------------------------------------- auth utils */
  async function promptPIN(name, correctPin) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-backdrop';
      overlay.innerHTML = `
        <div class="modal" style="width:300px; text-align:center; padding:30px;">
          <h2 style="margin-bottom:20px">Enter PIN for ${name}</h2>
          <input id="pin-input" type="password" style="width:100%; padding:12px; margin-bottom:20px; text-align:center; font-size:20px; letter-spacing:5px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;" placeholder="****">
          <div class="pf-btns">
            <button class="btn btn-red" id="pin-go">Continue</button>
            <button class="btn btn-ghost" id="pin-cancel">Cancel</button>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const input = overlay.querySelector('#pin-input');
      input.focus();
      const finish = (ok) => { overlay.remove(); resolve(ok); };
      overlay.querySelector('#pin-go').addEventListener('click', () => {
        if (input.value === correctPin) finish(true);
        else { input.value = ''; input.placeholder = 'Wrong PIN!'; setTimeout(() => input.placeholder = '****', 1000); }
      });
      overlay.querySelector('#pin-cancel').addEventListener('click', () => finish(false));
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') overlay.querySelector('#pin-go').click(); });
    });
  }

  async function showAccountCreation(p) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'modal-backdrop';
      overlay.innerHTML = `
        <div class="modal" style="width:400px; padding:30px;">
          <h2 style="margin-bottom:10px">Welcome, ${esc(p.name)}</h2>
          <p style="color:var(--muted); margin-bottom:20px">Create your account to start watching.</p>
          <div class="pf-form" style="width:100%; margin:0;">
            <input id="acc-email" type="email" placeholder="Email address" style="width:100%; padding:12px; margin-bottom:12px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;">
            <input id="acc-pass" type="password" placeholder="Password" style="width:100%; padding:12px; margin-bottom:20px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;">
            <h3 style="font-size:15px; margin:20px 0 10px; color:var(--text)">Payment Details</h3>
            <input id="acc-card" type="text" placeholder="Card Number" style="width:100%; padding:12px; margin-bottom:12px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;">
            <div style="display:flex; gap:10px; margin-bottom:20px;">
              <input id="acc-exp" type="text" placeholder="MM/YY" style="width:50%; padding:12px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;">
              <input id="acc-cvv" type="text" placeholder="CVV" style="width:50%; padding:12px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;">
            </div>
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px;">
              <input id="acc-promo" type="text" placeholder="Promo Code" style="flex:1; padding:12px; background:var(--bg-3); border:1px solid var(--line); color:#fff; border-radius:8px;">
              <button class="btn btn-sm btn-ghost" id="acc-thanks">thanksjulius</button>
            </div>
            <div id="trial-info" style="text-align:center; font-size:13px; color:var(--muted); margin-bottom:20px;">Trial: 3 Days Free</div>
            <div class="pf-btns" style="justify-content:flex-end">
              <button class="btn btn-ghost" id="acc-cancel">Cancel</button>
              <button class="btn btn-red" id="acc-create">Start Free Trial</button>
            </div>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const promo = overlay.querySelector('#acc-promo');
      const trialInfo = overlay.querySelector('#trial-info');
      overlay.querySelector('#acc-thanks').addEventListener('click', () => {
        promo.value = 'thanksjulius';
        trialInfo.textContent = 'Trial: 3 Months Free';
        trialInfo.style.color = '#46d369';
      });
      const finish = (data) => { overlay.remove(); resolve(data); };
      overlay.querySelector('#acc-cancel').addEventListener('click', () => finish(null));
      overlay.querySelector('#acc-create').addEventListener('click', () => {
        const email = overlay.querySelector('#acc-email').value.trim();
        const pass = overlay.querySelector('#acc-pass').value.trim();
        if (!email || !pass) { toast('Email and password required'); return; }
        finish({ email, password: pass });
      });
    });
  }

  /* ---------------------------------------------------------- accounts (per-user data) */
  let userSyncTimer = 0;
  function syncUserData() { // debounced push of progress + list to the server (signed-in only)
    if (!state.user) return;
    clearTimeout(userSyncTimer);
    userSyncTimer = setTimeout(() => {
      api('/api/user/data', { method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ progress: state.progress, list: state.myList }) }).catch(() => {});
    }, 2500);
  }

  function avatarInit() {
    const a = $('#avatar');
    a.textContent = state.user ? state.user.trim()[0].toUpperCase() : 'G';
    a.title = state.user ? state.user + ' — profile menu' : 'Guest — profile menu';
    $('#ud-name').textContent = state.user ? state.user : 'Guest (not signed in)';
  }

  async function loadUserData() { // server data is the truth for signed-in users
    let d = null;
    try { d = await api('/api/user/data'); } catch (e) { d = e.message === 'no-user' ? null : undefined; }
    if (!d) return;
    const empty = !Object.keys(d.progress || {}).length && !(d.list || []).length;
    const localP = store.get('hf_progress', {}), localL = store.get('hf_mylist', []);
    if (empty && (Object.keys(localP).length || localL.length)) {
      // first sign-in on this device: adopt this device's guest history
      state.progress = localP;
      state.myList = localL;
      syncUserData();
    } else {
      state.progress = d.progress || {};
      state.myList = d.list || [];
    }
  }

  function pfColor(name) {
    let h = 0;
    for (const c of String(name)) h = (h * 31 + c.charCodeAt(0)) % 360;
    return `linear-gradient(160deg,hsl(${h},45%,42%),hsl(${(h + 60) % 360},50%,26%))`;
  }

  function showProfilePicker() {
    return new Promise((resolve) => {
      const root = $('#profiles'), grid = $('#profiles-grid'), sub = $('#profiles-sub');
      root.hidden = false;
      sub.textContent = '';
      let done = false;
      const finish = (name) => { if (done) return; done = true; root.hidden = true; resolve(name); };
      const post = (path, body) => api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

      async function drawGrid() {
        sub.textContent = '';
        grid.innerHTML = '<div class="spinner" style="margin:30px auto"></div>';
        let profiles = [];
        try { profiles = (await api('/api/auth/profiles')).profiles; } catch (e) { sub.textContent = e.message; }
        if (done) return;
        // Map 'Mom' to 'Guest' for the UI
        const uiProfiles = profiles.map(p => p.name === 'Mom' ? { ...p, name: 'Guest' } : p);
        grid.innerHTML = uiProfiles.map((p, i) => `
          <div class="pf" data-i="${i}">
            <div class="pf-ava" style="background:${pfColor(p.name)}">${esc(p.name.trim()[0].toUpperCase())}</div>
            <div class="pf-name">${esc(p.name)}${p.hasPw || p.name === 'Guest' ? ' ' + icon('lock') : ''}</div>
          </div>`).join('') + `
          <div class="pf" id="pf-add"><div class="pf-ava pf-add-ava">${icon('plus')}</div><div class="pf-name">Add profile</div></div>`;
        $$('.pf[data-i]', grid).forEach((el) => el.addEventListener('click', () => pickProfile(uiProfiles[Number(el.dataset.i)])));
        $('#pf-add', grid).addEventListener('click', addForm);
      }

      async function pickProfile(p) {
        if (!p.hasPw) {
          try { finish((await post('/api/auth/login', { name: p.name })).user); }
          catch (e) { sub.textContent = e.message; }
          return;
        }
        sub.textContent = '';
        grid.innerHTML = `
          <div class="pf-form">
            <div class="pf-ava" style="background:${pfColor(p.name)}">${esc(p.name.trim()[0].toUpperCase())}</div>
            <div class="pf-name">${esc(p.name)} — enter password</div>
            <input id="pf-pass" type="password" placeholder="Password" autocomplete="current-password">
            <div class="pf-btns"><button class="btn btn-red" id="pf-go">Continue</button><button class="btn btn-ghost" id="pf-back">${icon('back')} Back</button></div>
          </div>`;
        const pass = $('#pf-pass', grid);
        pass.focus();
        $('#pf-back', grid).addEventListener('click', drawGrid);
        const go = async () => {
          try { finish((await post('/api/auth/login', { name: p.name, password: pass.value })).user); }
          catch (e) { sub.textContent = e.message; }
        };
        $('#pf-go', grid).addEventListener('click', go);
        pass.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
      }

      function addForm() {
        sub.textContent = '';
        grid.innerHTML = `
          <div class="pf-form">
            <input id="pf-name" placeholder="Profile name" maxlength="24" autocomplete="off">
            <input id="pf-pass1" type="password" placeholder="Password (optional)" autocomplete="new-password">
            <div class="pf-btns"><button class="btn btn-red" id="pf-create">Create</button><button class="btn btn-ghost" id="pf-back">${icon('back')} Back</button></div>
            <div class="pf-hint">Password is optional — it just stops others from opening your profile.</div>
          </div>`;
        $('#pf-name', grid).focus();
        $('#pf-back', grid).addEventListener('click', drawGrid);
        const create = async () => {
          try { finish((await post('/api/auth/register', { name: $('#pf-name', grid).value, password: $('#pf-pass1', grid).value })).user); }
          catch (e) { sub.textContent = e.message; }
        };
        $('#pf-create', grid).addEventListener('click', create);
        $('#pf-name', grid).addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#pf-pass1', grid).focus(); });
        $('#pf-pass1', grid).addEventListener('keydown', (e) => { if (e.key === 'Enter') create(); });
      }

      $('#profiles-guest').addEventListener('click', async () => {
        const pin = await promptPIN('Guest', '2126');
        if (pin) finish(null);
      });
      drawGrid();
    });
  }

  async function enterAs(name) {
    state.user = name;
    if (name) await loadUserData();
    avatarInit();
  }

  /* ---------------------------------------------------------- progress (local-first) */
  const pKey = (type, id, s, e) => type === 'tv' ? `tv:${id}:${s}x${e}` : `movie:${id}`;

  function saveProgress(rec, s, e, t, dur) {
    if (!rec || !t || t < 3) return;
    const key = pKey(rec.type, rec.id, s, e);
    const prev = state.progress[key] || {};
    state.progress[key] = Object.assign({}, prev, {
      key, type: rec.type, id: rec.id, s: s || 0, e: e || 0,
      t, dur: dur || prev.dur || 0, at: Date.now(),
      title: titleOf(rec), year: rec.y || 0, poster: rec.p || null, backdrop: rec.b || prev.backdrop || null
    });
    // keep only latest 60
    const keys = Object.keys(state.progress);
    if (keys.length > 60) {
      keys.sort((a, b) => (state.progress[a].at || 0) - (state.progress[b].at || 0));
      for (let i = 0; i < keys.length - 60; i++) delete state.progress[keys[i]];
    }
    if (state.user) syncUserData(); else store.set('hf_progress', state.progress);
  }

  function continueWatching() {
    return Object.values(state.progress)
      .filter((p) => p.t > 10 && (!p.dur || p.t < p.dur * 0.96))
      .sort((a, b) => b.at - a.at)
      .slice(0, 14);
  }

  /* ---------------------------------------------------------- my list */
  function inMyList(rec) { return state.myList.some((x) => x.type === rec.type && x.id === rec.id); }
  function toggleMyList(rec) {
    if (inMyList(rec)) state.myList = state.myList.filter((x) => !(x.type === rec.type && x.id === rec.id));
    else state.myList.unshift({ type: rec.type, id: rec.id, t: rec.t, y: rec.y, p: rec.p, g: rec.g, v: rec.v, d: rec.d, addedAt: Date.now() });
    if (state.user) syncUserData(); else store.set('hf_mylist', state.myList);
    toast(inMyList(rec) ? `Added “${rec.t}” to My List` : `Removed “${rec.t}” from My List`);
    return inMyList(rec);
  }

  /* ---------------------------------------------------------- settings */
  function saveSettings() { store.set('hf_settings', state.settings); }

  /* ---------------------------------------------------------- router */
  function parseRoute() {
    const h = location.hash.replace(/^#/, '') || '/';
    const parts = h.split('/').filter(Boolean);
    if (!parts.length) return { name: 'home' };
    switch (parts[0]) {
      case 'movies': return { name: 'browse', type: 'movie' };
      case 'tv': return { name: 'browse', type: 'tv' };
      case 'live': return { name: 'live' };
      case 'radio': return { name: 'radio' };
      case 'youtube': return { name: 'youtube' };
      case 'mylist': return { name: 'mylist' };
      case 'search': return { name: 'search', q: decodeURIComponent(parts[1] || '') };
      case 'watch':
        if (parts[1] === 'live') return { name: 'watchlive', id: decodeURIComponent(parts[2] || '') };
        if (parts[1] === 'tv') return { name: 'watch', type: 'tv', id: Number(parts[2]), s: Number(parts[3] || 1), e: Number(parts[4] || 1) };
        return { name: 'watch', type: 'movie', id: Number(parts[2]) };
      default: return { name: 'home' };
    }
  }

  const isWatchRoute = (r) => r && (r.name === 'watch' || r.name === 'watchlive');

  function nav(hash) { if (location.hash === hash) render(); else location.hash = hash; }

  async function render() {
    closeModal(true);
    if (!playerRoot.hidden) return; // player takes over
    const route = parseRoute();
    state.route = route;
    if (!isWatchRoute(route)) state.prevHash = location.hash; // Back lands here
    setActiveNav(route);
    window.scrollTo(0, 0);

    if (route.name === 'watch') { openWatch(route); return; }
    if (route.name === 'watchlive') { openLivePlayer(route); return; }
    if (route.name === 'live') { renderLive('tv'); return; }
    if (route.name === 'radio') { renderLive('radio'); return; }
    if (route.name === 'youtube') { renderYouTube(); return; }
    if (route.name === 'search') { renderSearch(route.q); return; }
    if (route.name === 'mylist') { renderMyList(); return; }
    renderBrowse(route);
  }

  function setActiveNav(route) {
    const key = route.name === 'browse' ? route.type
      : route.name === 'mylist' ? 'mylist'
      : route.name === 'search' ? ''
      : route.name === 'radio' ? 'radio'
      : route.name === 'youtube' ? 'youtube'
      : route.name === 'live' || route.name === 'watchlive' ? 'live'
      : 'home';
    $$('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.nav === key));
  }

  /* ---------------------------------------------------------- rows fetch */
  async function getRows() {
    const cached = store.get('hf_rows', null);
    const fresh = Date.now() - state.rowsAt < 10 * 60000;
    if (cached && fresh) {
      state.rows = cached; // instant paint (local-first)
      api('/api/catalog/rows').then((data) => {
        if (JSON.stringify(data).length !== JSON.stringify(cached).length) {
          state.rows = data; state.rowsAt = Date.now();
          store.set('hf_rows', data); store.set('hf_rows_at', state.rowsAt);
          if (!playerRoot.hidden || state.locked) return;
          const r = state.route;
          if (r && (r.name === 'home' || r.name === 'browse')) renderBrowse(r, true);
        }
      }).catch(() => {});
      return cached;
    }
    try {
      const data = await api('/api/catalog/rows');
      state.rows = data; state.rowsAt = Date.now();
      store.set('hf_rows', data); store.set('hf_rows_at', state.rowsAt);
      return data;
    } catch (e) {
      if (e.message === 'locked') return null;
      return cached || null;
    }
  }

  /* ---------------------------------------------------------- browse views */
  function cardHtml(r, opts) {
    opts = opts || {};
    const fallbackHue = (r.id % 360);
    const posterUrl = imgSize(r.p, 280);
    const poster = posterUrl
      ? `<img class="card-poster" loading="lazy" src="${esc(posterUrl)}" alt="" referrerpolicy="no-referrer">`
      : `<div class="tile-fallback" style="background:linear-gradient(160deg,hsl(${fallbackHue},26%,22%),hsl(${(fallbackHue + 80) % 360},30%,12%))"><span>${esc(r.t)}</span></div>`;
    const badge = (r.type === 'tv' ? '<span class="badge-type">SERIES</span>' : '')
      + (r.o ? `<span class="badge-origin">${esc(r.o)}</span>` : '')
      + (r.av === 1 ? `<span class="badge-av" title="Verified playable">${icon('check')}</span>` : '');
    let progress = '';
    if (opts.progressKey) {
      const p = state.progress[opts.progressKey];
      if (p && p.dur) {
        const pct = Math.min(100, (p.t / p.dur) * 100).toFixed(1);
        const label = p.s ? `S${p.s}:E${p.e}` : 'Resume';
        progress = `<div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
          <div class="card-sub">${esc(label)} &middot; ${fmtTime(p.t)} of ${fmtTime(p.dur)}</div>`;
      }
    }
    const overlay = `<div class="card-overlay"><div class="card-title">${esc(r.t)}</div>
      <div class="card-sub">${esc(periodOf(r))}${periodOf(r) && r.v ? ' &middot; ' : ''}${r.v ? `<span class="rating-badge">${Number(r.v).toFixed(1)} ${icon('star')}</span>` : ''}</div>${progress}</div>`;
    return `<div class="card" data-type="${r.type}" data-id="${r.id}" data-key="${opts.progressKey || ''}" ${r.p ? '' : 'data-enrich="1"'}>
      ${badge}${poster}${overlay}</div>`;
  }

  function fmtTime(s) {
    s = Math.round(s || 0);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return h ? `${h}h ${m}m` : `${m}m`;
  }

  function rowHtml(title, items, opts) {
    if (!items || items.length < 3) return '';
    const key = opts && opts.key || '';
    return `<section class="row-wrap" data-rowkey="${esc(key)}">
      <h2>${esc(title)}</h2>
      <button class="row-arrow left" aria-label="Scroll left">&lsaquo;</button>
      <div class="row">${items.map((r) => cardHtml(r)).join('')}</div>
      <button class="row-arrow right" aria-label="Scroll right">&rsaquo;</button>
    </section>`;
  }

  async function renderBrowse(route, soft) {
    const data = await getRows();
    if (state.locked) return;
    if (!data) {
      main.innerHTML = `<div class="loading-view"><div><div class="spinner"></div>Connecting to your Homeflix…</div></div>`;
      return;
    }
    let rows = data.rows;
    if (route.name === 'browse') rows = rows.filter((r) => r.key === (route.type === 'movie' ? 'movies' : 'tv') ||
      (route.type === 'movie'
        ? ['trending', 'new', 'newmonth', 'available', 'action', 'comedy', 'scifi', 'horror', 'romance', 'documentary', 'top']
        : ['trending', 'new', 'newmonth', 'available', 'animation', 'crime', 'action', 'scifi', 'top']).includes(r.key));

    const cw = continueWatching();
    const hero = route.name === 'home' ? heroHtml(data.featured[0]) : '';
    const cwRow = route.name === 'home' && cw.length ? `<section class="row-wrap" data-rowkey="continue">
      <h2>Continue Watching</h2>
      <button class="row-arrow left" aria-label="Scroll left">&lsaquo;</button>
      <div class="row">${cw.map((p) => cardHtml(
        { type: p.type, id: p.id, t: p.title, y: p.year, p: p.poster, g: [], v: 0 },
        { progressKey: p.key }
      )).join('')}</div>
      <button class="row-arrow right" aria-label="Scroll right">&rsaquo;</button>
    </section>` : '';
    main.innerHTML = `
      ${hero}
      <div class="rows">
        ${cwRow}
        ${rows.map((r) => rowHtml(r.title, r.items)).join('')}
      </div>`;

    bindCards();
    enrichInView(main);
  }

  function heroHtml(r) {
    if (!r) return '';
    const art = imgSize(r.b || r.p, 1280);
    const inList = inMyList(r);
    return `<section class="hero">
      ${art ? `<div class="hero-bg" style="background-image:url('${esc(art)}')"></div>` : ''}
      <div class="hero-inner">
        <div class="hero-meta"><span class="tag">HOMEFLIX ORIGINAL</span></div>
        <h1 class="hero-title">${esc(r.t)}</h1>
        <div class="hero-meta">${metaLine(r)}</div>
        <p class="hero-overview">${esc(r.d)}</p>
        <div class="hero-actions">
          <button class="btn btn-white" data-play="1" data-type="${r.type}" data-id="${r.id}">${icon('play')} Play</button>
          <button class="btn btn-ghost" data-info="1" data-type="${r.type}" data-id="${r.id}">${icon('info')} More Info</button>
        </div>
      </div>
    </section>`;
  }

  /* ---------------------------------------------------------- search */
  let searchTimer = 0;
  function renderSearch(q) {
    $('#search').value = q;
    main.innerHTML = `<div class="grid-wrap"><h1 class="grid-title">Results for “${esc(q)}”</h1><div class="loading-view"><div class="spinner"></div></div></div>`;
    if (!q.trim()) { main.innerHTML = `<div class="grid-wrap"><div class="empty">Type something to search your Homeflix catalog.</div></div>`; return; }
    api(`/api/catalog/search?q=${encodeURIComponent(q)}`).then((data) => {
      if (!data.results.length) {
        main.innerHTML = `<div class="grid-wrap"><h1 class="grid-title">Results for “${esc(q)}”</h1>
          <div class="empty">No matches in your local catalog.<br>Your catalog covers popular movies & shows and refreshes automatically.</div></div>`;
        return;
      }
      main.innerHTML = `<div class="grid-wrap"><p class="search-live">${data.results.length} matches</p>
        <div class="grid">${data.results.map((r) => cardHtml(r)).join('')}</div></div>`;
      bindCards();
      enrichInView(main);
    }).catch((e) => {
      if (e.message === 'locked') return;
      main.innerHTML = `<div class="grid-wrap"><div class="empty">Search failed: ${esc(e.message)}</div></div>`;
    });
  }

  function liveSearch() {
    const q = $('#search').value.trim();
    if (!q) { if (parseRoute().name === 'search') nav('#/'); return; }
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => nav('#/search/' + encodeURIComponent(q)), 380);
  }

  /* ---------------------------------------------------------- my list */
  function renderMyList() {
    if (!state.myList.length) {
      main.innerHTML = `<div class="grid-wrap"><h1 class="grid-title">My List</h1>
        <div class="empty">Your list is empty.<br>Hover any title and use <b>+ My List</b> in its details.</div></div>`;
      return;
    }
    main.innerHTML = `<div class="grid-wrap"><h1 class="grid-title">My List</h1>
      <div class="grid">${state.myList.map((r) => cardHtml(r)).join('')}</div></div>`;
    bindCards();
    enrichInView(main);
  }

  function renderYouTube() {
    main.innerHTML = `
      <div class="yt-page">
        <h1 class="grid-title">HomeTube</h1>
        <div class="yt-layout">
          <aside class="yt-sidebar">
            <div class="yt-side-section">
              <h3>Subscriptions</h3>
              <div id="yt-subs-list" class="yt-subs-grid"></div>
              <button class="btn btn-ghost btn-sm" id="yt-add-sub">${icon('plus')} Follow Channel</button>
            </div>
            <div class="yt-side-section">
              <h3>Library</h3>
              <div id="yt-library-list" class="yt-subs-grid"></div>
            </div>
          </aside>
          <main class="yt-main">
            <div class="yt-filters">
              <button class="chip active" data-yt-filter="all">All</button>
              <button class="chip" data-yt-filter="latest">Latest</button>
              <button class="chip" data-yt-filter="recommended">Recommended</button>
              <button class="chip" data-yt-filter="saved">Saved Videos</button>
            </div>
            <div id="yt-grid" class="grid"></div>
          </main>
        </div>
      </div>`;
    
    // Initial render of placeholders
    $('#yt-subs-list').innerHTML = '<div class="empty-sm">No followed channels</div>';
    $('#yt-library-list').innerHTML = '<div class="empty-sm">No saved videos</div>';
    $('#yt-grid').innerHTML = '<div class="loading-view"><div class="spinner"></div>Curating your HomeTube feed...</div>';
    
    $$('.yt-filters .chip', main).forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.yt-filters .chip', main).forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        // This would call a backend algorithm for filtering/suggestions
        toast(`Filtering by ${btn.dataset.ytFilter}...`);
      });
    });

    $('#yt-add-sub').addEventListener('click', () => {
      const channel = prompt("Enter YouTube Channel ID or @handle:");
      if (channel) toast(`Following ${channel}...`);
    });
  }

  /* ---------------------------------------------------------- modal */
  function openModal(rec) {
    modalRoot.innerHTML = `<div class="modal-backdrop"><div class="modal" role="dialog" aria-label="${esc(rec.t)}">
      <div class="modal-hero" style="${rec.p ? `background-image:url('${esc(imgSize(rec.p, 1280))}')` : ''}"></div>
      <button class="modal-close" aria-label="Close">${icon('close')}</button>
      <div class="modal-body">
        <h2 class="modal-title">${esc(rec.t)}</h2>
        <div class="modal-actions">
          <button class="btn btn-white" data-play="1" data-type="${rec.type}" data-id="${rec.id}">${icon('play')} Play</button>
          <button class="btn btn-ghost" data-download="1" data-type="${rec.type}" data-id="${rec.id}">${icon('download')} Download</button>
          <button class="btn btn-ghost" data-mylist="1" data-type="${rec.type}" data-id="${rec.id}">${inMyList(rec) ? icon('check') + ' In My List' : icon('plus') + ' My List'}</button>
        </div>
        <div class="modal-meta"><span id="modal-av"></span>${metaLine(rec)}</div>
        <p class="modal-overview">${esc(rec.d || '')}</p>
        <div id="modal-episodes"></div>
        <div id="modal-similar"></div>
      </div>
    </div></div>`;
    
    bindCards(modalRoot);
    $('.modal-close', modalRoot).addEventListener('click', () => closeModal());
    $('.modal-backdrop', modalRoot).addEventListener('click', (e) => { if (e.target.classList.contains('modal-backdrop')) closeModal(); });
    document.body.style.overflow = 'hidden';
    
    // Availability check (server probes frameXTV providers, disk-cached) —
    // updates in place without blocking the modal opening.
    const avEl = () => $('#modal-av');
    api(`/api/av?type=${rec.type}&id=${rec.id}${rec.type === 'tv' ? '&season=1&episode=1' : ''}`).then((a) => {
      if (!avEl()) return;
      avEl().innerHTML = a.av === 1
        ? '<span class="match">' + icon('check') + ' Available</span> <span class="dim">&bull;</span> '
        : a.av === 0 ? '<span class="dim">' + icon('close') + ' No stream right now</span> <span class="dim">&bull;</span> ' : '';
    }).catch(() => {});
    
    // Fresh details (server enriches + disk-caches on this request)
    api(`/api/title/${rec.type}/${rec.id}`).then((d) => {
      if (!modalRoot.querySelector('.modal')) return;
      const fresh = d.title;
      const body = modalRoot.querySelector('.modal-body');
      const ov = body.querySelector('.modal-overview');
      if (fresh.d && !ov.textContent) ov.textContent = fresh.d;
      body.querySelector('.modal-meta').innerHTML = metaLine(fresh);
      const hero = modalRoot.querySelector('.modal-hero');
      const art = imgSize(fresh.p, 1280);
      if (art && !hero.style.backgroundImage) hero.style.backgroundImage = `url('${art}')`;
    
      const box = $('#modal-similar');
      if (box && d.similar && d.similar.length) {
        box.innerHTML = `<h3 class="sec-title">More Like This</h3><div class="sim-grid">${d.similar.map((r) => `
          <div class="sim-card" data-type="${r.type}" data-id="${r.id}">
            ${r.p ? `<img loading="lazy" src="${esc(imgSize(r.p, 160))}" alt="" referrerpolicy="no-referrer">` : `<div class="tile-fallback" style="aspect-ratio:2/3;background:linear-gradient(160deg,#23262c,#14161a)"><span>${esc(r.t)}</span></div>`}
            <div class="sim-name">${esc(r.t)}</div></div>`).join('')}</div>`;
        bindCards(box);
        enrichInView(box);
      }
    }).catch(() => {});
    
    if (rec.type === 'tv') renderModalEpisodes(rec);
  }

  async function renderModalEpisodes(rec) {
    const box = $('#modal-episodes');
    box.innerHTML = `<h3 class="sec-title">Episodes</h3><div class="loading-view" style="min-height:120px"><div class="spinner"></div></div>`;
    let seasons;
    try { seasons = await api(`/api/tv/${rec.id}/seasons`); }
    catch (_) { seasons = { seasons: [], fallback: true }; }
    if (!seasons.seasons.length) {
      box.innerHTML = `<h3 class="sec-title">Episodes</h3>
        <div class="empty" style="padding:16px 0">Episode guide unavailable — the player includes its own season & episode picker.</div>`;
      return;
    }
    const first = seasons.seasons[0].n;
    box.innerHTML = `<h3 class="sec-title">Episodes</h3>
      <div class="season-bar"><label class="pb-sub" for="season-select">Season</label>
        <select id="season-select">${seasons.seasons.map((s) => `<option value="${s.n}">Season ${s.n}</option>`).join('')}</select>
        <span class="pb-sub" id="season-count">${seasons.seasons[0].count} episodes</span></div>
      <div class="ep-list" id="ep-list"><div class="loading-view" style="min-height:100px"><div class="spinner"></div></div></div>`;
    const sel = $('#season-select', box);
    sel.addEventListener('change', () => loadEpisodes(rec, Number(sel.value)));
    loadEpisodes(rec, first);
  }

  async function loadEpisodes(rec, season) {
    const list = $('#ep-list');
    let data;
    try { data = await api(`/api/tv/${rec.id}/episodes/${season}`); }
    catch (_) { data = { episodes: [], fallback: true }; }
    if (!data.episodes.length) {
      list.innerHTML = `<div class="empty" style="padding:14px 0">No episode data for this season — you can still play it; the player has its own picker.</div>`;
      return;
    }
    list.innerHTML = data.episodes.map((ep) => `
      <div class="ep" data-play-ep="1" data-type="tv" data-id="${rec.id}" data-s="${ep.s}" data-e="${ep.e}">
        <div class="ep-num">${ep.e}</div>
        ${ep.img ? `<img class="ep-thumb" loading="lazy" src="${esc(ep.img)}" alt="">` : `<div class="ep-thumb-fb">${icon("play")}</div>`}
        <div class="ep-info">
          <div class="ep-name">${esc(ep.n || `Episode ${ep.e}`)}</div>
          <div class="ep-sub">${ep.air || ''}</div>
          ${ep.d ? `<div class="ep-sum">${esc(ep.d)}</div>` : ''}
        </div>
      </div>`).join('');
    $('#season-count', modalRoot).textContent = `${data.episodes.length} episodes`;
  }

  function closeModal() {
    if (!modalRoot.innerHTML) return;
    modalRoot.innerHTML = '';
    if (playerRoot.hidden) document.body.style.overflow = '';
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalRoot.innerHTML && playerRoot.hidden) closeModal();
  });

  /* ---------------------------------------------------------- player */
  function embedUrl(route, extra) {
    const rec = route.rec;
    const path = rec.type === 'tv' ? `${rec.id}/${route.s}/${route.e}` : `${rec.id}`;
    const params = new URLSearchParams({
      autoplay: '1',
      muted: state.settings.mutedStart ? '1' : '0',
      controls: '1',
      speed: state.settings.speed || '1'
    });
    if (route.resumeT > 5) params.set('t', String(Math.floor(route.resumeT)));
    if (state.settings.provider && state.settings.provider !== 'auto') params.set('server', state.settings.provider);
    const posterUrl = imgSize(rec.p, 1280);
    if (posterUrl) params.set('poster', posterUrl);
    params.set('title', rec.t);
    if (extra) for (const [k, v] of Object.entries(extra)) v == null ? params.delete(k) : params.set(k, v);
    const base = EMBED_ORDER[embedBaseIdx % EMBED_ORDER.length];
    return base + '/embed/' + path + '?' + params.toString();
  }

  let playerCtl = null; // live player controller

  async function openWatch(route) {
    document.body.style.overflow = 'hidden';
    main.innerHTML = '';
    $('#topbar').style.display = 'none';
    playerRoot.hidden = false;

    let rec = null;
    try {
      const d = await api(`/api/title/${route.type}/${route.id}`);
      rec = d.title;
    } catch (e) {
      if (e.message === 'locked') return;
      rec = null;
    }
    if (!rec) {
      rec = { id: route.id, type: route.type, t: route.type === 'tv' ? 'TV Episode' : 'Movie', p: null, b: null, g: [], v: 0, y: 0, rd: '', d: '' };
      toast('Title details unavailable — playing anyway');
    }
    route.rec = rec;

    const pk = pKey(rec.type, rec.id, route.s, route.e);
    const prevEp = state.progress[pKey(rec.type, rec.id, 0, 0)] || Object.values(state.progress).find((p) => p.type === rec.type && p.id === rec.id && (rec.type === 'movie' || (p.s === route.s && p.e === route.e)));
    route.resumeT = prevEp && prevEp.t > 5 ? prevEp.t : 0;

    const label = rec.type === 'tv' ? `${rec.t} — S${route.s}:E${route.e}` : rec.t;
    const provs = await getProviders();
    const providerOpts = [['auto', 'Auto (best available)']].concat(provs.map((p) => [p.id, p.name]))
      .map(([v, l]) => `<option value="${esc(v)}" ${v === state.settings.provider ? 'selected' : ''}>${esc(l)}</option>`).join('');
    const speeds = ['0.5', '1', '1.25', '1.5', '2'].map((v) => `<option value="${v}" ${v === String(state.settings.speed) ? 'selected' : ''}>${v}×</option>`).join('');
    const nextEp = rec.type === 'tv' ? await peekNextEpisode(rec, route.s, route.e) : null;

    playerRoot.innerHTML = `
      <div class="player-stage">
        <div class="stage-16x9">
          <iframe id="streamframe" src="${embedUrl(route)}" allowfullscreen
            allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
            sandbox="allow-scripts allow-same-origin allow-presentation"
            referrerpolicy="origin" title="${esc(label)}"></iframe>
          <div class="player-loading" id="player-loading"><div><div class="spinner"></div>Extracting stream…</div></div>
          <div class="player-overlay-ctrls">
            <button class="overlay-btn" id="overlay-fs" title="Fullscreen">${icon('fullscreen')}</button>
            <button class="overlay-btn" id="overlay-rotate" title="Rotate Screen">${icon('rotate')}</button>
          </div>
        </div>
      </div>
      <div class="player-bar" id="player-bar">
        <div class="pb-group">
          <button class="pb-btn primary" id="pb-back" title="Back (Esc)">${icon('back')} Back</button>
          <span class="pb-title">${esc(rec.t)}</span>
          ${rec.type === 'tv' ? `<span class="pb-sub pb-keep">S${route.s}:E${route.e}</span>` : ''}
        </div>
        <div class="pb-group">
          <button class="pb-btn" id="pb-back10" title="Back 10s">${icon('rewind10')} 10s</button>
          <button class="pb-btn primary" id="pb-playpause" title="Play / Pause (Space)">${icon('pause')} Pause</button>
          <button class="pb-btn" id="pb-fwd10" title="Forward 10s">10s ${icon('forward10')}</button>
        </div>
        <div class="pb-group">
          <button class="pb-btn" id="pb-mute" title="Mute (M)">${icon(state.settings.muted ? 'mute' : 'volume')}</button>
          <input type="range" class="pb-range" id="pb-vol" min="0" max="1" step="0.05" value="${state.settings.volume}">
        </div>
        <div class="pb-group">
          <span class="pb-sub">Server</span>
          <select class="pb-select" id="pb-provider">${providerOpts}</select>
          <span class="pb-sub">Speed</span>
          <select class="pb-select" id="pb-speed">${speeds}</select>
          <span class="pb-sub">Subs</span>
          <input type="number" class="pb-select" id="pb-sub" min="0" max="20" value="${state.settings.sub || 0}" style="width:64px">
        </div>
        <div class="pb-group" style="margin-left:auto">
          <span class="pb-sub" id="shield-badge" hidden title="Blocked ad attempts this session"></span>
          ${nextEp ? `<button class="pb-btn" id="pb-next" title="Next episode">Next episode ${icon('next')}</button>` : ''}
          <button class="pb-btn" id="pb-reload" title="Reload stream (R)">Reload</button>
          <button class="pb-btn" id="pb-fs" title="Fullscreen (F)" data-fs="0">${icon('fullscreen')} Fullscreen</button>
        </div>
      </div>`;

    const iframe = $('#streamframe');
    let loadedOk = false;
    iframe.addEventListener('load', () => {
      loadedOk = true;
      const pl = $('#player-loading');
      if (pl) pl.remove();
    });
    setTimeout(() => {
      if (!loadedOk) {
        const pl = $('#player-loading');
        if (pl) pl.innerHTML = '<div><div class="spinner"></div>Still extracting — if nothing loads, try another server below.</div>';
      }
    }, 8000);

    playerCtl = {
      route,
      iframe,
      lastSaved: 0,
      send(msg) { try { iframe.contentWindow.postMessage(msg, '*'); } catch (_) {} }
    };

    // Playback watchdog — "never breaks" guarantee: if the embed never reports
    // actual playback (dead provider, moved embed domain), silently rotate
    // through every server, then through every embed mirror, then show a note.
    const ctl = playerCtl; // single reference for every watcher closure
    let watchdog = 0;
    const scheduleWatchdog = () => {
      clearTimeout(watchdog);
      watchdog = setTimeout(async () => {
        if (playerCtl !== ctl || playerRoot.hidden || ctl.gotPlayback || document.hidden) return;
        const p = await getProviders();
        const order = ['auto'].concat(p.map((x) => x.id));
        const k = (ctl.rot || 0) + 1;
        ctl.rot = k;
        if (k > order.length * EMBED_BASES.length) {
          showStreamNote('Stream servers are busy right now — tap Reload to retry, or try again in a few minutes.', true);
          return;
        }
        embedBaseIdx = Math.floor((k - 1) / order.length) % EMBED_BASES.length;
        state.settings.provider = order[(k - 1) % order.length];
        const sel = $('#pb-provider');
        if (sel) sel.value = state.settings.provider;
        toast('Stream server busy — switching automatically…');
        reloadStream(ctl);
        scheduleWatchdog();
      }, 16000);
    };
    scheduleWatchdog();

    bindPlayerControls(ctl, nextEp);
    setupDoubleTapSeek($('.player-stage'));
    fsBtnSync(); // keep the enter/exit label truthful on open
    startIdleHider();
  }

  async function peekNextEpisode(rec, s, e) {
    try {
      const d = await api(`/api/tv/${rec.id}/episodes/${s}`);
      const list = d.episodes || [];
      const next = list.find((x) => x.e === e + 1) || (list.length && e >= list[list.length - 1].e ? null : null);
      if (next) return { s: next.s, e: next.e, n: next.n };
      // last episode of season -> first of next season
      const sd = await api(`/api/tv/${rec.id}/seasons`);
      const nextSeason = (sd.seasons || []).find((x) => x.n === s + 1);
      if (nextSeason) {
        const nd = await api(`/api/tv/${rec.id}/episodes/${nextSeason.n}`);
        if (nd.episodes && nd.episodes.length) return { s: nextSeason.n, e: nd.episodes[0].e, n: nd.episodes[0].n };
      }
      return null;
    } catch (_) { return null; }
  }

  /* ---- fullscreen, consolidated -------------------------------------
   * One code path for entering AND exiting "true" fullscreen, used by the
   * player-bar button, the keyboard shortcut, and the in-iframe native
   * control alike:
   *   - embed player -> the iframe itself is fullscreened (its own UI fills
   *     the screen; ESC/gesture exits)
   *   - live player  -> on iOS/Android Safari where element fullscreen is
   *     missing, native <video> fullscreen is used; otherwise the stage is
   *   - a fullscreenchange listener keeps the button state truthful. */
  function fsActive() {
    return document.fullscreenElement || document.webkitFullscreenElement || null;
  }
  function requestFs(el) {
    if (!el) return Promise.reject(new Error('no fs element'));
    if (el.requestFullscreen) return el.requestFullscreen();
    if (el.webkitRequestFullscreen) return el.webkitRequestFullscreen();
    return Promise.reject(new Error('fs unsupported'));
  }
  function toggleFullscreen() {
    if (fsActive()) {
      const d = document;
      if (d.exitFullscreen) d.exitFullscreen().catch(() => {});
      else if (d.webkitExitFullscreen) d.webkitExitFullscreen();
      return;
    }
    const isPadlessIos = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    const v = $('#live-media');
    const iframe = $('#streamframe');
    const stage = $('.player-stage');
    if (isPadlessIos && v && v.tagName === 'VIDEO' && v.webkitEnterFullscreen) { v.webkitEnterFullscreen(); return; }
    const target = iframe || (v && v.tagName === 'VIDEO' ? stage : stage);
    requestFs(target).catch(() => { requestFs(document.documentElement).catch(() => {}); });
  }
  function fsBtnSync() {
    const b = $('#pb-fs');
    if (!b) return;
    const on = Boolean(fsActive());
    b.dataset.fs = on ? '1' : '0';
    b.innerHTML = on ? `${icon('exitFs')} Exit` : `${icon('fullscreen')} Fullscreen`;
    b.title = on ? 'Exit fullscreen (F)' : 'Fullscreen (F)';
    const ob = $('#overlay-fs');
    if (ob) {
      ob.innerHTML = on ? icon('exitFs') : icon('fullscreen');
      ob.title = on ? 'Exit fullscreen' : 'Fullscreen';
    }
  }
  // One consolidated fullscreen state machine: button label + control bar
  // visibility stay truthful through EVERY transition (enter via button,
  // exit via button / F key / Esc / native gesture).
  function fsStateChanged() {
    fsBtnSync();
    const bar = $('#player-bar');
    if (!bar) return;
    if (fsActive()) bar.classList.add('hidden-ui'); // fullscreen owns the screen
    else bar.classList.remove('hidden-ui');         // returning -> controls back
  }
  document.addEventListener('fullscreenchange', fsStateChanged);
  document.addEventListener('webkitfullscreenchange', fsStateChanged);

  function bindPlayerControls(ctl, nextEp) {
    const send = ctl.send;
    $('#pb-back').addEventListener('click', () => closeWatch());
    $('#pb-playpause').addEventListener('click', () => {
      const btn = $('#pb-playpause');
      const playing = btn.dataset.playing !== '1';
      btn.dataset.playing = playing ? '1' : '0';
      btn.innerHTML = playing ? `${icon('play')} Play` : `${icon('pause')} Pause`;
      send({ action: playing ? 'pause' : 'play' });
    });
    $('#pb-back10').addEventListener('click', () => send({ action: 'seekBy', seconds: -10 }));
    $('#pb-fwd10').addEventListener('click', () => send({ action: 'seekBy', seconds: 10 }));
    $('#pb-mute').addEventListener('click', () => {
      state.settings.muted = !state.settings.muted;
      $('#pb-mute').innerHTML = icon(state.settings.muted ? 'mute' : 'volume');
      send(state.settings.muted ? { action: 'mute' } : { action: 'setVolume', volume: state.settings.volume });
      saveSettings();
    });
    $('#pb-vol').addEventListener('input', (e) => {
      state.settings.volume = Number(e.target.value);
      state.settings.muted = state.settings.volume === 0;
      $('#pb-mute').innerHTML = icon(state.settings.muted ? 'mute' : 'volume');
      send({ action: 'setVolume', volume: state.settings.volume });
      saveSettings();
    });
    $('#pb-provider').addEventListener('change', (e) => {
      state.settings.provider = e.target.value;
      saveSettings();
      ctl.rot = 0; // manual choice resets the auto-rotation
      if (e.target.value === 'auto') { reloadStream(ctl); }
      else send({ action: 'setProvider', provider: e.target.value });
      const p = PROVIDER_LIST && PROVIDER_LIST.find((x) => x.id === e.target.value);
      toast(`Extraction server: ${p ? p.name : e.target.value}`);
    });
    $('#pb-sub').addEventListener('change', (e) => {
      state.settings.sub = Math.max(0, Number(e.target.value) || 0);
      saveSettings();
      send({ action: 'setSubtitle', index: state.settings.sub });
      toast(`Subtitle track: #${state.settings.sub}`);
    });
    $('#pb-speed').addEventListener('change', (e) => {
      state.settings.speed = e.target.value;
      saveSettings();
      reloadStream(ctl); // speed is applied via URL param per frameXTV docs
    });
    $('#pb-reload').addEventListener('click', () => reloadStream(ctl));
    $('#pb-fs').addEventListener('click', toggleFullscreen);
    $('#overlay-fs').addEventListener('click', toggleFullscreen);
    $('#overlay-rotate').addEventListener('click', () => {
      document.body.classList.toggle('screen-rotated');
      toast('Screen rotated');
    });
    const nextBtn = $('#pb-next');
    if (nextBtn && nextEp) {
      nextBtn.addEventListener('click', () => {
        const r = ctl.route;
        nav(`#/watch/tv/${r.rec.id}/${nextEp.s}/${nextEp.e}`);
      });
    }
  }

  function reloadStream(ctl) {
    const frame = $('#streamframe');
    if (!frame || !ctl.route) return;
    const url = embedUrl(ctl.route, { _r: String(Date.now()) }); // rebuilt fresh: new server + new mirror
    frame.src = url;
    const pl = $('#player-loading');
    if (!pl) $('.stage-16x9').insertAdjacentHTML('beforeend', '<div class="player-loading" id="player-loading"><div><div class="spinner"></div>Switching servers…</div></div>');
    toast('Stream reloaded');
  }

  function closeWatch() {
    if (playerCtl && playerCtl.hls) { try { playerCtl.hls.destroy(); } catch (_) {} }
    if (playerCtl && playerCtl.stallT) clearTimeout(playerCtl.stallT);
    if (fsActive()) { try { document.exitFullscreen(); } catch (_) {} }
    playerRoot.hidden = true;
    playerRoot.innerHTML = '';
    $('#topbar').style.display = '';
    document.body.style.overflow = '';
    playerCtl = null;
    stopIdleHider();
    // Back must land where the user came from — never re-open the player.
    const target = state.prevHash || '#/';
    if (location.hash !== target) { location.hash = target; } // hashchange -> render()
    else render();
  }
  window.addEventListener('hashchange', () => {
    const r = parseRoute();
    if (!playerRoot.hidden) {
      if (!isWatchRoute(r)) { closeWatch(); return; }
      if (r.name === 'watchlive' && playerCtl && playerCtl.mode === 'live' && playerCtl.channel && playerCtl.channel.id !== r.id) {
        openLivePlayer(r);
        return;
      }
      return;
    }
    render();
  });

  /* -------- telemetry: frameXTV postMessage events -> local progress */
  window.addEventListener('message', (event) => {
    const d = event.data;
    if (!d || typeof d !== 'object' || !String(d.event || '').startsWith('frameXTV:')) return;
    if (!playerCtl) return;
    const ev = String(d.event);
    // keep the play/pause button truthful (embed may change state on its own)
    const pb = $('#pb-playpause');
    if (pb && /playing|play$/i.test(ev) && ev !== 'frameXTV:playpause') { pb.dataset.playing = '1'; pb.innerHTML = `${icon('pause')} Pause`; }
    if (pb && /paus/i.test(ev) && !/playing/i.test(ev)) { pb.dataset.playing = '0'; pb.innerHTML = `${icon('play')} Play`; }
    if (!ev.startsWith('frameXTV:error')) playerCtl.gotPlayback = playerCtl.gotPlayback || /timeupdate|progress|playing/i.test(ev);
    if (ev === 'frameXTV:timeupdate' || ev === 'frameXTV:progress') {
      const t = Number(d.currentTime || 0);
      const dur = Number(d.duration || 0);
      const now = Date.now();
      if (now - playerCtl.lastSaved > 5000 && t > 3) {
        playerCtl.lastSaved = now;
        const r = playerCtl.route;
        saveProgress(r.rec, r.type === 'tv' ? r.s : 0, r.type === 'tv' ? r.e : 0, t, dur);
      }
    }
    if (d.event === 'frameXTV:ended') {
      const r = playerCtl.route;
      const key = pKey(r.rec.type, r.rec.id, r.s, r.e);
      delete state.progress[key];
      if (state.user) syncUserData(); else store.set('hf_progress', state.progress);
    }
    if (d.event === 'frameXTV:error' || d.event === 'frameXTV:providererror') {
      showStreamNote('Extraction failed on this server — switching may help:', true);
    }
  });

  function showStreamNote(text, withServers) {
    const stage = $('.player-stage');
    if (!stage) return;
    let note = $('.stream-note', stage);
    if (!note) {
      note = document.createElement('div');
      note.className = 'stream-note';
      stage.appendChild(note);
    }
    note.innerHTML = `<span>${esc(text)}</span>${withServers ? `<button id="note-switch">Switch server & reload</button>` : ''}`;
    const btn = $('#note-switch');
    if (btn) btn.addEventListener('click', async () => {
      const provs = await getProviders();
      const order = ['auto'].concat(provs.map((p) => p.id));
      const cur = state.settings.provider;
      const i = order.indexOf(cur);
      state.settings.provider = order[(i + 1) % order.length] || 'auto';
      saveSettings();
      const sel = $('#pb-provider');
      if (sel) sel.value = state.settings.provider;
      note.remove();
      reloadStream(playerCtl);
    });
  }

  /* -------- ad shield: absolutely zero ads survive ---------------------
   * Layer 1 (server): CSP only ever frames the known embed mirrors, and the
   * player iframe is sandboxed without allow-popups / allow-top-navigation /
   * allow-modals / allow-downloads — pop-unders, tab-outs, top-page
   * redirects and fake "download" dialogs from embedded sources cannot happen
   * on any browser platform (desktop Chrome, mobile Chrome, Safari, iOS…).
   * Layer 2 (this runtime): even stray code in our own page can't spawn ads. */
  let adsBlocked = 0, lastShieldNote = 0;
  function noteShield() {
    adsBlocked++;
    const b = $('#shield-badge');
    if (b) { b.hidden = false; b.innerHTML = icon('shield') + ' ' + adsBlocked; }
    const now = Date.now();
    if (now - lastShieldNote > 12000) { lastShieldNote = now; toast('Ad popup blocked — playback stays clean'); }
  }
  window.open = function adShieldOpen() { noteShield(); return null; };
  document.addEventListener('click', (e) => {
    const t = e.target;
    const a = t && t.closest ? t.closest('a[target="_blank"]') : null;
    if (a) { e.preventDefault(); e.stopPropagation(); noteShield(); }
  }, true);

  /* -------- auto-hide player bar (mouse AND touch) */
  let idleTimer = 0;
  const idleEvents = ['mousemove', 'touchstart', 'pointerdown'];
  function idleHandler() {
    const bar = $('#player-bar');
    if (!bar) return;
    bar.classList.remove('hidden-ui');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      const p = $('#pb-provider');
      const q = $('#live-q');
      if (!(p && p.matches(':focus')) && !(q && q.matches(':focus'))) bar.classList.add('hidden-ui');
    }, 3000);
  }
  function startIdleHider() {
    idleEvents.forEach((ev) => window.addEventListener(ev, idleHandler, { passive: true }));
    idleHandler();
  }
  function stopIdleHider() {
    idleEvents.forEach((ev) => window.removeEventListener(ev, idleHandler));
    clearTimeout(idleTimer);
  }

  /* -------- player keyboard (fullscreen-safe: Esc exits FS before closing) */
  document.addEventListener('keydown', (e) => {
    if (playerRoot.hidden || !playerCtl) return;
    if (e.target && /input|select|textarea/i.test(e.target.tagName)) return;
    const send = playerCtl.send || (() => {});
    const v = $('#live-media');
    const inFs = Boolean(fsActive());
    switch (e.key) {
      case ' ': case 'k': case 'K': e.preventDefault(); $('#pb-playpause')?.click(); break;
      case 'ArrowLeft':
        e.preventDefault();
        if (v) {
          const start = (v.seekable && v.seekable.length) ? v.seekable.start(0) : 0;
          v.currentTime = Math.max(start, v.currentTime - 10);
        } else {
          send({ action: 'seekBy', seconds: -10 });
        }
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (v) {
          const end = (v.seekable && v.seekable.length) ? v.seekable.end(v.seekable.length - 1) : v.currentTime + 10;
          v.currentTime = Math.min(end, v.currentTime + 10);
        } else {
          send({ action: 'seekBy', seconds: 10 });
        }
        break;
      case 'ArrowUp':
      case 'ChannelUp':
        if (playerCtl.mode === 'live') {
          e.preventDefault();
          switchLiveChannel(-1);
        } else if (v) {
          e.preventDefault();
          v.volume = Math.min(1, v.volume + 0.1);
          if ($('#pb-vol')) $('#pb-vol').value = v.volume;
        }
        break;
      case 'ArrowDown':
      case 'ChannelDown':
        if (playerCtl.mode === 'live') {
          e.preventDefault();
          switchLiveChannel(1);
        } else if (v) {
          e.preventDefault();
          v.volume = Math.max(0, v.volume - 0.1);
          if ($('#pb-vol')) $('#pb-vol').value = v.volume;
        }
        break;
      case 'm': case 'M': $('#pb-mute')?.click(); break;
      case 'f': case 'F': e.preventDefault(); toggleFullscreen(); break;
      case 'r': case 'R': e.preventDefault(); $('#pb-reload')?.click(); break;
      case 'Escape': case 'Backspace': if (!inFs) closeWatch(); break;
    }
  });

  /* ------------------------------------------------- live TV & radio */
  const liveUi = { kind: 'tv', cat: 'all', country: 'INT', q: '', flags: new Map() };
  const LEAGUES = [
    ['epl', 'EPL', 'soccer,premier league,sky sports,nbc sports,usa network,ten sports'],
    ['nfl', 'NFL', 'nfl,fox sports,cbs sports,espn,nbc sports,nfl network'],
    ['nba', 'NBA', 'nba,basketball,espn,tnt sports,nba tv'],
    ['news', 'News', 'news']
  ];

  async function renderLive(kind) {
    if (kind && kind !== liveUi.kind) { liveUi.kind = kind; liveUi.cat = 'all'; liveUi.q = ''; liveUi.country = 'INT'; }
    const noun = liveUi.kind === 'radio' ? 'station' : 'channel';
    const nouns = liveUi.kind === 'radio' ? 'stations' : 'channels';
    main.innerHTML = `<div class="live-page"><div class="loading-view"><div><div class="spinner"></div>Loading worldwide ${liveUi.kind === 'radio' ? 'stations' : 'channels'}…</div></div></div>`;
    let idx;
    try { idx = await api('/api/live/index'); }
    catch (e) {
      if (e.message === 'locked') return;
      main.innerHTML = `<div class="grid-wrap"><div class="empty">${liveUi.kind === 'radio' ? 'Radio list' : 'Live guide'} is warming up — try again in a few seconds.</div></div>`;
      return;
    }
    liveUi.flags = new Map(idx.countries.map((c) => [c.code, c.flag]));
    // page-switch pills (separate sections in the navbar, friendly cross-links here)
    const kindTabs = [
      { href: '#/live', k: 'tv', label: 'Live TV', icon: 'tv', count: idx.kinds.tv },
      { href: '#/radio', k: 'radio', label: 'Radio', icon: 'radio', count: idx.kinds.radio }
    ];
    const cats = [{ slug: 'all', count: idx.total }].concat(idx.categories);
    const countries = [{ code: 'INT', name: 'Worldwide', flag: '', count: idx.total }]
      .concat(idx.countries.filter((c) => c.code));
    main.innerHTML = `<div class="live-page">
      <h1 class="grid-title">${liveUi.kind === 'radio' ? icon('radio') + ' Radio' : icon('tv') + ' Live TV'}</h1>
      <p class="live-intro">${liveUi.kind === 'radio'
        ? `Live radio stations from around the world, grouped by country. Every station tries its backup streams automatically.`
        : `Live channels & radio from around the world &mdash; EPL, NFL and NBA networks under Sports. If a signal fails, the player auto-switches to backup streams.`}</p>
      ${liveUi.kind === 'radio' && idx.kinds.radio === 0 ? `<p class="live-intro dim">${icon('radio')} Stations are still syncing &mdash; the list fills in automatically in about a minute.</p>` : ''}
      <div class="live-tabs">${kindTabs.map((k) => `<a class="live-tab ${liveUi.kind === k.k ? 'active' : ''}" href="${k.href}">${icon(k.icon)} ${esc(k.label)} &middot; ${k.count}</a>`).join('')}</div>
      <div class="live-controls">
        <input id="live-q" class="live-q" placeholder="Search ${nouns}…" value="${esc(liveUi.q)}" autocomplete="off">
        <select id="live-country" class="live-select" title="Country">
          ${countries.map((c) => `<option value="${esc(c.code)}" ${liveUi.country === c.code ? 'selected' : ''}>${esc(c.flag + ' ' + c.name + ' (' + c.count + ')')}</option>`).join('')}
        </select>
      </div>
      <div class="live-cats">${cats.map((c) => `<button class="chip ${liveUi.cat === c.slug ? 'active' : ''}" data-cat="${esc(c.slug)}">${esc(c.slug === 'all' ? 'All' : c.slug.charAt(0).toUpperCase() + c.slug.slice(1))}<span class="chip-n">${c.count}</span></button>`).join('')}</div>
      ${liveUi.kind === 'tv' ? `<div class="live-leagues">${LEAGUES.map(([iconKey, label, q]) => `<button class="chip chip-league" data-league="${esc(q)}">${icon(iconKey)} ${esc(label)}</button>`).join('')}<button class="chip chip-league" id="live-add-toggle" title="Pin another official YouTube live channel as a dynamic feed">${icon('plus')} Add YouTube channel</button></div>
        <div class="live-controls" id="live-add-form" style="display:none">
          <input id="add-yt-url" class="live-q" placeholder="Paste a YouTube live link or @handle — https://youtube.com/@Name/live" autocomplete="off">
          <input id="add-yt-name" class="live-q" style="max-width:220px" placeholder="Display name" maxlength="80" autocomplete="off">
          <button id="add-yt-save" class="btn btn-ghost" style="flex:none">${icon('plus')} Add</button>
        </div>` : ''}
      <div id="live-list"><div class="loading-view" style="min-height:160px"><div class="spinner"></div></div></div>
      <div id="live-more"></div>
    </div>`;

    $$('.chip[data-cat]', main).forEach((b) => b.addEventListener('click', () => { liveUi.cat = b.dataset.cat; renderLive(liveUi.kind); }));
    $$('.chip-league', main).forEach((b) => b.addEventListener('click', () => { liveUi.q = b.dataset.league; liveUi.cat = 'sports'; const inp = $('#live-q'); if (inp) inp.value = ''; loadLiveList(0); }));
    const csel = $('#live-country');
    csel.addEventListener('change', () => { liveUi.country = csel.value; loadLiveList(0); });
    let lqTimer = 0;
    const qinp = $('#live-q');
    qinp.addEventListener('input', () => {
      clearTimeout(lqTimer);
      lqTimer = setTimeout(() => { liveUi.q = qinp.value.trim(); loadLiveList(0); }, 350);
    });
    // self-service: pin any official YouTube live channel as a dynamic feed
    const addToggle = $('#live-add-toggle');
    if (addToggle) {
      const addForm = $('#live-add-form');
      addToggle.addEventListener('click', () => {
        const open = addForm.style.display === 'none';
        addForm.style.display = open ? '' : 'none';
        if (open) $('#add-yt-url').focus();
      });
      const addSave = $('#add-yt-save');
      addSave.addEventListener('click', async () => {
        const url = $('#add-yt-url').value.trim();
        const n = $('#add-yt-name') ? $('#add-yt-name').value.trim() : '';
        if (!url) { toast('Paste a YouTube live link or @handle first'); return; }
        addSave.disabled = true; addSave.textContent = 'Adding…';
        try {
          const d = await api('/api/live/yt/add', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url, n }) });
          toast(d.added ? 'Added to Live TV — the list refreshed' : d.updated ? 'Channel pinned — the list refreshed' : 'Channel was already in the list');
          if (d.added || d.updated) renderLive();
          else { addSave.disabled = false; addSave.innerHTML = icon('plus') + ' Add'; }
        } catch (e) {
          toast(e.message === 'locked' ? 'Sign in first' : 'Could not add: ' + e.message);
          addSave.disabled = false; addSave.innerHTML = icon('plus') + ' Add';
        }
      });
      $('#add-yt-url').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addSave.click(); } });
    }
    loadLiveList(0);
    // Radio lands via the server's background top-up — refresh this page once
    // so the radio data appears without the user reloading anything.
    if (liveUi.kind === 'radio' && idx.kinds.radio === 0) {
      clearTimeout(renderLive._radioWait);
      renderLive._radioWait = setTimeout(() => {
        if (state.route && state.route.name === 'radio') renderLive(liveUi.kind);
      }, 15000); // increased from 60s to 15s to reduce perceived lag, but the actual issue isSvr a bit slow
    }
  }

  const overviewMode = () => liveUi.country === 'INT' && !liveUi.q && liveUi.cat === 'all';

  async function loadLiveList(offset) {
    const host = $('#live-list');
    if (!host) return;
    if (offset === 0 && overviewMode()) { await loadLiveSections(); return; }
    hideLiveSectionsNote(host);
    const grid = $('#live-grid') || ensureFlatGrid(host);
    const p = new URLSearchParams({
      kind: liveUi.kind,
      country: liveUi.country === 'INT' ? '' : liveUi.country,
      category: liveUi.cat, q: liveUi.q, limit: '120', offset: String(offset)
    });
    let d;
    try { d = await api('/api/live/channels?' + p.toString()); }
    catch (e) { if (e.message === 'locked') return; grid.innerHTML = `<div class="empty">Live guide unavailable — ${esc(e.message)}</div>`; return; }
    if (offset === 0) liveUi.lastChannels = d.channels || []; else liveUi.lastChannels = (liveUi.lastChannels || []).concat(d.channels || []);
    const html = d.channels.map(liveCardHtml).join('');
    if (offset === 0) grid.innerHTML = html || `<div class="empty">No matches &mdash; try another country, category or search.</div>`;
    else grid.insertAdjacentHTML('beforeend', html);
    $$('.live-thumb img', grid).forEach((img) => img.addEventListener('error', () => { img.style.display = 'none'; }, { once: true }));
    bindLiveCards();
    const more = $('#live-more');
    if (more) more.innerHTML = (offset + d.channels.length) < d.total
      ? `<button class="btn btn-ghost" id="live-more-btn">Show more (${d.total - offset - d.channels.length} left)</button>` : '';
    const mb = $('#live-more-btn');
    if (mb) mb.addEventListener('click', () => loadLiveList(offset + d.channels.length));
  }

  function ensureFlatGrid(host) {
    host.innerHTML = `<div class="live-grid" id="live-grid"></div>`;
    return $('#live-grid', host);
  }
  function hideLiveSectionsNote(host) {
    const note = $('#live-secnote', host);
    if (note) note.remove();
  }

  // Worldwide overview: one server call, whole world nested by country —
  // each section is a flag-titled board with that country's top channels
  // and a "View all" jump into the flat filtered view.
  async function loadLiveSections() {
    const host = $('#live-list');
    const more = $('#live-more');
    if (more) more.innerHTML = '';
    let d;
    try {
      d = await api('/api/live/sections?' + new URLSearchParams({
        kind: liveUi.kind, category: liveUi.cat === 'all' ? '' : liveUi.cat, limit: '24'
      }));
    } catch (e) {
      if (e.message === 'locked') return;
      host.innerHTML = `<div class="empty">Guide unavailable — ${esc(e.message)}</div>`;
      return;
    }
    if (!d.sections || !d.sections.length) {
      host.innerHTML = `<div class="empty">Nothing available yet — try again in a few seconds.</div>`;
      return;
    }
    host.innerHTML = `
      <p class="live-intro" id="live-secnote">${icon('globe')} World overview &mdash; ${d.total} live ${liveUi.kind === 'radio' ? 'stations' : 'channels'}. Pick a country or search to go deeper.</p>
      <div id="live-sections-container"></div>`;
    
    // Render sections incrementally to keep UI responsive
    const container = $('#live-sections-container');
    for (let i = 0; i < d.sections.length; i++) {
      const sec = d.sections[i];
      const secHtml = `
        <section class="live-sec" data-co="${esc(sec.co)}">
          <h2 class="live-sec-h">
            <span class="live-sec-flag">${esc(sec.flag)}</span> ${esc(sec.name)}
            <span class="chip-n">${sec.total}</span>
            ${sec.total > sec.channels.length ? `<button class="live-sec-all" data-co="${esc(sec.co)}" data-name="${esc(sec.name)}">View all ${sec.total} &rarr;</button>` : ''}
          </h2>
          <div class="live-grid">${sec.channels.map(liveCardHtml).join('')}</div>
        </section>`;
      container.insertAdjacentHTML('beforeend', secHtml);
      // Load batches of 5 then yield to paint, but if radio, yield more often to prevent UI freeze
      if (i % (liveUi.kind === 'radio' ? 2 : 5) === 0) await sleep(0);
    }
    $$('.live-thumb img', host).forEach((img) => img.addEventListener('error', () => { img.style.display = 'none'; }, { once: true }));
    bindLiveCards();
    $$('.live-sec-all', host).forEach((b) => b.addEventListener('click', () => {
      liveUi.country = b.dataset.co || 'INT';
      const csel = $('#live-country');
      if (csel) csel.value = liveUi.country;
      loadLiveList(0);
    }));
  }

  function liveCardHtml(c) {
    const flag = (liveUi.flags && liveUi.flags.get(c.co)) || '';
    const flagHtml = (flag && flag !== '🌐' && flag !== '🌍') ? `<span class="live-flag">${esc(flag)}</span>` : icon('globe');
    const tags = (c.cats || []).slice(0, 2).map((x) => esc(x)).join(' &middot; ');
    const ytc = c.src === 'youtube' ? `<span class="chip-n" title="Official YouTube live feed">${icon('play')} YT</span> ` : '';
    return `<div class="live-card" role="button" tabindex="0" aria-label="Watch ${esc(c.n)}" data-live="${esc(c.id)}">
      <div class="live-thumb">
        ${c.logo ? `<img loading="lazy" src="${esc(c.logo)}" alt="" referrerpolicy="no-referrer">` : `<span class="live-fallback">${icon(c.kind === 'radio' ? 'radio' : 'tv')}</span>`}
        <span class="live-dot ${c.av === 1 ? 'dot-green' : 'dot-red'}">&bull;</span>
      </div>
      <div class="live-name">${esc(c.n)}</div>
      <div class="live-sub">${ytc}${flagHtml}${tags ? ' &middot; ' + tags : ''}</div>
    </div>`;
  }

  function bindLiveCards() {
    $$('.live-card', main).forEach((el) => {
      const go = () => nav('#/watch/live/' + encodeURIComponent(el.dataset.live));
      el.addEventListener('click', go);
      // keyboard + assistive tech: every channel is reachable without a mouse
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
    });
  }

  async function openLivePlayer(route) {
    document.body.style.overflow = 'hidden';
    main.innerHTML = '';
    $('#topbar').style.display = 'none';
    playerRoot.hidden = false;

    let ch = null;
    try {
      const d = await api('/api/live/channels?id=' + encodeURIComponent(route.id) + '&limit=1');
      ch = d.channels && d.channels[0] || null;
    } catch (_) {}
    if (!ch) {
      playerRoot.innerHTML = `<div class="player-stage"><div class="stage-16x9"><div class="empty" style="margin:auto">Channel not found — it may have gone offline.</div></div></div>
        <div class="player-bar"><div class="pb-group"><button class="pb-btn primary" id="pb-back">${icon('back')} Back</button></div></div>`;
      $('#pb-back').addEventListener('click', () => closeWatch());
      return;
    }
    const isRadio = ch.kind === 'radio';
    playerCtl = { route: { rec: { t: ch.n }, type: 'live' }, channel: ch, mode: 'live', hls: null, candidateIdx: 0, cands: candidatesFor(ch.urls) };

    playerRoot.innerHTML = `
      <div class="player-stage">
        <div class="stage-16x9">
          <${isRadio ? 'audio' : 'video'} id="live-media" ${isRadio ? '' : 'playsinline'} controls
            style="width:100%;height:100%;background:#000;object-fit:contain"></${isRadio ? 'audio' : 'video'}>
          <div class="player-loading" id="player-loading"><div><div class="spinner"></div>Connecting to live signal&hellip;</div></div>
          ${isRadio ? `<div class="live-badge">${icon('radio')} RADIO</div>` : `<div class="live-badge"><span class="live-dot-pulse"></span> LIVE</div>`}
          <div class="player-overlay-ctrls">
            <button class="overlay-btn" id="overlay-fs" title="Fullscreen">${icon('fullscreen')}</button>
            <button class="overlay-btn" id="overlay-rotate" title="Rotate Screen">${icon('rotate')}</button>
          </div>
        </div>
      </div>
      <div class="player-bar" id="player-bar">
        <div class="pb-group">
          <button class="pb-btn primary" id="pb-back" title="Back (Esc)">${icon('back')} Back</button>
          <span class="pb-title">${esc(ch.n)}</span>
          ${isRadio ? `<span class="pb-sub pb-keep">${icon('radio')}</span>` : `<span class="pb-sub pb-keep"><span class="live-dot-pulse"></span> LIVE</span>`}
          <button class="pb-btn" id="pb-prev-chan" title="Previous channel (ArrowUp)">${icon('prev')} Prev</button>
          <button class="pb-btn" id="pb-next-chan" title="Next channel (ArrowDown)">Next ${icon('next')}</button>
        </div>
        <div class="pb-group">
          <button class="pb-btn" id="pb-back10" title="Back 10s">${icon('rewind10')} 10s</button>
          <button class="pb-btn primary" id="pb-playpause" title="Play / Pause (Space)">${icon('pause')} Pause</button>
          <button class="pb-btn" id="pb-fwd10" title="Forward 10s">10s ${icon('forward10')}</button>
          <button class="pb-btn" id="pb-mute" title="Mute (M)">${icon('mute')}</button>
          <input type="range" class="pb-range" id="pb-vol" min="0" max="1" step="0.05" value="${state.settings.volume}">
        </div>
        <div class="pb-group" style="margin-left:auto">
          <span class="pb-sub" id="shield-badge" hidden title="Blocked ad attempts this session"></span>
          ${isRadio ? '' : `<button class="pb-btn" id="pb-tolive" title="Jump to live edge">${icon('live')} Live</button>`}
          <button class="pb-btn" id="pb-reload" title="Reload stream (R)">${icon('reload')} Reload</button>
          <button class="pb-btn" id="pb-fs" title="Fullscreen (F)" data-fs="0">${icon('fullscreen')} Fullscreen</button>
        </div>
      </div>`;

    bindLiveControls(playerCtl);
    startIdleHider();
    fsBtnSync();
    // Autoplay-safe: start muted, invite unmute (browsers require a gesture).
    const v = $('#live-media');
    v.muted = true;
    $('#pb-mute').innerHTML = icon('mute');
    playLiveUrl(playerCtl, 0);
  }

  function bindLiveControls(ctl) {
    const v = $('#live-media');
    const pp = $('#pb-playpause');
    $('#pb-back').addEventListener('click', () => closeWatch());
    v.addEventListener('play', () => { if (pp) pp.innerHTML = `${icon('pause')} Pause`; });
    v.addEventListener('pause', () => { if (pp) pp.innerHTML = `${icon('play')} Play`; });
    if (pp) {
      pp.addEventListener('click', () => {
        if (v.paused) v.play().catch(() => {}); else v.pause();
      });
    }
    const b10 = $('#pb-back10');
    if (b10) {
      b10.addEventListener('click', () => {
        const start = (v.seekable && v.seekable.length) ? v.seekable.start(0) : 0;
        v.currentTime = Math.max(start, v.currentTime - 10);
        toast('Rewound 10s');
      });
    }
    const f10 = $('#pb-fwd10');
    if (f10) {
      f10.addEventListener('click', () => {
        const end = (v.seekable && v.seekable.length) ? v.seekable.end(v.seekable.length - 1) : v.currentTime + 10;
        v.currentTime = Math.min(end, v.currentTime + 10);
        toast('Forward 10s');
      });
    }
    const muteBtn = $('#pb-mute');
    if (muteBtn) {
      muteBtn.addEventListener('click', () => {
        v.muted = !v.muted;
        muteBtn.innerHTML = icon(v.muted ? 'mute' : 'volume');
        state.settings.muted = v.muted;
        saveSettings();
      });
    }
    const vol = $('#pb-vol');
    if (vol) {
      vol.addEventListener('input', (e) => {
        v.volume = Number(e.target.value);
        v.muted = v.volume === 0;
        if (muteBtn) muteBtn.innerHTML = icon(v.muted ? 'mute' : 'volume');
        state.settings.volume = v.volume;
        state.settings.muted = v.muted;
        saveSettings();
      });
    }
    const tl = $('#pb-tolive');
    if (tl) {
      tl.addEventListener('click', () => {
        const lp = ctl.hls && ctl.hls.liveSyncPosition;
        const edge = lp != null && isFinite(lp) ? lp : v.seekable && v.seekable.length ? v.seekable.end(v.seekable.length - 1) - 2 : null;
        if (edge != null && isFinite(edge)) { v.currentTime = edge; v.play().catch(() => {}); toast('Jumped to live edge'); }
        else toast('Already at live edge');
      });
    }
    const rl = $('#pb-reload');
    if (rl) rl.addEventListener('click', () => playLiveUrl(ctl, ctl.candidateIdx || 0));
    const fs = $('#pb-fs');
    if (fs) fs.addEventListener('click', toggleFullscreen);
    const ofs = $('#overlay-fs');
    if (ofs) ofs.addEventListener('click', toggleFullscreen);
    const orot = $('#overlay-rotate');
    if (orot) {
      orot.addEventListener('click', () => {
        document.body.classList.toggle('screen-rotated');
        toast('Screen rotated');
      });
    }
    const prevCh = $('#pb-prev-chan');
    if (prevCh) prevCh.addEventListener('click', () => switchLiveChannel(-1));
    const nextCh = $('#pb-next-chan');
    if (nextCh) nextCh.addEventListener('click', () => switchLiveChannel(1));
  }

  async function switchLiveChannel(dir) {
    let list = (liveUi.lastChannels && liveUi.lastChannels.length) ? liveUi.lastChannels : null;
    if (!list || !list.length) {
      try {
        const d = await api('/api/live/channels?kind=' + (playerCtl && playerCtl.channel && playerCtl.channel.kind || 'tv') + '&limit=100');
        list = d.channels || [];
        liveUi.lastChannels = list;
      } catch (_) { list = []; }
    }
    if (!list.length) { toast('No adjacent channels found'); return; }
    const curId = playerCtl && playerCtl.channel && playerCtl.channel.id;
    let idx = list.findIndex((c) => c.id === curId);
    if (idx < 0) idx = 0;
    let nextIdx = idx + dir;
    if (nextIdx < 0) nextIdx = list.length - 1;
    if (nextIdx >= list.length) nextIdx = 0;
    const nextCh = list[nextIdx];
    showChannelBanner(nextCh.n);
    toast(`Switching to ${nextCh.n}…`);
    location.hash = `#/watch/live/${encodeURIComponent(nextCh.id)}`;
  }

  function showChannelBanner(name) {
    const stage = $('.stage-16x9');
    if (!stage) return;
    const old = $('.chan-banner', stage);
    if (old) old.remove();
    const b = document.createElement('div');
    b.className = 'chan-banner';
    b.innerHTML = `${icon('tv')} <span>${esc(name)}</span>`;
    stage.appendChild(b);
    setTimeout(() => { if (b.parentNode) b.remove(); }, 2400);
  }

  /* -------- "actually works" link builder -------------------------------
   * For the HTTPS tunnel, plain http:// links are invisible to the browser
   * (mixed content) and many HLS hosts send no CORS headers at all. Every
   * candidate therefore gets two attempts: direct first, then through our
   * same-origin proxy (/api/media), which lifts both restrictions. */
  function candidatesFor(urls) {
    const pageHttps = location.protocol === 'https:';
    const out = [];
    const seen = new Set();
    const push = (u) => { if (u && !seen.has(u)) { seen.add(u); out.push(u); } };
    for (const u0 of (urls || [])) {
      const raw = String(u0 || '').trim();
      if (/^youtube-live:/i.test(raw)) { push(raw); continue; } // dynamic YT feed — resolved server-side at play time
      if (!/^https?:/i.test(raw)) continue;
      const proxied = '/api/media?u=' + encodeURIComponent(raw);
      if (pageHttps && /^http:/i.test(raw)) push(proxied); // direct is impossible — proxy is not optional here
      else { push(raw); push(proxied); }
    }
    return out;
  }

  // Low-latency live playback with automatic backup-signal rotation:
  // hls.js hugs the live edge and speed-ratchets to catch up after a stall;
  // on any fatal error it silently moves to the next candidate (direct URL,
  // proxy-wrapped URL, backup streams…), and reports dead links to the
  // server so they disappear for everyone.
  function playLiveUrl(ctl, i) {
    const v = $('#live-media');
    const url = (ctl.cands || [])[i || 0];
    if (!v) return;
    if (!url) { nextCandidate(ctl, true); return; }
    if (/^youtube-live:/i.test(url)) { resolveYtLive(ctl, i || 0, url); return; }
    ctl.candidateIdx = i || 0;
    ctl.currentUrl = url;
    if (ctl.hls) {
      try {
        ctl.hls.stopLoad();
        ctl.hls.detachMedia();
        ctl.hls.destroy();
      } catch (_) {}
      ctl.hls = null;
    }
    const cleanup = () => {
      v.removeEventListener('error', vErrNative);
      v.removeEventListener('waiting', vWaiting);
    };
    const vErrNative = () => { cleanup(); nextCandidate(ctl); };
    const vWaiting = () => {
      if (!playerRoot.hidden && !$('#player-loading')) {
        $('.stage-16x9')?.insertAdjacentHTML('beforeend', '<div class="player-loading" id="player-loading"><div><div class="spinner"></div>Buffering live stream&hellip;</div></div>');
      }
    };
    v.addEventListener('waiting', vWaiting);
    v.addEventListener('playing', () => {
      clearTimeout(ctl.stallT);
      const p = $('#player-loading');
      if (p) p.remove();
      cleanup();
    }, { once: true });

    let urlDecoded = url;
    try { urlDecoded = decodeURIComponent(url); } catch (_) {}
    const isHls = /\.m3u8($|[\?#])/i.test(urlDecoded);
    const useHlsJs = window.Hls && isHls && Hls.isSupported();
    if (useHlsJs) {
      const hls = new Hls({
        lowLatencyMode: true,
        liveSyncDurationCount: 2,
        liveDurationInfinity: true,
        maxLiveSyncPlaybackRate: 2,
        backBufferLength: 30,
        maxBufferLength: 18,
        maxBufferSize: 40 * 1000 * 1000,
        capLevelToPlayerSize: true,
        abrEwmaDefaultEstimate: 1000000,
        manifestLoadingTimeOut: 12000,
        manifestLoadingMaxRetry: 2,
        levelLoadingMaxRetry: 4,
        fragLoadingMaxRetry: 6
      });
      ctl.hls = hls;
      hls.loadSource(url);
      hls.attachMedia(v);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        const p = $('#player-loading');
        if (p) p.remove();
        v.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (!data.fatal) return;
        console.log('[hls] fatal:', data.type, data.details, data.response ? 'http=' + data.response.code : '');
        if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          ctl.mediaRetries = (ctl.mediaRetries || 0) + 1;
          if (ctl.mediaRetries <= 2) {
            try { hls.recoverMediaError(); return; } catch (_) {}
          }
        } else if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          ctl.netRetries = (ctl.netRetries || 0) + 1;
          if (ctl.netRetries <= 2) {
            try { hls.startLoad(); return; } catch (_) {}
          }
        }
        cleanup();
        nextCandidate(ctl); // network/other fatal -> backup stream
      });
    } else {
      v.addEventListener('error', vErrNative); // native HLS (Safari) or direct radio stream (mp3/aac)
      v.src = url;
      v.play().catch(() => {});
    }
    clearTimeout(ctl.stallT);
    ctl.stallT = setTimeout(() => {
      if (v.readyState < 2 && !v.paused) nextCandidate(ctl);
    }, 7000);
  }

  /* -------- dynamic YouTube live channels (no embeds, no platform ads) ---
   * youtube-live:<id> candidates are pseudo-URLs: the server resolves the
   * official channel's live page into a fresh raw googlevideo HLS manifest
   * (yt-dlp) played through our own proxy with header fidelity — never an
   * iframe, so the shield stays intact. If a resolved manifest dies
   * mid-play we rotate back to the pseudo slot and re-resolve (&fresh=1
   * bypasses the server's reuse window), capped so an offline channel ends
   * in a visible note instead of spinning forever. */
  async function resolveYtLive(ctl, i, pseudo) {
    const tries = (ctl.ytTries || 0) + 1;
    ctl.ytTries = tries;
    if (!pseudo || tries > 3 || playerCtl !== ctl) { if (tries > 3) ytOffline(ctl); return; }
    let d;
    try {
      d = await api('/api/live/yt/resolve?id=' + encodeURIComponent(pseudo) + (tries > 1 ? '&fresh=1' : ''));
    } catch (e) {
      if (e.message === 'locked') return;
      if (tries < 3) { toast('Live source failed — fetching a fresh one…'); setTimeout(() => { if (playerCtl === ctl) resolveYtLive(ctl, i, pseudo); }, 1500); }
      else ytOffline(ctl);
      return;
    }
    if (!d.url || playerCtl !== ctl) { if (!d.url) ytOffline(ctl); return; }
    const cands = (ctl.cands || []).slice();
    cands[i] = d.url;
    if (!cands.includes(pseudo)) cands.push(pseudo); // keep a re-resolve slot
    ctl.cands = cands;
    playLiveUrl(ctl, i);
  }

  function ytOffline(ctl) {
    const p = $('#player-loading');
    if (p) p.remove();
    if (playerCtl !== ctl) return;
    showStreamNote(`"${(ctl.channel && ctl.channel.n) || 'This channel'}" is not streaming right now — a fresh source is fetched automatically next time.`, false);
  }

  async function nextCandidate(ctl, exhausted) {
    const cands = ctl.cands || [];
    const failed = cands[ctl.candidateIdx || 0];
    if (failed && /^https?:/i.test(failed)) { // only report the real upstream URL
      try {
        const upstream = /api\/media\?u=/.test(failed) ? decodeURIComponent((failed.split('u=')[1] || '').split('&')[0]) : failed;
        // resolved YouTube manifests rotate to a freshly negotiated URL — they
        // are session links, not durable sources, so never poison the ledger
        if (/^https?:/i.test(upstream) && !/googlevideo\./i.test(upstream)) {
          api('/api/live/bad', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: upstream }) }).catch(() => {});
        }
      } catch (_) {}
    }
    const i = (ctl.candidateIdx || 0) + 1;
    if (i < cands.length) {
      toast('Signal failed — trying the next source…');
      playLiveUrl(ctl, i);
    } else {
      const p = $('#player-loading');
      if (p) p.remove();
      const name = ctl.channel && ctl.channel.n ? `“${ctl.channel.n}” is offline right now` : 'This channel is offline right now';
      showStreamNote(`${name} — every link was tried. Pick another${exhausted ? '' : ' or retry in a moment'}.`, false);
    }
  }

  /* ---------------------------------------------------------- card binding */
  function bindCards(root) {
    $$('.card, .sim-card', root).forEach((el) => {
      el.addEventListener('click', (e) => {
        const type = el.dataset.type, id = Number(el.dataset.id);
        if (!type || !id) return;
        const rec = findRec(type, id);
        if (rec) openModal(rec);
        else api(`/api/title/${type}/${id}`).then((d) => openModal(d.title)).catch(() => toast('Details unavailable'));
      });
    });
    $$('.row-wrap').forEach((wrap) => {
      const rowEl = $('.row', wrap);
      $('.row-arrow.left', wrap).addEventListener('click', () => rowEl.scrollBy({ left: -rowEl.clientWidth * 0.9, behavior: 'smooth' }));
      $('.row-arrow.right', wrap).addEventListener('click', () => rowEl.scrollBy({ left: rowEl.clientWidth * 0.9, behavior: 'smooth' }));
    });
    $$('[data-play]', root).forEach((btn) => btn.addEventListener('click', (e) => {
      e.stopPropagation();
      playTitle(btn.dataset.type, Number(btn.dataset.id));
    }));
    $$('[data-download]', root).forEach((btn) => btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const type = btn.dataset.type, id = Number(btn.dataset.id);
      toast(`Requesting download for ${type} ID ${id}...`);
      try {
        const d = await api(`/api/download?type=${type}&id=${id}`);
        if (d.url) {
          window.location.href = d.url;
          toast('Starting download...');
        } else {
          toast('Download link not available for this title');
        }
      } catch (e) {
        toast('Download failed: ' + e.message);
      }
    }));
    $$('[data-play-ep]', root).forEach((btn) => btn.addEventListener('click', () => {
      closeModal();
      nav(`#/watch/tv/${btn.dataset.id}/${btn.dataset.s}/${btn.dataset.e}`);
    }));
    $$('[data-info]', root).forEach((btn) => btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const rec = findRec(btn.dataset.type, Number(btn.dataset.id));
      if (rec) openModal(rec);
    }));
    $$('[data-mylist]', root).forEach((btn) => btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const rec = findRec(btn.dataset.type, Number(btn.dataset.id));
      if (!rec) return;
      const added = toggleMyList(rec);
      btn.innerHTML = added ? `${icon('check')} In My List` : `${icon('plus')} My List`;
    }));
  }

  /* -------- lazy poster/overview enrichment ----------------------------
   * Cards rendered from long-tail catalog rows can arrive without art.
   * `data-enrich="1"` marks them; when scrolled near the viewport we ask the
   * server for fresh details (disk-cached on the server side, so it's cheap)
   * and swap the placeholder tile for a real poster — no full re-render. */
  const seenEnrich = new Set();
  function enrichInView(root) {
    const cards = $$('[data-enrich="1"]', root);
    if (!cards.length) return;
    const io = 'IntersectionObserver' in window
      ? new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            io.unobserve(en.target);
            enrichCard(en.target);
          }
        }, { rootMargin: '160px' })
      : null;
    cards.forEach((el) => {
      if (seenEnrich.has(el.dataset.type + ':' + el.dataset.id)) { el.removeAttribute('data-enrich'); return; }
      if (io) io.observe(el); else enrichCard(el);
    });
  }

  async function enrichCard(el) {
    const type = el.dataset.type, id = Number(el.dataset.id);
    if (!type || !id) { el.removeAttribute('data-enrich'); return; }
    const k = type + ':' + id;
    if (seenEnrich.has(k)) { el.removeAttribute('data-enrich'); return; }
    seenEnrich.add(k);
    let fresh = null;
    try { fresh = (await api(`/api/title/${type}/${id}`)).title; } catch (_) {}
    if (!fresh || (!fresh.p && !fresh.d)) return; // server knew nothing more
    $$(`[data-type="${type}"][data-id="${id}"]`).forEach((other) => { applyEnrich(other, fresh); });
  }

  function applyEnrich(el, fresh) {
    el.removeAttribute('data-enrich');
    const img = $('.card-poster', el);
    if (!img && fresh.p) {
      const fb = $('.tile-fallback', el);
      if (fb) {
        const im = document.createElement('img');
        im.className = 'card-poster';
        im.loading = 'lazy';
        im.referrerPolicy = 'no-referrer';
        im.alt = '';
        im.onerror = (ev) => { ev.target.remove(); };
        im.src = imgSize(fresh.p, 280);
        fb.replaceWith(im);
      }
    }
    const ov = $('.card-overlay', el);
    if (ov && (fresh.rd || fresh.y) && !ov.textContent.includes(String(fresh.y))) {
      const sub = $('.card-sub', ov);
      if (sub) sub.innerHTML = `${esc(periodOf(fresh))}${periodOf(fresh) && fresh.v ? ' &middot; ' : ''}${fresh.v ? `<span class="rating-badge">${Number(fresh.v).toFixed(1)} ${icon('star')}</span>` : ''}`;
    }
  }

  function findRec(type, id) {
    const pools = [];
    if (state.rows) {
      for (const r of state.rows.rows) pools.push(...r.items);
      pools.push(...(state.rows.featured || []));
    }
    pools.push(...state.myList);
    for (const p of Object.values(state.progress)) pools.push({ type: p.type, id: p.id, t: p.title, y: p.year, p: p.poster, b: p.backdrop });
    return pools.find((r) => r && r.type === type && Number(r.id) === Number(id)) || null;
  }

  async function playTitle(type, id) {
    const rec = findRec(type, id);
    if (rec && rec.type === 'tv') {
      // try to resume latest episode progress, else S1E1
      let s = 1, e = 1;
      const p = Object.values(state.progress).filter((x) => x.type === 'tv' && x.id === id).sort((a, b) => b.at - a.at)[0];
      if (p) { s = p.s || 1; e = p.e || 1; }
      closeModal();
      nav(`#/watch/tv/${id}/${s}/${e}`);
      return;
    }
    closeModal();
    nav(`#/watch/movie/${id}`);
  }

  /* ---------------------------------------------------------- status poll */
  async function pollStatus() {
    try {
      const s = await api('/api/status');
      if (s.syncing) {
        showStatus(`<b>Building local catalog…</b> ${esc(s.progress || s.phase || '')} — browsing works with the starter catalog meanwhile`, true);
      } else if (s.error && (!s.counts || s.counts.total === 0)) {
        showStatus(`<b>${icon('info')} Catalog sync failed:</b> ${esc(s.error)} <button class="pb-btn" id="retry-sync" style="margin-left:8px">Retry</button>`, false);
        const b = $('#retry-sync');
        if (b) b.addEventListener('click', () => api('/api/admin/sync', { method: 'POST' }).catch(() => {}));
      } else if (s.counts.total > 0 && s.fromSeed) {
        showStatus(`Starter catalog (${s.counts.total} titles) — full catalog syncing soon`, true);
      } else {
        showStatus('');
      }
    } catch (_) {}
  }

  /* ---------------------------------------------------------- boot */
  window.addEventListener('scroll', () => $('#topbar').classList.toggle('scrolled', window.scrollY > 24));
  $('#search').addEventListener('input', liveSearch);
  $('#search').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { clearTimeout(searchTimer); const q = e.target.value.trim(); if (q) nav('#/search/' + encodeURIComponent(q)); }
    else if (e.key === 'Escape') { e.target.value = ''; e.target.blur(); if (parseRoute().name === 'search') nav('#/'); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && playerRoot.hidden && document.activeElement !== $('#search')) { e.preventDefault(); $('#search').focus(); }
  });

  /* ---------------------------------------------------------- avatar menu */
  $('#avatar').addEventListener('click', (e) => {
    e.stopPropagation();
    const dd = $('#user-dropdown');
    dd.hidden = !dd.hidden;
  });
  document.addEventListener('click', (e) => {
    const dd = $('#user-dropdown');
    if (!dd.hidden && !dd.contains(e.target)) dd.hidden = true;
  });
  $('#ud-switch').addEventListener('click', async () => {
    $('#user-dropdown').hidden = true;
    await enterAs(await showProfilePicker());
    render();
  });
  $('#ud-logout').addEventListener('click', async () => {
    $('#user-dropdown').hidden = true;
    try { await api('/api/auth/logout', { method: 'POST' }); } catch (_) {}
    state.user = null;
    state.progress = store.get('hf_progress', {});
    state.myList = store.get('hf_mylist', []);
    await enterAs(await showProfilePicker());
    render();
  });

  async function boot() {
    pickEmbedBase().catch(() => {}); // fastest embed mirror selected before first Play
    try {
      const g = await api('/api/gate');
      if (g.locked && !g.authed) { showLock(); return; }
    } catch (_) { /* network hiccup — keep going, calls will retry */ }
    try {
      const m = await api('/api/auth/me');
      const qaGuest = new URLSearchParams(location.search).get('qa') === 'guest';
      if (qaGuest) {
        // headless QA / screenshots: skip the picker (safe — gate already unlocked)
      } else if (m && m.user) {
        state.user = m.user;
        await loadUserData();
      } else {
        await enterAs(await showProfilePicker());
      }
    } catch (_) { /* auth hiccup — browse as guest */ }
    avatarInit();
    render();
    pollStatus();
    setInterval(pollStatus, 12000);
  }
  boot();
})();
