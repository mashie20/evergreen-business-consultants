@echo off
REM Homeflix — one-shot public test link via Cloudflare quick tunnel (no account needed)
setlocal
where cloudflared >nul 2>nul
if errorlevel 1 (
  echo Installing cloudflared via winget...
  winget install --id Cloudflare.cloudflared -e --accept-source-agreements --accept-package-agreements
)
echo.
echo Starting a temporary public link for http://localhost:8200 ...
echo Share the https://*.trycloudflare.com URL that appears with your friends.
echo Press Ctrl+C to stop sharing.
echo.
cloudflared tunnel --url http://localhost:8200
